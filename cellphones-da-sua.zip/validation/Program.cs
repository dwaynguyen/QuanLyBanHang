using cellphones.Services;
using cellphones.Models;
using cellphones.ViewModels;
using Microsoft.AspNetCore.DataProtection;
using System.Security.Cryptography;

var passed=0;
void Check(bool condition,string name) { if(!condition) throw new Exception(name);passed++;Console.WriteLine("PASS: "+name); }
var today=new DateTime(2026,11,1);
var purchases=new[] {
    new DonMH { MaDMH=1,NgayGiao=today.AddHours(15) },
    new DonMH { MaDMH=2,NgayGiao=today.AddDays(1) },
    new DonMH { MaDMH=3,NgayGiao=null }
};
var stock=InventoryService.Calculate(purchases,new[] {
    new CTMH { MaDMH=1,MaSP="SP1  ",SLM=20 },
    new CTMH { MaDMH=2,MaSP="SP1",SLM=100 },
    new CTMH { MaDMH=3,MaSP="SP1",SLM=100 }
},new[] { new CTBH { MaSP="sp1",SLB=7 } },today);
Check(stock["SP1"]==13,"received purchases minus reserved sales, case-insensitive IDs, trimmed SQL char padding");
Check(stock.Count==1,"future and undated purchases excluded");
var large=InventoryService.Calculate(purchases,new[] {
    new CTMH { MaDMH=1,MaSP="X",SLM=int.MaxValue },new CTMH { MaDMH=1,MaSP="X",SLM=int.MaxValue }
},Array.Empty<CTBH>(),today);
Check(large["X"]==2L*int.MaxValue,"stock aggregation cannot overflow 32-bit quantities");
var negative=InventoryService.Calculate(Array.Empty<DonMH>(),Array.Empty<CTMH>(),new[]{new CTBH { MaSP="X",SLB=3 }},today);
Check(negative["X"]==-3,"overdrawn historical stock is retained, not silently inflated");
var cart=new CartPage { Lines=new() { new() { Quantity=2,Available=1,Product=new() { MaSP="SP1",DonGia=100 } } } };
Check(cart.HasInsufficientStock,"checkout can identify insufficient quantities");
var oldFingerprint=CartService.Fingerprint(cart);
cart.Lines[0].Product.DonGia=101;
Check(oldFingerprint!=CartService.Fingerprint(cart),"price change invalidates checkout confirmation");
cart.Lines[0].Product.DonGia=100;cart.Lines[0].Quantity=3;
Check(oldFingerprint!=CartService.Fingerprint(cart),"quantity change invalidates checkout confirmation");
var path=Path.Combine(Path.GetTempPath(),"cellphones-key-tests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(path);
try {
    var provider=DataProtectionProvider.Create(new DirectoryInfo(path),b=>b.SetApplicationName("cellphones"));
    var receipts=new OrderReceiptService(null,provider);
    var key=receipts.CreateKey(123,456,today);
    Check(!key.Contains("123:456"),"receipt capability does not expose raw identifiers");
    var restarted=DataProtectionProvider.Create(new DirectoryInfo(path),b=>b.SetApplicationName("cellphones"));
    var payload=restarted.CreateProtector("cellphones.order-receipt.v1").Unprotect(key);
    Check(payload==$"123:456:{today.Ticks}","saved key ring survives a fresh provider / process lifetime");
    Check(receipts.Read("invalid-key")==null,"malformed receipt keys rejected before querying SQL");
    var chars=key.ToCharArray();var index=chars.Length/2;chars[index]=chars[index]=='a'?'b':'a';
    Check(receipts.Read(new string(chars))==null,"tampered receipt key rejected");
} finally { Directory.Delete(path,true); }
Console.WriteLine($"{passed} backend checks passed (no SQL connection required).");
