using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;
using cellphones.Services;
using cellphones.ViewModels;
namespace cellphones.Controllers;
public class AccountController(AppDbContext db,AdminAccess access,ILogger<AccountController> logger):Controller
{
    [AllowAnonymous] public IActionResult Login(string returnUrl="")
    {
        if(User.Identity?.IsAuthenticated==true) return RedirectToAction("Index","Admin");
        return View(new LoginPage { ReturnUrl=returnUrl??"" });
    }
    [HttpPost,AllowAnonymous,EnableRateLimiting("login")]
    public async Task<IActionResult> Login(LoginPage page)
    {
        if(!ModelState.IsValid) return View(page);
        try
        {
            var employee=db.NhanVien_DanhSach().FirstOrDefault(x=>string.Equals(x.TenDN.Trim(),page.Username.Trim(),StringComparison.OrdinalIgnoreCase));
            var verified=false;
            if(employee!=null && !string.IsNullOrEmpty(employee.MatKhau))
            {
                try { verified=new PasswordHasher<NhanVien>().VerifyHashedPassword(employee,employee.MatKhau,page.Password)!=PasswordVerificationResult.Failed; }
                catch(FormatException) { verified=false; }
            }
            if(!verified || !access.IsAdmin(employee!.MaNV)) { ModelState.AddModelError("","Tài khoản, mật khẩu không đúng hoặc bạn chưa có quyền quản trị.");return View(page); }
            var claims=new[] { new Claim(ClaimTypes.NameIdentifier,employee.MaNV.ToString()),new Claim(ClaimTypes.Name,employee.HoNV+" "+employee.TenNV),new Claim(ClaimTypes.Role,"Admin") };
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)),new AuthenticationProperties { IsPersistent=false });
            return Url.IsLocalUrl(page.ReturnUrl)?LocalRedirect(page.ReturnUrl):RedirectToAction("Index","Admin");
        }
        catch(SqlException e) { logger.LogWarning(e,"Admin login database is unavailable");ModelState.AddModelError("","Không kết nối được CSDL. Kiểm tra DbQLBHConnection rồi thử lại.");return View(page); }
    }
    [HttpPost] public async Task<IActionResult> Logout() { await HttpContext.SignOutAsync();return RedirectToAction("Index","Store"); }
    [AllowAnonymous] public IActionResult Denied()=>View();
}
