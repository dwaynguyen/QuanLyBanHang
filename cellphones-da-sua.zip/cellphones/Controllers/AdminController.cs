using Microsoft.AspNetCore.Mvc;
using cellphones.Data;
using cellphones.ViewModels;
namespace cellphones.Controllers;
public class AdminController(AppDbContext db):Controller
{
    public IActionResult Index()
    {
        var products=db.SanPham_DanhSach();var customers=db.KhachHang_DanhSach();var orders=db.DonBH_DanhSach();var details=db.CTBH_DanhSach();
        var totals=details.GroupBy(x=>x.MaDBH).ToDictionary(x=>x.Key,x=>x.Sum(d=>d.SLB*d.DGB));
        var today=TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow,TimeZoneInfo.FindSystemTimeZoneById("Asia/Ho_Chi_Minh")).Date;
        var names=products.ToDictionary(x=>x.MaSP.Trim(),x=>x.TenSP,StringComparer.OrdinalIgnoreCase);
        return View(new DashboardPage { ProductCount=products.Count,CustomerCount=customers.Count,EmployeeCount=db.NhanVien_DanhSach().Count,OrderCount=orders.Count,PendingCount=orders.Count(x=>x.NgayGiao==null),SalesValue=totals.Values.Sum(),Totals=totals,Customers=customers.ToDictionary(x=>x.MaKH,x=>x.HoKH+" "+x.TenKH),Orders=orders.OrderByDescending(x=>x.NgayDat).ThenByDescending(x=>x.MaDBH).Take(8).ToList(),Daily=Enumerable.Range(0,7).Select(i=>today.AddDays(i-6)).Select(day=>(day,orders.Where(o=>o.NgayDat.Date==day).Sum(o=>totals.GetValueOrDefault(o.MaDBH)))).ToList(),BestSellers=details.GroupBy(x=>x.MaSP.Trim(),StringComparer.OrdinalIgnoreCase).Select(g=>(names.GetValueOrDefault(g.Key)??g.Key,g.Sum(x=>x.SLB),g.Sum(x=>x.SLB*x.DGB))).OrderByDescending(x=>x.Item2).Take(5).ToList() });
    }
}
