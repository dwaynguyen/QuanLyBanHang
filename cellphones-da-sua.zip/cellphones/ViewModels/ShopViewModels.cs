using System.ComponentModel.DataAnnotations;
using cellphones.Models;
namespace cellphones.ViewModels;

public class StorePage
{
    public Dictionary<string,long> Stock { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public List<SanPham> Products { get; set; } = new();
    public Dictionary<short,string> Categories { get; set; } = new();
    public bool DatabaseReady { get; set; } = true;
}
public class CartEntry { public string Id { get; set; } = ""; public int Quantity { get; set; } }
public class CartLine
{
    public long Available { get; set; } = long.MaxValue;
    public bool InsufficientStock => Quantity > Available;
    public SanPham Product { get; set; } = new();
    public int Quantity { get; set; }
    public decimal Total => Product.DonGia * Quantity;
}
public class CartPage
{
    public List<CartLine> Lines { get; set; } = new();
    public decimal Total => Lines.Sum(x=>x.Total);
    public int Count => Lines.Sum(x=>x.Quantity);
    public bool DatabaseReady { get; set; } = true;
    public bool HasUnavailable { get; set; }
    public bool HasInsufficientStock => Lines.Any(x => x.InsufficientStock);
    public List<string> UnavailableIds { get; set; } = new();
}
public class CheckoutPage
{
    [Required(ErrorMessage="Nhập họ và tên người nhận"),StringLength(70),Display(Name="Họ và tên")]
    public string FullName { get; set; } = "";
    [Required(ErrorMessage="Nhập số điện thoại"),StringLength(15),RegularExpression(@"^\+?[0-9]{9,15}$",ErrorMessage="Nhập số điện thoại từ 9 đến 15 chữ số"),Display(Name="Số điện thoại")]
    public string Phone { get; set; } = "";
    [Required(ErrorMessage="Nhập email nhận thông tin đơn hàng"),EmailAddress(ErrorMessage="Email không hợp lệ"),StringLength(100),Display(Name="Email")]
    public string Email { get; set; } = "";
    [Required(ErrorMessage="Nhập địa chỉ nhận hàng"),StringLength(255),Display(Name="Địa chỉ nhận hàng")]
    public string Address { get; set; } = "";
    [Range(1,short.MaxValue,ErrorMessage="Chọn xã / phường nhận hàng"),Display(Name="Xã / phường")]
    public short WardId { get; set; }
    [Required,StringLength(64)] public string Token { get; set; } = "";
    public CartPage Cart { get; set; } = new();
    public List<XaPhuong> Wards { get; set; } = new();
    public Dictionary<byte,string> Provinces { get; set; } = new();
    public bool CanOrder { get; set; } = true;
}
public class LoginPage
{
    [Required(ErrorMessage="Nhập tên đăng nhập"),StringLength(50),Display(Name="Tên đăng nhập")]
    public string Username { get; set; } = "";
    [Required(ErrorMessage="Nhập mật khẩu"),StringLength(255),DataType(DataType.Password),Display(Name="Mật khẩu")]
    public string Password { get; set; } = "";
    public string ReturnUrl { get; set; } = "";
}
public class OrderReceipt
{
    public string SessionId { get; set; } = "";
    public DateTime? DeliveryDate { get; set; }
    public string DeliveryLabel => !DeliveryDate.HasValue ? "Chưa có ngày giao" : "Ngày giao đã ghi nhận: " + DeliveryDate.Value.ToString("dd/MM/yyyy");
    public string Key { get; set; } = "";
    public int OrderId { get; set; }
    public string FullName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Address { get; set; } = "";
    public DateTime Created { get; set; }
    public List<CartLine> Lines { get; set; } = new();
    public decimal Total => Lines.Sum(x=>x.Total);
}
public class DashboardPage
{
    public int ProductCount { get; set; }
    public int CustomerCount { get; set; }
    public int EmployeeCount { get; set; }
    public int OrderCount { get; set; }
    public int PendingCount { get; set; }
    public decimal SalesValue { get; set; }
    public List<(DateTime Date,decimal Total)> Daily { get; set; } = new();
    public List<DonBH> Orders { get; set; } = new();
    public Dictionary<int,string> Customers { get; set; } = new();
    public Dictionary<int,decimal> Totals { get; set; } = new();
    public List<(string Name,int Quantity,decimal Total)> BestSellers { get; set; } = new();
}
