using System.Data;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

Console.OutputEncoding=Encoding.UTF8;
var hasher=new PasswordHasher<object>();
var subject=new object();
bool Equal(string a,string b)=>CryptographicOperations.FixedTimeEquals(SHA256.HashData(Encoding.UTF8.GetBytes(a)),SHA256.HashData(Encoding.UTF8.GetBytes(b)));
bool Verify(string stored,string password) {
    // Used ONLY in this local maintenance tool, never in the web login endpoint.
    try {
        var bytes=Convert.FromBase64String(stored);
        if(bytes.Length>0 && bytes[0] is 0 or 1)
            return hasher.VerifyHashedPassword(subject,stored,password)!=PasswordVerificationResult.Failed;
    } catch(FormatException) { }
    return Equal(stored,password);
}
string Normalize(string text)=>new string((text??"").Normalize(NormalizationForm.FormD).Where(c=>CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark).ToArray()).Replace('đ','d').Replace('Đ','D').ToLowerInvariant().Trim();
bool IsAdminRole(string role)=>new[]{"admin","administrator","quan ly","quan tri","quan tri vien"}.Contains(Normalize(role));
if(args.Contains("--self-test")) {
    var password=Convert.ToHexString(RandomNumberGenerator.GetBytes(24))+"a!";
    var hash=hasher.HashPassword(subject,password);
    if(!Verify(hash,password)||Verify(hash,password+"x")||!Verify(password,password)||Verify(password,password+"x")||!IsAdminRole("Quản trị")||IsAdminRole("Bán hàng"))
        throw new Exception("Verification checks failed.");
    Console.WriteLine("PASS: hash verification, wrong password rejection, legacy comparison, role normalization and sales-role rejection (6 checks). No SQL connection.");
    return 0;
}
string ReadSecret(string prompt) {
    if(Console.IsInputRedirected) throw new InvalidOperationException("Hãy chạy công cụ trong cửa sổ console tương tác. Không nhập mật khẩu qua tham số hoặc file.");
    Console.Write(prompt);
    var result=new StringBuilder();
    while(true) {
        var key=Console.ReadKey(intercept:true);
        if(key.Key==ConsoleKey.Enter)break;
        if(key.Key==ConsoleKey.Backspace) { if(result.Length>0) { result.Length--;Console.Write("\b \b"); } }
        else if(!char.IsControl(key.KeyChar)) {result.Append(key.KeyChar);Console.Write('*');}
    }
    Console.WriteLine();return result.ToString();
}
async Task<string> Table(SqlConnection connection,string name) {
    await using var cmd=new SqlCommand("SELECT QUOTENAME(SCHEMA_NAME(schema_id))+'.'+QUOTENAME(name) FROM sys.tables WHERE name IN (@a,@b)",connection);
    cmd.Parameters.AddWithValue("@a",name);cmd.Parameters.AddWithValue("@b",name+"s");
    var names=new List<string>();await using var reader=await cmd.ExecuteReaderAsync();while(await reader.ReadAsync())names.Add(reader.GetString(0));
    if(names.Count!=1)throw new InvalidOperationException("Không tìm được duy nhất bảng "+name+". Không có thay đổi.");
    return names[0];
}
async Task<(short Id,string Password)> Employee(SqlConnection connection,SqlTransaction tx,string table,string username) {
    await using var cmd=new SqlCommand($"SELECT MaNV,MatKhau FROM {table} {(tx==null?"":"WITH(UPDLOCK,HOLDLOCK)")} WHERE LTRIM(RTRIM(TenDN))=@u",connection,tx);
    cmd.Parameters.AddWithValue("@u",username);
    await using var r=await cmd.ExecuteReaderAsync();
    if(!await r.ReadAsync())throw new InvalidOperationException("Không tìm thấy tài khoản nhân viên. Kiểm tra đúng Server/database/tên đăng nhập.");
    var id=r.GetInt16(0);var password=r.IsDBNull(1)?"":r.GetString(1);
    if(await r.ReadAsync())throw new InvalidOperationException("Có nhiều nhân viên trùng tên đăng nhập. Không có thay đổi.");
    return (id,password);
}
async Task CheckRole(SqlConnection connection,SqlTransaction tx,string permissions,string roles,short employee) {
    await using var cmd=new SqlCommand($"SELECT q.TenQuyen FROM {permissions} p JOIN {roles} q ON q.MaQuyen=p.MaQuyen WHERE p.MaNV=@id",connection,tx);
    cmd.Parameters.AddWithValue("@id",employee);await using var r=await cmd.ExecuteReaderAsync();var allowed=false;
    while(await r.ReadAsync())allowed|=IsAdminRole(r.GetString(0));
    if(!allowed)throw new InvalidOperationException("Tài khoản không có quyền quản trị. Công cụ không tự cấp hoặc đổi quyền. Hãy dùng tài khoản quản trị như tandat.");
}
try {
    Console.WriteLine("ĐỔI MẬT KHẨU QUẢN TRỊ SANG DẠNG BĂM\nChỉ cập nhật MatKhau của một nhân viên; không sửa cấu trúc bảng hoặc quyền.");
    Console.Write("Dán đường dẫn thư mục chứa cellphones.csproj: ");
    var root=Path.GetFullPath((Console.ReadLine()??"").Trim().Trim('"'));
    if(!File.Exists(Path.Combine(root,"cellphones.csproj")))throw new InvalidOperationException("Thư mục không có cellphones.csproj.");
    var settings=new ConfigurationBuilder().SetBasePath(root).AddJsonFile("appsettings.json").AddJsonFile("appsettings.Development.json",optional:true).AddEnvironmentVariables().Build();
    var connectionString=settings.GetConnectionString("DbQLBHConnection");
    if(string.IsNullOrWhiteSpace(connectionString))throw new InvalidOperationException("Thiếu DbQLBHConnection trong cấu hình.");
    await using var connection=new SqlConnection(connectionString);await connection.OpenAsync();
    Console.WriteLine($"Đã kết nối Server: {connection.DataSource}; Database: {connection.Database}");
    Console.Write("Tên đăng nhập quản trị (Enter để dùng tandat): ");var username=(Console.ReadLine()??"").Trim();if(username.Length==0)username="tandat";
    var employees=await Table(connection,"NhanVien");var permissions=await Table(connection,"PhanQuyen");var roles=await Table(connection,"Quyen");
    var initial=await Employee(connection,null,employees,username);await CheckRole(connection,null,permissions,roles,initial.Id);
    if(!Verify(initial.Password,ReadSecret("Mật khẩu hiện tại: ")))throw new InvalidOperationException("Mật khẩu hiện tại không khớp. Không có thay đổi.");
    var password=ReadSecret("Mật khẩu MỚI (ít nhất 12 ký tự): ");
    if(password.Length<12 || password.Length>128)throw new InvalidOperationException("Mật khẩu mới cần từ 12 đến 128 ký tự. Không có thay đổi.");
    if(!Equal(password,ReadSecret("Nhập lại mật khẩu mới: ")))throw new InvalidOperationException("Hai lần nhập không khớp. Không có thay đổi.");
    if(Verify(initial.Password,password))throw new InvalidOperationException("Hãy chọn mật khẩu mới khác mật khẩu cũ đã lộ trong ảnh. Không có thay đổi.");
    var hash=hasher.HashPassword(subject,password);
    await using(var size=new SqlCommand("SELECT CASE WHEN max_length=-1 THEN -1 WHEN TYPE_NAME(system_type_id) IN ('nvarchar','nchar') THEN max_length/2 ELSE max_length END FROM sys.columns WHERE object_id=OBJECT_ID(@table) AND name='MatKhau'",connection)) {
        size.Parameters.AddWithValue("@table",employees);var capacity=Convert.ToInt32(await size.ExecuteScalarAsync());
        if(capacity!=-1 && capacity<hash.Length)throw new InvalidOperationException("Cột MatKhau không đủ dài để lưu dạng băm. Công cụ dừng, không đổi kiểu dữ liệu hoặc ghi dữ liệu bị cắt.");
    }
    Console.Write($"Sẽ cập nhật duy nhất mật khẩu của {username} (MaNV={initial.Id}). Gõ DOI để xác nhận: ");
    if(Console.ReadLine()!="DOI") {Console.WriteLine("Đã hủy. Không có thay đổi.");return 0;}
    await using var tx=(SqlTransaction)await connection.BeginTransactionAsync(IsolationLevel.Serializable);
    var current=await Employee(connection,tx,employees,username);
    if(current.Id!=initial.Id || !Equal(current.Password,initial.Password))throw new InvalidOperationException("Tài khoản đã thay đổi trong lúc thao tác. Hãy chạy lại; chưa có thay đổi được lưu.");
    await CheckRole(connection,tx,permissions,roles,current.Id);
    await using var update=new SqlCommand($"UPDATE {employees} SET MatKhau=@hash WHERE MaNV=@id",connection,tx);
    update.Parameters.Add("@hash",SqlDbType.NVarChar,hash.Length).Value=hash;update.Parameters.AddWithValue("@id",current.Id);
    if(await update.ExecuteNonQueryAsync()!=1)throw new InvalidOperationException("Không cập nhật được duy nhất một nhân viên. Giao dịch sẽ hoàn tác.");
    var saved=await Employee(connection,tx,employees,username);
    if(hasher.VerifyHashedPassword(subject,saved.Password,password)==PasswordVerificationResult.Failed)throw new InvalidOperationException("Không xác minh được mật khẩu vừa ghi. Giao dịch sẽ hoàn tác.");
    await tx.CommitAsync();Console.WriteLine("THÀNH CÔNG. Đăng nhập web bằng tài khoản này và mật khẩu MỚI bạn vừa nhập. Không dùng chuỗi băm trong SQL.");
    return 0;
} catch(SqlException e) {
    Console.WriteLine($"Không hoàn tất thao tác SQL (mã {e.Number}). Kiểm tra DbQLBHConnection, quyền cập nhật dữ liệu và đúng database. Không có thay đổi nào được xác nhận thành công.");return 1;
} catch(Exception e) when(e is InvalidOperationException or IOException or ArgumentException or System.Text.Json.JsonException) {
    Console.WriteLine(e.Message);return 1;
}
