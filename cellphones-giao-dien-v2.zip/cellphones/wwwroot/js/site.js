(() => {
    'use strict';
    const norm = value => (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().trim();
    const menuButton = document.querySelector('.menu-toggle');
    const menu = document.getElementById('site-menu');
    const shade = document.querySelector('.menu-shade');
    function closeMenu() { menu.hidden = true; shade.hidden = true; document.body.classList.remove('menu-open'); menuButton.setAttribute('aria-expanded', 'false'); }
    menuButton?.addEventListener('click', () => { const open = menu.hidden; menu.style.top = document.querySelector('.site-header').getBoundingClientRect().bottom + 'px'; menu.hidden = !open; shade.hidden = !open; document.body.classList.toggle('menu-open', open); menuButton.setAttribute('aria-expanded', String(open)); });
    shade?.addEventListener('click', closeMenu);
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && menu && !menu.hidden) { closeMenu(); menuButton.focus(); }
        if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) && !document.activeElement.isContentEditable) { e.preventDefault(); document.querySelector('.global-search input')?.focus(); }
    });
    const topButton = document.querySelector('.back-top');
    window.addEventListener('scroll', () => { if (topButton) topButton.hidden = window.scrollY < 450; }, { passive: true });
    topButton?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }));
    // Handle empty / old image paths without changing a stored database value.
    function useFallback(img) { const fallback = img.dataset.fallback; if (fallback && img.src !== new URL(fallback, location.href).href) { img.src = fallback; } }
    document.addEventListener('error', e => { if (e.target instanceof HTMLImageElement) useFallback(e.target); }, true);
    document.querySelectorAll('img[data-fallback]').forEach(img => { if (img.complete && img.naturalWidth === 0) useFallback(img); });
    function pageButtons(host, page, pages, onChange) {
        host.replaceChildren();
        if (pages <= 1) return;
        const add = (text, target, disabled, current) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = text; b.disabled = disabled; b.setAttribute('aria-label', text === '‹' ? 'Trang trước' : text === '›' ? 'Trang sau' : 'Trang ' + text); if (current) b.setAttribute('aria-current', 'page'); b.addEventListener('click', () => onChange(target)); host.append(b); };
        add('‹', page - 1, page === 1, false);
        const start = Math.max(1, Math.min(page - 2, pages - 4));
        for (let p = start; p <= Math.min(pages, start + 4); p++) add(String(p), p, false, p === page);
        add('›', page + 1, page === pages, false);
    }
    document.querySelectorAll('[data-catalog]').forEach(panel => {
        const items = Array.from(panel.querySelectorAll(panel.dataset.item || '.product-card'));
        const parent = panel.querySelector('.product-grid, .staff-grid');
        const search = panel.querySelector('[data-search]');
        const category = panel.querySelector('[data-category]');
        const sort = panel.querySelector('[data-sort]');
        const count = panel.querySelector('[data-result-count]');
        const empty = panel.querySelector('[data-empty]');
        const pager = panel.querySelector('[data-pagination]');
        const staff = !!panel.dataset.item;
        const pageSize = 12;
        let page = 1;
        function restore() {
            const params = new URLSearchParams(location.search);
            search.value = params.get('q') || '';
            if (category) category.value = params.get('category') || '';
            if (sort) sort.value = params.get('sort') || 'default';
            const requested = Number(params.get('page'));
            page = Number.isSafeInteger(requested) && requested > 0 ? requested : 1;
        }
        restore();
        function remember() {
            const url = new URL(location.href);
            for (const [key, value] of [['q',search.value.trim()],['category',category?.value || ''],['sort',sort?.value === 'default' ? '' : sort?.value || ''],['page',page > 1 ? String(page) : '']]) {
                if (value) url.searchParams.set(key,value); else url.searchParams.delete(key);
            }
            history.replaceState(null,'',url.pathname+url.search+url.hash);
            panel.querySelectorAll('input[name="returnUrl"]').forEach(input => input.value = url.pathname+url.search);
            panel.querySelectorAll('a[data-product-detail]').forEach(link => {
                const target = new URL(link.href,location.href);
                target.searchParams.set('returnUrl',url.pathname+url.search);
                link.href = target.pathname+target.search;
            });
        }
        const searchable = new Map(items.map(item => [item, norm(staff ? item.textContent + ' ' + item.dataset.category : [item.dataset.name,item.dataset.code,item.dataset.category].join(' '))]));
        function draw() {
            const term = norm(search.value); const group = norm(category?.value || '');
            let found = items.filter(item => (!term || searchable.get(item).includes(term)) && (!group || norm(item.dataset.category) === group));
            const order = sort?.value || 'default';
            if (order === 'price-up' || order === 'price-down') found.sort((a, b) => (Number(a.dataset.price) - Number(b.dataset.price)) * (order === 'price-up' ? 1 : -1));
            else if (order === 'name') found.sort((a, b) => a.dataset.name.localeCompare(b.dataset.name, 'vi'));
            const pages = Math.max(1, Math.ceil(found.length / pageSize)); page = Math.max(1, Math.min(page, pages));
            items.forEach(item => { item.hidden = true; });
            found.forEach((item, index) => { parent.append(item); item.hidden = index < (page - 1) * pageSize || index >= page * pageSize; });
            count.textContent = found.length + (staff ? ' nhân viên' : ' sản phẩm') + (term || group ? ' phù hợp' : '');
            empty.hidden = found.length !== 0;
            pageButtons(pager, page, pages, p => { page = p; draw(); panel.scrollIntoView({ block: 'start' }); });
            remember();
        }
        search.addEventListener('input', () => { page = 1; draw(); });
        window.addEventListener('popstate', () => { restore(); draw(); });
        category?.addEventListener('change', () => { page = 1; draw(); });
        sort?.addEventListener('change', () => { page = 1; draw(); });
        panel.querySelectorAll('[data-reset]').forEach(b => b.addEventListener('click', () => { search.value = ''; if (category) category.value = ''; if (sort) sort.value = 'default'; page = 1; history.replaceState(null, '', location.pathname); draw(); search.focus(); }));
        draw();
    });
    document.querySelectorAll('table[data-manage-table]').forEach(table => {
        const panel = table.closest('.table-panel'); const rows = Array.from(table.tBodies[0]?.rows || []);
        const search = panel.querySelector('[data-table-search]'); const count = panel.querySelector('[data-table-count]');
        const empty = panel.querySelector('[data-table-empty]'); const pager = panel.querySelector('[data-table-pagination]');
        const texts = new Map(rows.map(r => [r, norm(r.textContent)])); let page = 1;
        rows.forEach(row => { const last = row.lastElementChild; if (last && last.querySelector('a')) { const group = document.createElement('div'); group.className = 'row-actions'; while (last.firstChild) group.append(last.firstChild); last.append(group); } });
        function draw() { const term = norm(search.value); const found = rows.filter(r => !term || texts.get(r).includes(term)); const pages = Math.max(1, Math.ceil(found.length / 10)); page = Math.max(1, Math.min(page, pages)); rows.forEach(r => { r.hidden = true; }); found.slice((page - 1) * 10, page * 10).forEach(r => { r.hidden = false; }); count.textContent = found.length + ' bản ghi'; empty.hidden = !!found.length; pageButtons(pager, page, pages, p => { page = p; draw(); }); }
        search.addEventListener('input', () => { page = 1; draw(); });
        window.addEventListener('popstate', () => { restore(); draw(); }); draw();
    });
    document.querySelectorAll('[data-image-field]').forEach(field => {
        const input = field.querySelector('input'); const preview = field.querySelector('[data-image-preview]');
        const resolve = value => { const s = value.trim(); if (!s) return preview.dataset.fallback; if (/^https?:\/\//i.test(s)) return s; const base = field.dataset.base || '/'; return base + s.replace(/^~?\//, ''); };
        const update = () => { preview.src = resolve(input.value); field.querySelectorAll('[data-image-option]').forEach(b => b.setAttribute('aria-pressed', String(input.value === b.dataset.imageOption))); };
        input.addEventListener('input', update);
        field.querySelectorAll('[data-image-option]').forEach(b => b.addEventListener('click', () => { input.value = b.dataset.imageOption; input.dispatchEvent(new Event('input', { bubbles: true })); }));
        update();
    });
})();
