(() => {
 'use strict';
 document.querySelectorAll('[data-step]').forEach(button=>button.addEventListener('click',()=>{
  const form=button.closest('form');const input=form.querySelector('input[name="quantity"]');
  input.value=String(Math.max(1,Math.min(99,Number(input.value||1)+Number(button.dataset.step))));
  form.requestSubmit();
 }));
 document.querySelectorAll('[data-password-toggle]').forEach(button=>button.addEventListener('click',()=>{
  const input=button.parentElement.querySelector('input');const show=input.type==='password';input.type=show?'text':'password';button.setAttribute('aria-pressed',String(show));button.setAttribute('aria-label',show?'Ẩn mật khẩu':'Hiện mật khẩu');
 }));
 const province=document.querySelector('[data-province]');
 const ward=document.querySelector('[data-ward]');
 if(province && ward) {
  const options=Array.from(ward.querySelectorAll('option[data-province-id]')).map(option=>option.cloneNode(true));
  const selected=options.find(option=>option.value===ward.value);
  province.value=selected?.dataset.provinceId || '';
  province.required=true;
  document.querySelector('[data-province-field]').hidden=false;
  function filterWards(keep) {
   const old=keep?ward.value:'';
   ward.replaceChildren(new Option(province.value?'Chọn xã / phường':'Chọn tỉnh / thành phố trước',''));
   options.filter(option=>option.dataset.provinceId===province.value).forEach(option=>ward.append(option.cloneNode(true)));
   ward.value=old;
   if(ward.selectedIndex<0) ward.selectedIndex=0;
   ward.disabled=!province.value;
  }
  province.addEventListener('change',()=>filterWards(false));
  filterWards(true);
 }
 document.querySelectorAll('[data-copy-receipt]').forEach(button=>button.addEventListener('click',async()=>{
  const input=document.getElementById('receipt-key');
  try { await navigator.clipboard.writeText(input.value);button.textContent='Đã sao chép'; }
  catch { input.focus();input.select();button.textContent='Hãy sao chép mã đang chọn'; }
 }));
 document.querySelectorAll('[data-print-receipt]').forEach(button=>button.addEventListener('click',()=>window.print()));
 document.querySelectorAll('[data-checkout-form]').forEach(form=>form.addEventListener('submit',()=>{
  // Do not disable when unobtrusive validation rejects the form.
  if(!form.checkValidity() || (window.jQuery && !window.jQuery(form).valid())) return;
  const button=form.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Đang lưu đơn hàng...';
 }));
})();
