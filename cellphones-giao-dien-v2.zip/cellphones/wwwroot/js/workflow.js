(() => {
 'use strict';
 const toggle=document.querySelector('[data-admin-menu]');
 const sidebar=document.getElementById('admin-navigation');
 function closeNavigation() { if(!toggle||!sidebar)return; sidebar.classList.remove('mobile-open');toggle.setAttribute('aria-expanded','false'); }
 toggle?.addEventListener('click',()=>{const open=sidebar.classList.toggle('mobile-open');toggle.setAttribute('aria-expanded',String(open));});
 document.addEventListener('keydown',e=>{if(e.key==='Escape' && toggle?.getAttribute('aria-expanded')==='true'){closeNavigation();toggle.focus();}});
 matchMedia('(min-width: 901px)').addEventListener('change',closeNavigation);
 document.querySelectorAll('[data-confirm-clear]').forEach(form=>form.addEventListener('submit',event=>{
  if(!window.confirm('Xóa tất cả sản phẩm trong giỏ hàng?'))event.preventDefault();
 }));
 const errors=document.querySelector('[data-order-errors]');
 if(errors?.textContent.trim()) { errors.focus();errors.scrollIntoView({block:'center',behavior:'auto'}); }
 document.querySelectorAll('[data-login-form]').forEach(form=>form.addEventListener('submit',()=>{
  if(!form.checkValidity() || (window.jQuery && !window.jQuery(form).valid()))return;
  const button=form.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Đang đăng nhập…';
 }));
 // Browsers may restore a page from their back/forward cache with an old disabled button.
 window.addEventListener('pageshow',e=>{if(e.persisted)document.querySelectorAll('[data-login-form] button[type="submit"]').forEach(button=>{button.disabled=false;button.textContent='Đăng nhập';});});
})();
