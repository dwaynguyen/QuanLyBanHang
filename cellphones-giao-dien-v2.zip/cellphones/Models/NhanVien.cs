﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class NhanVien
    {
        [Key]
        [Display(Name = "Mã nhân viên")]
        public short MaNV { get; set; }

        [Display(Name = "Họ và tên đệm")]
        [Required(ErrorMessage = "Vui lòng nhập họ và tên đệm")]
        [StringLength(50)]
        public string HoNV { get; set; } = string.Empty;

        [Display(Name = "Tên nhân viên")]
        [Required(ErrorMessage = "Vui lòng nhập tên nhân viên")]
        [StringLength(20)]
        public string TenNV { get; set; } = string.Empty;

        [Display(Name = "Điện thoại")]
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        [StringLength(15)]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        public string DienThoai { get; set; } = string.Empty;

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Vui lòng nhập email")]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Tên đăng nhập")]
        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        [StringLength(50)]
        public string TenDN { get; set; } = string.Empty;

        [Display(Name = "Mật khẩu")]
        [DataType(DataType.Password)]
        [StringLength(255)]
        public string? MatKhau { get; set; }

        [Display(Name = "Ảnh nhân viên")]
        [StringLength(255)]
        public string? AnhNV { get; set; }

        [Display(Name = "Phòng ban")]
        public byte MaPB { get; set; }
    }
}