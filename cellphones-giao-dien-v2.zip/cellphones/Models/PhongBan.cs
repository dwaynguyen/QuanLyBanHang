﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class PhongBan
    {
        [Key]
        [Display(Name = "Mã phòng ban")]
        public byte MaPB { get; set; }

        [Display(Name = "Tên phòng ban")]
        [Required(ErrorMessage = "Vui lòng nhập tên phòng ban")]
        [StringLength(50)]
        public string TenPB { get; set; } = string.Empty;
    }
}