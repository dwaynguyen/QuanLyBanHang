﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class PhanQuyen
    {
        [Display(Name = "Quyền")]
        public byte MaQuyen { get; set; }

        [Display(Name = "Nhân viên")]
        public short MaNV { get; set; }
    }
}