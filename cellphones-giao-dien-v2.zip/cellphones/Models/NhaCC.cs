﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class NhaCC
    {
        [Key]
        [Display(Name = "Mã nhà cung cấp")]
        public short MaNCC { get; set; }

        [Display(Name = "Tên nhà cung cấp")]
        [Required(ErrorMessage = "Vui lòng nhập tên nhà cung cấp")]
        [StringLength(100)]
        public string TenNCC { get; set; } = string.Empty;

        [Display(Name = "Điện thoại")]
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        [StringLength(15)]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        public string DienThoai { get; set; } = string.Empty;

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Vui lòng nhập email")]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Địa chỉ")]
        [Required(ErrorMessage = "Vui lòng nhập địa chỉ")]
        [StringLength(255)]
        public string DiaChi { get; set; } = string.Empty;

        [Display(Name = "Xã/phường")]
        public short MaXP { get; set; }
    }
}