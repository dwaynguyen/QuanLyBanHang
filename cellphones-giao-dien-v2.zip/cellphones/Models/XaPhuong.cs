﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class XaPhuong
    {
        [Key]
        public short MaXP { get; set; }

        [Display(Name = "Tên xã/phường")]
        [Required(ErrorMessage = "Vui lòng nhập tên xã/phường")]
        [StringLength(50)]
        public string TenXP { get; set; } = string.Empty;

        [Display(Name = "Tỉnh")]
        public byte MaTinh { get; set; }
    }
}
