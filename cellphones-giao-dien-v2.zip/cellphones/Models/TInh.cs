﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class Tinh
    {
        [Key]
        public byte MaTinh { get; set; }

        [Display(Name = "Tên tỉnh")]
        [Required(ErrorMessage = "Vui lòng nhập tên tỉnh")]
        [StringLength(50)]
        public string TenTinh { get; set; }
    }
}
