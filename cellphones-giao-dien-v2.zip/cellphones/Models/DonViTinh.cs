﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class DonViTinh
    {
        [Key]
        [Display(Name = "Mã đơn vị tính")]
        public byte MaDVT { get; set; }

        [Display(Name = "Tên đơn vị tính")]
        [Required(ErrorMessage = "Vui lòng nhập tên đơn vị tính")]
        [StringLength(20)]
        public string TenDVT { get; set; } = string.Empty;
    }
}