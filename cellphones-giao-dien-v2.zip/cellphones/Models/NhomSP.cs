using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class NhomSP
    {
        [Key]
        public byte MaNSP { get; set; }

        [Display(Name = "Tên nhóm sản phẩm")]
        [Required(ErrorMessage = "Vui lòng nhập tên nhóm sản phẩm")]
        [StringLength(45)]
        public string TenNSP { get; set; }
    }
}
