﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cellphones.Models
{
    public class CTMH
    {
        [Display(Name = "Đơn mua hàng")]
        public int MaDMH { get; set; }

        [Display(Name = "Sản phẩm")]
        [Required(ErrorMessage = "Vui lòng chọn sản phẩm")]
        [StringLength(9)]
        public string MaSP { get; set; } = string.Empty;

        [Display(Name = "Số lượng mua")]
        [Range(1, int.MaxValue,
            ErrorMessage = "Số lượng mua phải lớn hơn 0")]
        public int SLM { get; set; }

        [Display(Name = "Đơn giá mua")]
        [Column(TypeName = "money")]
        [DataType(DataType.Currency)]
        public decimal DGM { get; set; }
    }
}