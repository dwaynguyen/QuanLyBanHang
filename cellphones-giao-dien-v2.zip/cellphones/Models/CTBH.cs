﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cellphones.Models
{
    public class CTBH
    {
        [Display(Name = "Đơn bán hàng")]
        public int MaDBH { get; set; }

        [Display(Name = "Sản phẩm")]
        [Required(ErrorMessage = "Vui lòng chọn sản phẩm")]
        [StringLength(9)]
        public string MaSP { get; set; } = string.Empty;

        [Display(Name = "Số lượng bán")]
        [Range(1, int.MaxValue,
            ErrorMessage = "Số lượng bán phải lớn hơn 0")]
        public int SLB { get; set; }

        [Display(Name = "Đơn giá bán")]
        [Column(TypeName = "money")]
        [DataType(DataType.Currency)]
        public decimal DGB { get; set; }
    }
}