﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class DonMH
    {
        [Key]
        [Display(Name = "Mã đơn mua hàng")]
        public int MaDMH { get; set; }

        [Display(Name = "Ngày đặt")]
        [Required(ErrorMessage = "Vui lòng nhập ngày đặt")]
        [DataType(DataType.Date)]
        public DateTime NgayDat { get; set; }

        [Display(Name = "Ngày giao")]
        [DataType(DataType.Date)]
        public DateTime? NgayGiao { get; set; }

        [Display(Name = "Nhân viên")]
        public short MaNV { get; set; }

        [Display(Name = "Nhà cung cấp")]
        public short MaNCC { get; set; }
    }
}