using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cellphones.Models
{
    public class LoaiSP
    {
        [Key]
        public short MaLSP { get; set; }
        
        [Display(Name = "Tên loại sản phẩm")]
        [Required(ErrorMessage = "Vui lòng nhập tên loại sản phẩm")]
        [StringLength(50)]
        public string TenLSP { get; set; }

        [Display(Name = "Nhóm sản phẩm")]
        public byte MaNSP { get; set; }
        [ForeignKey("MaNSP")]// khai báo khóa ngoại
        public virtual NhomSP NhomSP { get; set; }
    }
}
