﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class Quyen
    {
        [Key]
        [Display(Name = "Mã quyền")]
        public byte MaQuyen { get; set; }

        [Display(Name = "Tên quyền")]
        [Required(ErrorMessage = "Vui lòng nhập tên quyền")]
        [StringLength(50)]
        public string TenQuyen { get; set; } = string.Empty;

        [Display(Name = "Mô tả")]
        [StringLength(255)]
        public string? MoTa { get; set; }
    }
}