﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cellphones.Models
{
    public class SanPham
    {
        [Key]
        [Display(Name = "Mã sản phẩm")]
        [Required(ErrorMessage = "Vui lòng nhập mã sản phẩm")]
        [StringLength(9)]
        public string MaSP { get; set; } = string.Empty;

        [Display(Name = "Tên sản phẩm")]
        [Required(ErrorMessage = "Vui lòng nhập tên sản phẩm")]
        [StringLength(50)]
        public string TenSP { get; set; } = string.Empty;

        [Display(Name = "Đơn giá")]
        [Column(TypeName = "money")]
        [DataType(DataType.Currency)]
        public decimal DonGia { get; set; }

        [Display(Name = "Ảnh sản phẩm")]
        [StringLength(100)]
        public string AnhSP { get; set; }

        [Display(Name = "Mô tả chi tiết")]
        public string MoTaCT { get; set; }

        [Display(Name = "Loại sản phẩm")]
        public short MaLSP { get; set; }

        [Display(Name = "Đơn vị tính")]
        public byte MaDVT { get; set; }
    }
}