﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class DonBH
    {
        [Key]
        [Display(Name = "Mã đơn bán hàng")]
        public int MaDBH { get; set; }

        [Display(Name = "Ngày đặt")]
        [Required(ErrorMessage = "Vui lòng nhập ngày đặt")]
        [DataType(DataType.Date)]
        public DateTime NgayDat { get; set; }

        [Display(Name = "Ngày giao")]
        [DataType(DataType.Date)]
        public DateTime? NgayGiao { get; set; }

        [Display(Name = "Địa chỉ giao hàng")]
        [Required(ErrorMessage = "Vui lòng nhập địa chỉ giao hàng")]
        [StringLength(255)]
        public string DCGH { get; set; } = string.Empty;

        [Display(Name = "Xã/phường")]
        public short MaXP { get; set; }

        [Display(Name = "Nhân viên")]
        public short MaNV { get; set; }

        [Display(Name = "Khách hàng")]
        public int MaKH { get; set; }
    }
}