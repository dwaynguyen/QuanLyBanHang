﻿using System.ComponentModel.DataAnnotations;

namespace cellphones.Models
{
    public class KhachHang
    {
        [Key]
        [Display(Name = "Mã khách hàng")]
        public int MaKH { get; set; }

        [Display(Name = "Họ và tên đệm")]
        [Required(ErrorMessage = "Vui lòng nhập họ và tên đệm")]
        [StringLength(50)]
        public string HoKH { get; set; } = string.Empty;

        [Display(Name = "Tên khách hàng")]
        [Required(ErrorMessage = "Vui lòng nhập tên khách hàng")]
        [StringLength(20)]
        public string TenKH { get; set; } = string.Empty;

        [Display(Name = "Điện thoại")]
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        [StringLength(15)]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        public string DienThoai { get; set; } = string.Empty;

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Vui lòng nhập email")]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Địa chỉ")]
        [Required(ErrorMessage = "Vui lòng nhập địa chỉ")]
        [StringLength(255)]
        public string DiaChi { get; set; } = string.Empty;

        [Display(Name = "Xã/phường")]
        public short MaXP { get; set; }

        [Display(Name = "Tên đăng nhập")]
        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        [StringLength(50)]
        public string TenDN { get; set; } = string.Empty;

        [Display(Name = "Mật khẩu")]
        [DataType(DataType.Password)]
        [StringLength(255)]
        public string MatKhau { get; set; }
    }
}