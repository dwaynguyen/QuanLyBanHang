﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class PhanQuyensController : Controller
    {
        private readonly AppDbContext _context;

        public PhanQuyensController(AppDbContext context)
        {
            _context = context;
        }

        // Chuẩn bị hai danh sách chọn cho form thêm và sửa.
        private void LoadDanhSach(byte? maQuyen = null, short? maNV = null)
        {
            ViewBag.MaQuyen = new SelectList(
                _context.Quyen_DanhSach(),
                "MaQuyen", "TenQuyen", maQuyen);

            var nhanViens = _context.NhanVien_DanhSach()
                .Select(nv => new
                {
                    nv.MaNV,
                    HoTen = nv.MaNV + " - " + nv.HoNV + " " + nv.TenNV
                })
                .ToList();

            ViewBag.MaNV = new SelectList(
                nhanViens, "MaNV", "HoTen", maNV);
        }

        // GET: PhanQuyens
        public IActionResult Index()
        {
            return View(_context.PhanQuyen_DanhSach());
        }

        // GET: PhanQuyens/Details?maQuyen=1&maNV=2
        public IActionResult Details(byte? maQuyen, short? maNV)
        {
            if (maQuyen == null || maNV == null)
                return NotFound();

            var phanQuyen = _context.PhanQuyen_ChiTiet(
                maQuyen.Value, maNV.Value);

            if (phanQuyen == null)
                return NotFound();

            return View(phanQuyen);
        }

        // GET: PhanQuyens/Create
        public IActionResult Create()
        {
            LoadDanhSach();
            return View();
        }

        // POST: PhanQuyens/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaQuyen,MaNV")] PhanQuyen phanQuyen)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.PhanQuyen_Them(phanQuyen);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex)
                    when (ex.Number == 2627 || ex.Number == 2601)
                {
                    ModelState.AddModelError(string.Empty,
                        "Nhân viên này đã được gán quyền đã chọn.");
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Quyền hoặc nhân viên không tồn tại.");
                }
            }

            LoadDanhSach(phanQuyen.MaQuyen, phanQuyen.MaNV);
            return View(phanQuyen);
        }

        // GET: PhanQuyens/Edit?maQuyen=1&maNV=2
        public IActionResult Edit(byte? maQuyen, short? maNV)
        {
            if (maQuyen == null || maNV == null)
                return NotFound();

            var phanQuyen = _context.PhanQuyen_ChiTiet(
                maQuyen.Value, maNV.Value);

            if (phanQuyen == null)
                return NotFound();

            ViewBag.MaQuyenCu = phanQuyen.MaQuyen;
            ViewBag.MaNVCu = phanQuyen.MaNV;

            LoadDanhSach(phanQuyen.MaQuyen, phanQuyen.MaNV);

            return View(phanQuyen);
        }

        // POST: PhanQuyens/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            byte? maQuyenCu,
            short? maNVCu,
            [Bind("MaQuyen,MaNV")] PhanQuyen phanQuyen)
        {
            if (maQuyenCu == null || maNVCu == null)
                return NotFound();

            var phanQuyenCu = _context.PhanQuyen_ChiTiet(
                maQuyenCu.Value, maNVCu.Value);

            if (phanQuyenCu == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.PhanQuyen_Sua(
                        maQuyenCu.Value, maNVCu.Value, phanQuyen);

                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex)
                    when (ex.Number == 2627 || ex.Number == 2601)
                {
                    ModelState.AddModelError(string.Empty,
                        "Nhân viên này đã được gán quyền đã chọn.");
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Quyền hoặc nhân viên không tồn tại.");
                }
            }

            ViewBag.MaQuyenCu = maQuyenCu.Value;
            ViewBag.MaNVCu = maNVCu.Value;

            LoadDanhSach(phanQuyen.MaQuyen, phanQuyen.MaNV);

            return View(phanQuyen);
        }

        // GET: PhanQuyens/Delete?maQuyen=1&maNV=2
        public IActionResult Delete(byte? maQuyen, short? maNV)
        {
            if (maQuyen == null || maNV == null)
                return NotFound();

            var phanQuyen = _context.PhanQuyen_ChiTiet(
                maQuyen.Value, maNV.Value);

            if (phanQuyen == null)
                return NotFound();

            return View(phanQuyen);
        }

        // POST: PhanQuyens/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte? maQuyen, short? maNV)
        {
            if (maQuyen == null || maNV == null)
                return NotFound();

            var phanQuyen = _context.PhanQuyen_ChiTiet(
                maQuyen.Value, maNV.Value);

            if (phanQuyen == null)
                return NotFound();

            _context.PhanQuyen_Xoa(maQuyen.Value, maNV.Value);

            return RedirectToAction(nameof(Index));
        }
    }
}