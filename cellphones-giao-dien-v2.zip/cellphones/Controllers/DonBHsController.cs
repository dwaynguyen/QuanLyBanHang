﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;
using cellphones.Services;

namespace cellphones.Controllers
{
    public class DonBHsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly OrderReceiptService _receipts;

        public DonBHsController(AppDbContext context, OrderReceiptService receipts)
        {
            _context = context;
            _receipts = receipts;
        }

        private void LoadDanhSach(
            short? maXP = null,
            short? maNV = null,
            int? maKH = null)
        {
            ViewBag.MaXP = new SelectList(
                _context.XaPhuong_DanhSach(),
                "MaXP", "TenXP", maXP);

            var nhanViens = _context.NhanVien_DanhSach()
                .Select(nv => new
                {
                    nv.MaNV,
                    HoTen = nv.HoNV + " " + nv.TenNV
                })
                .ToList();

            ViewBag.MaNV = new SelectList(
                nhanViens, "MaNV", "HoTen", maNV);

            var khachHangs = _context.KhachHang_DanhSach()
                .Select(kh => new
                {
                    kh.MaKH,
                    HoTen = kh.HoKH + " " + kh.TenKH
                })
                .ToList();

            ViewBag.MaKH = new SelectList(
                khachHangs, "MaKH", "HoTen", maKH);
        }

        // GET: DonBHs
        public IActionResult Index()
        {
            return View(_context.DonBH_DanhSach());
        }

        // GET: DonBHs/Details/1
        public IActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();

            var donBH = _context.DonBH_ChiTiet(id.Value);

            if (donBH == null)
                return NotFound();

            var page = _receipts.Details(id.Value);
            if(page==null) return NotFound();
            Response.Headers["Cache-Control"]="no-store";
            ViewBag.ReceiptKey=_receipts.CreateKey(page.Order.MaDBH,page.Order.MaKH,page.Order.NgayDat);
            return View(page);
        }

        // GET: DonBHs/Create
        public IActionResult Create()
        {
            LoadDanhSach();

            return View(new DonBH
            {
                NgayDat = DateTime.Today
            });
        }

        // POST: DonBHs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("NgayDat,NgayGiao,DCGH,MaXP,MaNV,MaKH")] DonBH donBH)
        {
            if (donBH.NgayGiao.HasValue && donBH.NgayGiao.Value.Date < donBH.NgayDat.Date)
                ModelState.AddModelError(nameof(donBH.NgayGiao), "Ngày giao không được trước ngày đặt.");
            if (ModelState.IsValid)
            {
                try
                {
                    _context.DonBH_Them(donBH);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Xã/phường, nhân viên hoặc khách hàng không tồn tại.");
                }
            }

            LoadDanhSach(donBH.MaXP, donBH.MaNV, donBH.MaKH);
            return View(donBH);
        }

        // GET: DonBHs/Edit/1
        public IActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var donBH = _context.DonBH_ChiTiet(id.Value);

            if (donBH == null)
                return NotFound();

            LoadDanhSach(donBH.MaXP, donBH.MaNV, donBH.MaKH);
            return View(donBH);
        }

        // POST: DonBHs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            int id,
            [Bind("MaDBH,NgayDat,NgayGiao,DCGH,MaXP,MaNV,MaKH")]
            DonBH donBH)
        {
            if (id != donBH.MaDBH)
                return NotFound();

            if (_context.DonBH_ChiTiet(id) == null)
                return NotFound();

            if (donBH.NgayGiao.HasValue && donBH.NgayGiao.Value.Date < donBH.NgayDat.Date)
                ModelState.AddModelError(nameof(donBH.NgayGiao), "Ngày giao không được trước ngày đặt.");
            if (ModelState.IsValid)
            {
                try
                {
                    _context.DonBH_Sua(donBH);
                    TempData["OrderMessage"]="Đã cập nhật thông tin đơn hàng.";
                    return RedirectToAction(nameof(Details),new { id=donBH.MaDBH });
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Xã/phường, nhân viên hoặc khách hàng không tồn tại.");
                }
            }

            LoadDanhSach(donBH.MaXP, donBH.MaNV, donBH.MaKH);
            return View(donBH);
        }

        // GET: DonBHs/Delete/1
        public IActionResult Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var donBH = _context.DonBH_ChiTiet(id.Value);

            if (donBH == null)
                return NotFound();

            return View(donBH);
        }

        // POST: DonBHs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var donBH = _context.DonBH_ChiTiet(id);

            if (donBH == null)
                return NotFound();

            try
            {
                _context.DonBH_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa đơn bán hàng vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), donBH);
            }
        }
    }
}