﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class XaPhuongsController : Controller
    {
        private readonly AppDbContext _context;

        public XaPhuongsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: XaPhuongs
        public IActionResult Index()
        {
            return View(_context.XaPhuong_DanhSach());
        }

        // GET: XaPhuongs/Details/1
        public IActionResult Details(short? id)
        {
            if (id == null)
                return NotFound();

            var xaPhuong = _context.XaPhuong_ChiTiet(id.Value);

            if (xaPhuong == null)
                return NotFound();

            return View(xaPhuong);
        }

        // GET: XaPhuongs/Create
        public IActionResult Create()
        {
            ViewBag.MaTinh = new SelectList(
                _context.Tinh_DanhSach(), "MaTinh", "TenTinh");

            return View();
        }

        // POST: XaPhuongs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaXP,TenXP,MaTinh")] XaPhuong xaPhuong)
        {
            if (ModelState.IsValid)
            {
                _context.XaPhuong_Them(xaPhuong);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.MaTinh = new SelectList(
                _context.Tinh_DanhSach(), "MaTinh", "TenTinh",
                xaPhuong.MaTinh);

            return View(xaPhuong);
        }

        // GET: XaPhuongs/Edit/1
        public IActionResult Edit(short? id)
        {
            if (id == null)
                return NotFound();

            var xaPhuong = _context.XaPhuong_ChiTiet(id.Value);

            if (xaPhuong == null)
                return NotFound();

            ViewBag.MaTinh = new SelectList(
                _context.Tinh_DanhSach(), "MaTinh", "TenTinh",
                xaPhuong.MaTinh);

            return View(xaPhuong);
        }

        // POST: XaPhuongs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            short id,
            [Bind("MaXP,TenXP,MaTinh")] XaPhuong xaPhuong)
        {
            if (id != xaPhuong.MaXP)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.XaPhuong_Sua(xaPhuong);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.MaTinh = new SelectList(
                _context.Tinh_DanhSach(), "MaTinh", "TenTinh",
                xaPhuong.MaTinh);

            return View(xaPhuong);
        }

        // GET: XaPhuongs/Delete/1
        public IActionResult Delete(short? id)
        {
            if (id == null)
                return NotFound();

            var xaPhuong = _context.XaPhuong_ChiTiet(id.Value);

            if (xaPhuong == null)
                return NotFound();

            return View(xaPhuong);
        }

        // POST: XaPhuongs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            try
            {
                _context.XaPhuong_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                var xaPhuong = _context.XaPhuong_ChiTiet(id);

                if (xaPhuong == null)
                    return NotFound();

                ModelState.AddModelError(string.Empty,
                    "Không thể xóa xã/phường này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), xaPhuong);
            }
        }
    }
}