﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class QuyensController : Controller
    {
        private readonly AppDbContext _context;

        public QuyensController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Quyens
        public IActionResult Index()
        {
            return View(_context.Quyen_DanhSach());
        }

        // GET: Quyens/Details/1
        public IActionResult Details(byte? id)
        {
            if (id == null)
                return NotFound();

            var quyen = _context.Quyen_ChiTiet(id.Value);

            if (quyen == null)
                return NotFound();

            return View(quyen);
        }

        // GET: Quyens/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Quyens/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaQuyen,TenQuyen,MoTa")] Quyen quyen)
        {
            if (ModelState.IsValid)
            {
                _context.Quyen_Them(quyen);
                return RedirectToAction(nameof(Index));
            }

            return View(quyen);
        }

        // GET: Quyens/Edit/1
        public IActionResult Edit(byte? id)
        {
            if (id == null)
                return NotFound();

            var quyen = _context.Quyen_ChiTiet(id.Value);

            if (quyen == null)
                return NotFound();

            return View(quyen);
        }

        // POST: Quyens/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            byte id,
            [Bind("MaQuyen,TenQuyen,MoTa")] Quyen quyen)
        {
            if (id != quyen.MaQuyen)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.Quyen_Sua(quyen);
                return RedirectToAction(nameof(Index));
            }

            return View(quyen);
        }

        // GET: Quyens/Delete/1
        public IActionResult Delete(byte? id)
        {
            if (id == null)
                return NotFound();

            var quyen = _context.Quyen_ChiTiet(id.Value);

            if (quyen == null)
                return NotFound();

            return View(quyen);
        }

        // POST: Quyens/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte id)
        {
            try
            {
                _context.Quyen_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                var quyen = _context.Quyen_ChiTiet(id);

                if (quyen == null)
                    return NotFound();

                ModelState.AddModelError(string.Empty,
                    "Không thể xóa quyền này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), quyen);
            }
        }
    }
}