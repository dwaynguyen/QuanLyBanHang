﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class CTMHsController : Controller
    {
        private readonly AppDbContext _context;

        public CTMHsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadDanhSach(int? maDMH = null, string maSP = null)
        {
            ViewBag.MaDMH = new SelectList(
                _context.DonMH_DanhSach(),
                "MaDMH", "MaDMH", maDMH);

            var sanPhams = _context.SanPham_DanhSach()
                .Select(sp => new
                {
                    MaSP = sp.MaSP.TrimEnd(),
                    sp.TenSP
                })
                .ToList();

            ViewBag.MaSP = new SelectList(
                sanPhams, "MaSP", "TenSP", maSP?.TrimEnd());
        }

        // GET: CTMHs
        public IActionResult Index()
        {
            return View(_context.CTMH_DanhSach());
        }

        // GET: CTMHs/Details
        public IActionResult Details(int? maDMH, string maSP)
        {
            if (maDMH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctmh = _context.CTMH_ChiTiet(maDMH.Value, maSP);

            if (ctmh == null)
                return NotFound();

            return View(ctmh);
        }

        // GET: CTMHs/Create
        public IActionResult Create()
        {
            LoadDanhSach();
            return View();
        }

        // POST: CTMHs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaDMH,MaSP,SLM,DGM")] CTMH ctmh)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.CTMH_Them(ctmh);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex)
                    when (ex.Number == 2627 || ex.Number == 2601)
                {
                    ModelState.AddModelError(string.Empty,
                        "Sản phẩm này đã có trong đơn mua hàng.");
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Đơn mua hàng hoặc sản phẩm không tồn tại.");
                }
            }

            LoadDanhSach(ctmh.MaDMH, ctmh.MaSP);
            return View(ctmh);
        }

        // GET: CTMHs/Edit
        public IActionResult Edit(int? maDMH, string maSP)
        {
            if (maDMH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctmh = _context.CTMH_ChiTiet(maDMH.Value, maSP);

            if (ctmh == null)
                return NotFound();

            return View(ctmh);
        }

        // POST: CTMHs/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            [Bind("MaDMH,MaSP,SLM,DGM")] CTMH ctmh)
        {
            if (string.IsNullOrWhiteSpace(ctmh.MaSP))
                return NotFound();

            if (_context.CTMH_ChiTiet(ctmh.MaDMH, ctmh.MaSP) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.CTMH_Sua(ctmh);
                return RedirectToAction(nameof(Index));
            }

            return View(ctmh);
        }

        // GET: CTMHs/Delete
        public IActionResult Delete(int? maDMH, string maSP)
        {
            if (maDMH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctmh = _context.CTMH_ChiTiet(maDMH.Value, maSP);

            if (ctmh == null)
                return NotFound();

            return View(ctmh);
        }

        // POST: CTMHs/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int? maDMH, string maSP)
        {
            if (maDMH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctmh = _context.CTMH_ChiTiet(maDMH.Value, maSP);

            if (ctmh == null)
                return NotFound();

            try
            {
                _context.CTMH_Xoa(maDMH.Value, maSP);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa chi tiết mua hàng vì còn dữ liệu liên quan.");

                return View(nameof(Delete), ctmh);
            }
        }
    }
}