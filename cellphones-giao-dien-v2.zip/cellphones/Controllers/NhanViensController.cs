﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class NhanViensController : Controller
    {
        private readonly AppDbContext _context;

        public NhanViensController(AppDbContext context)
        {
            _context = context;
        }

        // GET: NhanViens
        public IActionResult Index()
        {
            var danhSach = _context.NhanVien_DanhSach();

            foreach (var nhanVien in danhSach)
            {
                nhanVien.MatKhau = null;
            }

            return View(danhSach);
        }

        // GET: NhanViens/Details/1
        public IActionResult Details(short? id)
        {
            if (id == null)
                return NotFound();

            var nhanVien = _context.NhanVien_ChiTiet(id.Value);

            if (nhanVien == null)
                return NotFound();

            nhanVien.MatKhau = null;

            return View(nhanVien);
        }

        // GET: NhanViens/Create
        public IActionResult Create()
        {
            ViewBag.MaPB = new SelectList(
                _context.PhongBan_DanhSach(), "MaPB", "TenPB");

            return View();
        }

        // POST: NhanViens/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("HoNV,TenNV,DienThoai,Email,TenDN,MatKhau,AnhNV,MaPB")]
            NhanVien nhanVien)
        {
            if (string.IsNullOrWhiteSpace(nhanVien.MatKhau))
            {
                ModelState.AddModelError(
                    "MatKhau", "Vui lòng nhập mật khẩu");
            }

            if (ModelState.IsValid)
            {
                if (_context.PhongBan_ChiTiet(nhanVien.MaPB) == null)
                {
                    ModelState.AddModelError(
                        "MaPB", "Phòng ban không tồn tại");
                }
            }

            if (ModelState.IsValid)
            {
                var hasher = new PasswordHasher<NhanVien>();

                nhanVien.MatKhau = hasher.HashPassword(
                    nhanVien, nhanVien.MatKhau!);

                _context.NhanVien_Them(nhanVien);

                return RedirectToAction(nameof(Index));
            }

            ViewBag.MaPB = new SelectList(
                _context.PhongBan_DanhSach(), "MaPB", "TenPB",
                nhanVien.MaPB);

            return View(nhanVien);
        }

        // GET: NhanViens/Edit/1
        public IActionResult Edit(short? id)
        {
            if (id == null)
                return NotFound();

            var nhanVien = _context.NhanVien_ChiTiet(id.Value);

            if (nhanVien == null)
                return NotFound();

            // Để trống ô mật khẩu khi mở trang sửa.
            nhanVien.MatKhau = null;

            ViewBag.MaPB = new SelectList(
                _context.PhongBan_DanhSach(), "MaPB", "TenPB",
                nhanVien.MaPB);

            return View(nhanVien);
        }

        // POST: NhanViens/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            short id,
            [Bind("MaNV,HoNV,TenNV,DienThoai,Email,TenDN,MatKhau,AnhNV,MaPB")]
            NhanVien nhanVien)
        {
            if (id != nhanVien.MaNV)
                return NotFound();

            if (_context.NhanVien_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                if (_context.PhongBan_ChiTiet(nhanVien.MaPB) == null)
                {
                    ModelState.AddModelError(
                        "MaPB", "Phòng ban không tồn tại");
                }
            }

            if (ModelState.IsValid)
            {
                if (!string.IsNullOrWhiteSpace(nhanVien.MatKhau))
                {
                    var hasher = new PasswordHasher<NhanVien>();

                    nhanVien.MatKhau = hasher.HashPassword(
                        nhanVien, nhanVien.MatKhau);
                }
                else
                {
                    // Truyền NULL để SQL giữ nguyên mật khẩu cũ.
                    nhanVien.MatKhau = null;
                }

                _context.NhanVien_Sua(nhanVien);

                return RedirectToAction(nameof(Index));
            }

            ViewBag.MaPB = new SelectList(
                _context.PhongBan_DanhSach(), "MaPB", "TenPB",
                nhanVien.MaPB);

            return View(nhanVien);
        }

        // GET: NhanViens/Delete/1
        public IActionResult Delete(short? id)
        {
            if (id == null)
                return NotFound();

            var nhanVien = _context.NhanVien_ChiTiet(id.Value);

            if (nhanVien == null)
                return NotFound();

            nhanVien.MatKhau = null;

            return View(nhanVien);
        }

        // POST: NhanViens/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            try
            {
                _context.NhanVien_Xoa(id);

                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                var nhanVien = _context.NhanVien_ChiTiet(id);

                if (nhanVien == null)
                    return NotFound();

                nhanVien.MatKhau = null;

                ModelState.AddModelError(string.Empty,
                    "Không thể xóa nhân viên này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), nhanVien);
            }
        }
    }
}