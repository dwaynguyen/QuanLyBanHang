﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class KhachHangsController : Controller
    {
        private readonly AppDbContext _context;

        public KhachHangsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadXaPhuong(short? maXP = null)
        {
            ViewBag.MaXP = new SelectList(
                _context.XaPhuong_DanhSach(),
                "MaXP", "TenXP", maXP);
        }

        // GET: KhachHangs
        public IActionResult Index()
        {
            var danhSach = _context.KhachHang_DanhSach();

            foreach (var khachHang in danhSach)
            {
                khachHang.MatKhau = null;
            }

            return View(danhSach);
        }

        // GET: KhachHangs/Details/1
        public IActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();

            var khachHang = _context.KhachHang_ChiTiet(id.Value);

            if (khachHang == null)
                return NotFound();

            khachHang.MatKhau = null;
            return View(khachHang);
        }

        // GET: KhachHangs/Create
        public IActionResult Create()
        {
            LoadXaPhuong();
            return View();
        }

        // POST: KhachHangs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("HoKH,TenKH,DienThoai,Email,DiaChi,MaXP,TenDN,MatKhau")]
            KhachHang khachHang)
        {
            if (string.IsNullOrWhiteSpace(khachHang.MatKhau))
            {
                ModelState.AddModelError("MatKhau",
                    "Vui lòng nhập mật khẩu.");
            }

            if (ModelState.IsValid)
            {
                var hasher = new PasswordHasher<KhachHang>();

                khachHang.MatKhau = hasher.HashPassword(
                    khachHang, khachHang.MatKhau);

                try
                {
                    _context.KhachHang_Them(khachHang);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError("MaXP",
                        "Xã/phường không tồn tại. Vui lòng chọn lại.");
                }
            }

            khachHang.MatKhau = null;
            LoadXaPhuong(khachHang.MaXP);
            return View(khachHang);
        }

        // GET: KhachHangs/Edit/1
        public IActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var khachHang = _context.KhachHang_ChiTiet(id.Value);

            if (khachHang == null)
                return NotFound();

            khachHang.MatKhau = null;
            LoadXaPhuong(khachHang.MaXP);
            return View(khachHang);
        }

        // POST: KhachHangs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            int id,
            [Bind("MaKH,HoKH,TenKH,DienThoai,Email,DiaChi,MaXP,TenDN,MatKhau")]
            KhachHang khachHang)
        {
            if (id != khachHang.MaKH)
                return NotFound();

            if (_context.KhachHang_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                if (string.IsNullOrWhiteSpace(khachHang.MatKhau))
                {
                    khachHang.MatKhau = null;
                }
                else
                {
                    var hasher = new PasswordHasher<KhachHang>();

                    khachHang.MatKhau = hasher.HashPassword(
                        khachHang, khachHang.MatKhau);
                }

                try
                {
                    _context.KhachHang_Sua(khachHang);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError("MaXP",
                        "Xã/phường không tồn tại. Vui lòng chọn lại.");
                }
            }

            khachHang.MatKhau = null;
            LoadXaPhuong(khachHang.MaXP);
            return View(khachHang);
        }

        // GET: KhachHangs/Delete/1
        public IActionResult Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var khachHang = _context.KhachHang_ChiTiet(id.Value);

            if (khachHang == null)
                return NotFound();

            khachHang.MatKhau = null;
            return View(khachHang);
        }

        // POST: KhachHangs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var khachHang = _context.KhachHang_ChiTiet(id);

            if (khachHang == null)
                return NotFound();

            try
            {
                _context.KhachHang_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa khách hàng vì vẫn còn dữ liệu liên quan.");

                khachHang.MatKhau = null;
                return View(nameof(Delete), khachHang);
            }
        }
    }
}