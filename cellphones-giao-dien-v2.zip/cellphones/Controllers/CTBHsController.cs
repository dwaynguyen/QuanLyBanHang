﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;
using cellphones.Services;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace cellphones.Controllers
{
    public class CTBHsController : Controller
    {
        private readonly AppDbContext _context;

        public CTBHsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadDanhSach(int? maDBH = null, string maSP = null)
        {
            ViewBag.MaDBH = new SelectList(
                _context.DonBH_DanhSach(),
                "MaDBH", "MaDBH", maDBH);

            var sanPhams = _context.SanPham_DanhSach()
                .Select(sp => new
                {
                    MaSP = sp.MaSP.TrimEnd(),
                    sp.TenSP
                })
                .ToList();

            ViewBag.MaSP = new SelectList(
                sanPhams, "MaSP", "TenSP", maSP?.TrimEnd());
        }

        // GET: CTBHs
        public IActionResult Index()
        {
            return View(_context.CTBH_DanhSach());
        }

        // GET: CTBHs/Details
        public IActionResult Details(int? maDBH, string maSP)
        {
            if (maDBH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctbh = _context.CTBH_ChiTiet(maDBH.Value, maSP);

            if (ctbh == null)
                return NotFound();

            return View(ctbh);
        }

        // GET: CTBHs/Create
        public IActionResult Create(int? maDBH)
        {
            LoadDanhSach(maDBH);
            return View(new CTBH { MaDBH=maDBH??0, SLB=1 });
        }

        // POST: CTBHs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("MaDBH,MaSP,SLB,DGB")] CTBH ctbh)
        {
            if(ctbh.DGB<=0) ModelState.AddModelError(nameof(ctbh.DGB),"Đơn giá bán phải lớn hơn 0.");
            if (ModelState.IsValid)
            {
                try
                {
                    await using var tx=await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
                    var available=await InventoryService.Available((SqlConnection)_context.Database.GetDbConnection(),(SqlTransaction)tx.GetDbTransaction(),ctbh.MaSP.Trim());
                    if(ctbh.SLB>available) throw new InvalidOperationException($"Chỉ còn {Math.Max(0,available)} sản phẩm có thể bán.");
                    _context.CTBH_Them(ctbh);
                    await tx.CommitAsync();
                    TempData["OrderMessage"]="Đã thêm sản phẩm vào đơn.";
                    return RedirectToAction("Details","DonBHs",new { id=ctbh.MaDBH });
                }
                catch (InvalidOperationException ex) { ModelState.AddModelError(string.Empty,ex.Message); }
                catch (SqlException ex)
                    when (ex.Number == 2627 || ex.Number == 2601)
                {
                    ModelState.AddModelError(string.Empty,
                        "Sản phẩm này đã có trong đơn bán hàng.");
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Đơn bán hàng hoặc sản phẩm không tồn tại.");
                }
            }

            LoadDanhSach(ctbh.MaDBH, ctbh.MaSP);
            return View(ctbh);
        }

        // GET: CTBHs/Edit
        public IActionResult Edit(int? maDBH, string maSP)
        {
            if (maDBH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctbh = _context.CTBH_ChiTiet(maDBH.Value, maSP);

            if (ctbh == null)
                return NotFound();

            return View(ctbh);
        }

        // POST: CTBHs/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            [Bind("MaDBH,MaSP,SLB,DGB")] CTBH ctbh)
        {
            if (string.IsNullOrWhiteSpace(ctbh.MaSP))
                return NotFound();

            if (_context.CTBH_ChiTiet(ctbh.MaDBH, ctbh.MaSP) == null)
                return NotFound();

            if(ctbh.DGB<=0) ModelState.AddModelError(nameof(ctbh.DGB),"Đơn giá bán phải lớn hơn 0.");
            if (ModelState.IsValid)
            {
                try
                {
                    await using var tx=await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
                    var available=await InventoryService.Available((SqlConnection)_context.Database.GetDbConnection(),(SqlTransaction)tx.GetDbTransaction(),ctbh.MaSP.Trim());
                    var connection=(SqlConnection)_context.Database.GetDbConnection();
                    var transaction=(SqlTransaction)tx.GetDbTransaction();
                    var table=await SqlTables.Resolve(connection,transaction,"CTBH");
                    await using var command=new SqlCommand($"SELECT SLB FROM {table} WHERE MaDBH=@order AND MaSP=@product",connection,transaction);
                    command.Parameters.AddWithValue("@order",ctbh.MaDBH);command.Parameters.AddWithValue("@product",ctbh.MaSP);
                    var previous=await command.ExecuteScalarAsync();
                    if(previous==null || previous is DBNull) return NotFound();
                    var previousQuantity=Convert.ToInt32(previous);
                    if(ctbh.SLB>available+previousQuantity) throw new InvalidOperationException($"Tối đa {Math.Max(0,available+previousQuantity)} sản phẩm cho dòng này.");
                    _context.CTBH_Sua(ctbh);
                    await tx.CommitAsync();
                    TempData["OrderMessage"]="Đã cập nhật sản phẩm trong đơn.";
                    return RedirectToAction("Details","DonBHs",new { id=ctbh.MaDBH });
                }
                catch(InvalidOperationException ex) { ModelState.AddModelError(string.Empty,ex.Message); }
                catch(SqlException) { ModelState.AddModelError(string.Empty,"Chưa thể cập nhật. Vui lòng tải lại đơn và thử lại."); }
            }

            return View(ctbh);
        }

        // GET: CTBHs/Delete
        public IActionResult Delete(int? maDBH, string maSP)
        {
            if (maDBH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctbh = _context.CTBH_ChiTiet(maDBH.Value, maSP);

            if (ctbh == null)
                return NotFound();

            return View(ctbh);
        }

        // POST: CTBHs/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int? maDBH, string maSP)
        {
            if (maDBH == null || string.IsNullOrWhiteSpace(maSP))
                return NotFound();

            var ctbh = _context.CTBH_ChiTiet(maDBH.Value, maSP);

            if (ctbh == null)
                return NotFound();

            try
            {
                _context.CTBH_Xoa(maDBH.Value, maSP);
                TempData["OrderMessage"]="Đã xóa sản phẩm khỏi đơn.";
                return RedirectToAction("Details","DonBHs",new { id=maDBH.Value });
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa chi tiết bán hàng vì còn dữ liệu liên quan.");

                return View(nameof(Delete), ctbh);
            }
        }
    }
}