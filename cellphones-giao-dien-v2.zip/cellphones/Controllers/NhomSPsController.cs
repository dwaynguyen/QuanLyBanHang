using Microsoft.AspNetCore.Mvc;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class NhomSPsController : Controller
    {
        private readonly AppDbContext _context;

        public NhomSPsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: NhomSPs
        public IActionResult Index()
        {
            return View(_context.NhomSP_DanhSach());
        }

        // GET: NhomSPs/Details/1
        public IActionResult Details(byte? id)
        {
            if (id == null)
                return NotFound();

            var nhomSP = _context.NhomSP_ChiTiet(id.Value);
            if (nhomSP == null)
                return NotFound();

            return View(nhomSP);
        }

        // GET: NhomSPs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: NhomSPs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("MaNSP,TenNSP")] NhomSP nhomSP)
        {
            if (ModelState.IsValid)
            {
                _context.NhomSP_Them(nhomSP);
                return RedirectToAction(nameof(Index));
            }
            return View(nhomSP);
        }

        // GET: NhomSPs/Edit/1
        public IActionResult Edit(byte? id)
        {
            if (id == null)
                return NotFound();

            var nhomSP = _context.NhomSP_ChiTiet(id.Value);
            if (nhomSP == null)
                return NotFound();

            return View(nhomSP);
        }

        // POST: NhomSPs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(byte id, [Bind("MaNSP,TenNSP")] NhomSP nhomSP)
        {
            if (id != nhomSP.MaNSP)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.NhomSP_Sua(nhomSP);
                return RedirectToAction(nameof(Index));
            }
            return View(nhomSP);
        }

        // GET: NhomSPs/Delete/1
        public IActionResult Delete(byte? id)
        {
            if (id == null)
                return NotFound();

            var nhomSP = _context.NhomSP_ChiTiet(id.Value);
            if (nhomSP == null)
                return NotFound();

            return View(nhomSP);
        }

        // POST: NhomSPs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte id)
        {
            try
            {
                _context.NhomSP_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception)
            {
                // Nhóm đang có loại sản phẩm thuộc về nó -> khóa ngoại không cho xóa
                var nhomSP = _context.NhomSP_ChiTiet(id);
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa nhóm sản phẩm này vì vẫn còn loại sản phẩm thuộc nhóm. Hãy xóa các loại sản phẩm trước.");
                return View(nameof(Delete), nhomSP);
            }
        }
    }
}
