using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Services;
using cellphones.ViewModels;
namespace cellphones.Controllers;
[AllowAnonymous]
public class CartController(CartService cart,AppDbContext db,InventoryService inventory):Controller
{
    public IActionResult Index()
    {
        try { return View(cart.Page()); }
        catch(SqlException) { return View(new CartPage { DatabaseReady=false }); }
    }
    [HttpPost]
    public IActionResult Add(string id,int quantity=1,string returnUrl="")
    {
        if(string.IsNullOrWhiteSpace(id) || id.Length>9 || quantity<1 || quantity>99) return BadRequest();
        try {
        var product=db.SanPham_ChiTiet(id.Trim());
        if(product==null || product.DonGia<=0) { TempData["ShopError"]="Sản phẩm không còn khả dụng.";return RedirectToAction(nameof(Index)); }
        var entries=cart.Entries();var old=entries.FirstOrDefault(x=>string.Equals(x.Id,id.Trim(),StringComparison.OrdinalIgnoreCase));
        if(old==null && entries.Count>=30) { TempData["ShopError"]="Giỏ hàng tối đa 30 sản phẩm khác nhau.";return RedirectToAction(nameof(Index)); }
        var requested=(old?.Quantity??0)+quantity;
        var available=inventory.Snapshot().GetValueOrDefault(id.Trim());
        if(requested>99 || requested>available) { TempData["ShopError"]=$"Không thể thêm: tối đa {Math.Max(0,Math.Min(99,available))} sản phẩm trong giỏ cho mã {id.Trim()}.";return Url.IsLocalUrl(returnUrl)?LocalRedirect(returnUrl):RedirectToAction(nameof(Index)); }
        cart.Set(id,requested);TempData["ShopMessage"]="Đã thêm "+product.TenSP+" vào giỏ hàng.";
        return Url.IsLocalUrl(returnUrl)?LocalRedirect(returnUrl):RedirectToAction(nameof(Index));
        }
        catch(SqlException) { TempData["ShopError"]="Chưa thể cập nhật giỏ hàng. Vui lòng thử lại sau.";return RedirectToAction(nameof(Index)); }
    }
    [HttpPost]
    public IActionResult Update(string id,int quantity)
    {
        if(string.IsNullOrWhiteSpace(id) || quantity<1 || quantity>99) { TempData["ShopError"]="Số lượng phải từ 1 đến 99.";return RedirectToAction(nameof(Index)); }
        try {
        if(cart.Entries().Any(x=>string.Equals(x.Id,id,StringComparison.OrdinalIgnoreCase))) {
            var available=inventory.Snapshot().GetValueOrDefault(id.Trim());
            if(quantity>available) TempData["ShopError"]=$"Sản phẩm {id} chỉ còn {Math.Max(0,available)} sản phẩm có thể đặt.";
            else cart.Set(id,quantity);
        }
        }
        catch(SqlException) { TempData["ShopError"]="Chưa thể cập nhật số lượng. Vui lòng thử lại sau."; }
        return RedirectToAction(nameof(Index));
    }
    [HttpPost] public IActionResult Remove(string id) { if(!string.IsNullOrWhiteSpace(id)) cart.Set(id,0);return RedirectToAction(nameof(Index)); }
    [HttpPost] public IActionResult Clear() { cart.Clear();return RedirectToAction(nameof(Index)); }
}
