using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class DonMHsController : Controller
    {
        private readonly AppDbContext _context;

        public DonMHsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadDanhSach(short? maNV = null, short? maNCC = null)
        {
            var nhanViens = _context.NhanVien_DanhSach()
                .Select(nv => new
                {
                    nv.MaNV,
                    HoTen = nv.HoNV + " " + nv.TenNV
                })
                .ToList();

            ViewBag.MaNV = new SelectList(
                nhanViens, "MaNV", "HoTen", maNV);

            ViewBag.MaNCC = new SelectList(
                _context.NhaCC_DanhSach(),
                "MaNCC", "TenNCC", maNCC);
        }

        // GET: DonMHs
        public IActionResult Index()
        {
            return View(_context.DonMH_DanhSach());
        }

        // GET: DonMHs/Details/1
        public IActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();

            var donMH = _context.DonMH_ChiTiet(id.Value);

            if (donMH == null)
                return NotFound();

            return View(donMH);
        }

        // GET: DonMHs/Create
        public IActionResult Create()
        {
            LoadDanhSach();

            return View(new DonMH
            {
                NgayDat = DateTime.Today
            });
        }

        // POST: DonMHs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("NgayDat,NgayGiao,MaNV,MaNCC")] DonMH donMH)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.DonMH_Them(donMH);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Nhân viên hoặc nhà cung cấp không tồn tại.");
                }
            }

            LoadDanhSach(donMH.MaNV, donMH.MaNCC);
            return View(donMH);
        }

        // GET: DonMHs/Edit/1
        public IActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var donMH = _context.DonMH_ChiTiet(id.Value);

            if (donMH == null)
                return NotFound();

            LoadDanhSach(donMH.MaNV, donMH.MaNCC);
            return View(donMH);
        }

        // POST: DonMHs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            int id,
            [Bind("MaDMH,NgayDat,NgayGiao,MaNV,MaNCC")] DonMH donMH)
        {
            if (id != donMH.MaDMH)
                return NotFound();

            if (_context.DonMH_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.DonMH_Sua(donMH);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Nhân viên hoặc nhà cung cấp không tồn tại.");
                }
            }

            LoadDanhSach(donMH.MaNV, donMH.MaNCC);
            return View(donMH);
        }

        // GET: DonMHs/Delete/1
        public IActionResult Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var donMH = _context.DonMH_ChiTiet(id.Value);

            if (donMH == null)
                return NotFound();

            return View(donMH);
        }

        // POST: DonMHs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var donMH = _context.DonMH_ChiTiet(id);

            if (donMH == null)
                return NotFound();

            try
            {
                _context.DonMH_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa đơn mua hàng vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), donMH);
            }
        }
    }
}