﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class NhaCCsController : Controller
    {
        private readonly AppDbContext _context;

        public NhaCCsController(AppDbContext context)
        {
            _context = context;
        }

        // Chuẩn bị danh sách chọn xã/phường.
        private void LoadXaPhuong(short? maXP = null)
        {
            ViewBag.MaXP = new SelectList(
                _context.XaPhuong_DanhSach(),
                "MaXP", "TenXP", maXP);
        }

        // GET: NhaCCs
        public IActionResult Index()
        {
            return View(_context.NhaCC_DanhSach());
        }

        // GET: NhaCCs/Details/1
        public IActionResult Details(short? id)
        {
            if (id == null)
                return NotFound();

            var nhaCC = _context.NhaCC_ChiTiet(id.Value);

            if (nhaCC == null)
                return NotFound();

            return View(nhaCC);
        }

        // GET: NhaCCs/Create
        public IActionResult Create()
        {
            LoadXaPhuong();
            return View();
        }

        // POST: NhaCCs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("TenNCC,DienThoai,Email,DiaChi,MaXP")] NhaCC nhaCC)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.NhaCC_Them(nhaCC);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError("MaXP",
                        "Xã/phường không tồn tại. Vui lòng chọn lại.");
                }
            }

            LoadXaPhuong(nhaCC.MaXP);
            return View(nhaCC);
        }

        // GET: NhaCCs/Edit/1
        public IActionResult Edit(short? id)
        {
            if (id == null)
                return NotFound();

            var nhaCC = _context.NhaCC_ChiTiet(id.Value);

            if (nhaCC == null)
                return NotFound();

            LoadXaPhuong(nhaCC.MaXP);
            return View(nhaCC);
        }

        // POST: NhaCCs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            short id,
            [Bind("MaNCC,TenNCC,DienThoai,Email,DiaChi,MaXP")] NhaCC nhaCC)
        {
            if (id != nhaCC.MaNCC)
                return NotFound();

            if (_context.NhaCC_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.NhaCC_Sua(nhaCC);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError("MaXP",
                        "Xã/phường không tồn tại. Vui lòng chọn lại.");
                }
            }

            LoadXaPhuong(nhaCC.MaXP);
            return View(nhaCC);
        }

        // GET: NhaCCs/Delete/1
        public IActionResult Delete(short? id)
        {
            if (id == null)
                return NotFound();

            var nhaCC = _context.NhaCC_ChiTiet(id.Value);

            if (nhaCC == null)
                return NotFound();

            return View(nhaCC);
        }

        // POST: NhaCCs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            var nhaCC = _context.NhaCC_ChiTiet(id);

            if (nhaCC == null)
                return NotFound();

            try
            {
                _context.NhaCC_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa nhà cung cấp này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), nhaCC);
            }
        }
    }
}