﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class TinhsController : Controller
    {
        private readonly AppDbContext _context;

        public TinhsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Tinhs
        public IActionResult Index()
        {
            return View(_context.Tinh_DanhSach());
        }

        // GET: Tinhs/Details/1
        public IActionResult Details(byte? id)
        {
            if (id == null)
                return NotFound();

            var tinh = _context.Tinh_ChiTiet(id.Value);

            if (tinh == null)
                return NotFound();

            return View(tinh);
        }

        // GET: Tinhs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tinhs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("MaTinh,TenTinh")] Tinh tinh)
        {
            if (ModelState.IsValid)
            {
                _context.Tinh_Them(tinh);
                return RedirectToAction(nameof(Index));
            }

            return View(tinh);
        }

        // GET: Tinhs/Edit/1
        public IActionResult Edit(byte? id)
        {
            if (id == null)
                return NotFound();

            var tinh = _context.Tinh_ChiTiet(id.Value);

            if (tinh == null)
                return NotFound();

            return View(tinh);
        }

        // POST: Tinhs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(byte id, [Bind("MaTinh,TenTinh")] Tinh tinh)
        {
            if (id != tinh.MaTinh)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.Tinh_Sua(tinh);
                return RedirectToAction(nameof(Index));
            }

            return View(tinh);
        }

        // GET: Tinhs/Delete/1
        public IActionResult Delete(byte? id)
        {
            if (id == null)
                return NotFound();

            var tinh = _context.Tinh_ChiTiet(id.Value);

            if (tinh == null)
                return NotFound();

            return View(tinh);
        }

        // POST: Tinhs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte id)
        {
            try
            {
                _context.Tinh_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                var tinh = _context.Tinh_ChiTiet(id);

                ModelState.AddModelError(string.Empty,
                    "Không thể xóa tỉnh này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), tinh);
            }
        }
    }
}
