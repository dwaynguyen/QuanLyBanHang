using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class DonViTinhsController : Controller
    {
        private readonly AppDbContext _context;

        public DonViTinhsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: DonViTinhs
        public IActionResult Index()
        {
            return View(_context.DonViTinh_DanhSach());
        }

        // GET: DonViTinhs/Details/1
        public IActionResult Details(byte? id)
        {
            if (id == null)
                return NotFound();

            var donViTinh = _context.DonViTinh_ChiTiet(id.Value);

            if (donViTinh == null)
                return NotFound();

            return View(donViTinh);
        }

        // GET: DonViTinhs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DonViTinhs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("TenDVT")] DonViTinh donViTinh)
        {
            if (ModelState.IsValid)
            {
                _context.DonViTinh_Them(donViTinh);
                return RedirectToAction(nameof(Index));
            }

            return View(donViTinh);
        }

        // GET: DonViTinhs/Edit/1
        public IActionResult Edit(byte? id)
        {
            if (id == null)
                return NotFound();

            var donViTinh = _context.DonViTinh_ChiTiet(id.Value);

            if (donViTinh == null)
                return NotFound();

            return View(donViTinh);
        }

        // POST: DonViTinhs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            byte id,
            [Bind("MaDVT,TenDVT")] DonViTinh donViTinh)
        {
            if (id != donViTinh.MaDVT)
                return NotFound();

            if (_context.DonViTinh_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.DonViTinh_Sua(donViTinh);
                return RedirectToAction(nameof(Index));
            }

            return View(donViTinh);
        }

        // GET: DonViTinhs/Delete/1
        public IActionResult Delete(byte? id)
        {
            if (id == null)
                return NotFound();

            var donViTinh = _context.DonViTinh_ChiTiet(id.Value);

            if (donViTinh == null)
                return NotFound();

            return View(donViTinh);
        }

        // POST: DonViTinhs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte id)
        {
            var donViTinh = _context.DonViTinh_ChiTiet(id);

            if (donViTinh == null)
                return NotFound();

            try
            {
                _context.DonViTinh_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa đơn vị tính vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), donViTinh);
            }
        }
    }
}