using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class LoaiSPsController : Controller
    {
        private readonly AppDbContext _context;

        public LoaiSPsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: LoaiSPs
        public IActionResult Index()
        {
            return View(_context.LoaiSP_DanhSach());
        }

        // GET: LoaiSPs/Details/1
        // GET: LoaiSPs/Details
        public IActionResult Details(short? MaLSP)
        {
            if (MaLSP == null)
                return NotFound();

            var loaiSP = _context.LoaiSP_ChiTiet(MaLSP.Value);

            if (loaiSP == null)
                return NotFound();

            return View(loaiSP);
        }

        // GET: LoaiSPs/Create
        public IActionResult Create()
        {
            ViewBag.NhomSPs = new SelectList(_context.NhomSP_DanhSach(), "MaNSP", "TenNSP");
            return View();
        }

        // POST: LoaiSPs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MaLSP,TenLSP,MaNSP")] LoaiSP loaiSP)
        {
                _context.LoaiSP_Them(loaiSP);
                return RedirectToAction(nameof(Index));
        }

        // GET: LoaiSPs/Edit/
        public async Task <IActionResult> Edit(short MaLSP)
        {
            ViewBag.NhomSPs = new SelectList(_context.NhomSP_DanhSach(), "MaNSP", "TenNSP");
            return View(_context.LoaiSP_ChiTiet(MaLSP));
        }

        // POST: LoaiSPs/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task< IActionResult> Edit(string id, [Bind("MaLSP,TenLSP,MaNSP")] LoaiSP loaiSP)
        {
            _context.LoaiSP_Sua(loaiSP);
            return RedirectToAction(nameof(Index));
        }

        // GET: LoaiSPs/Delete/1
        public IActionResult Delete(short? MaLSP)
        {
            if (MaLSP == null)
                return NotFound();

            var loaiSP = _context.LoaiSP_ChiTiet(MaLSP.Value);

            if (loaiSP == null)
                return NotFound();

            return View(loaiSP);
        }

        // POST: LoaiSPs/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short MaLSP)
        {
            try
            {
                _context.LoaiSP_Xoa(MaLSP);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception)
            {
                // Loại sản phẩm đang được sản phẩm sử dụng -> khóa ngoại không cho xóa
                var loaiSP = _context.LoaiSP_ChiTiet(MaLSP);
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa loại sản phẩm này vì đang có sản phẩm thuộc loại này.");
                return View(nameof(Delete), loaiSP);
            }
        }
    }
}
