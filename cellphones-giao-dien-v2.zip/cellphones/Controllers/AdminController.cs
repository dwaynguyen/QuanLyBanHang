using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Services;
using cellphones.ViewModels;
namespace cellphones.Controllers;
[ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class AdminController(AppDbContext db,ILogger<AdminController> logger):Controller
{
    public IActionResult Index(int days=7)
    {
        days=days is 7 or 30 or 90?days:7;
        var today=TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow,TimeZoneInfo.FindSystemTimeZoneById("Asia/Ho_Chi_Minh")).Date;
        try {
            return View(DashboardService.Build(db.SanPham_DanhSach(),db.KhachHang_DanhSach(),db.DonBH_DanhSach(),
                db.CTBH_DanhSach(),db.NhanVien_DanhSach().Count,today,days));
        }
        catch(SqlException e) {
            logger.LogWarning(e,"Dashboard database unavailable");
            return View(new DashboardPage { DatabaseReady=false,Days=days,From=today.AddDays(1-days),To=today });
        }
    }
}
