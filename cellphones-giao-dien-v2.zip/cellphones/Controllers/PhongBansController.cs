﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class PhongBansController : Controller
    {
        private readonly AppDbContext _context;

        public PhongBansController(AppDbContext context)
        {
            _context = context;
        }

        // GET: PhongBans
        public IActionResult Index()
        {
            return View(_context.PhongBan_DanhSach());
        }

        // GET: PhongBans/Details/1
        public IActionResult Details(byte? id)
        {
            if (id == null)
                return NotFound();

            var phongBan = _context.PhongBan_ChiTiet(id.Value);

            if (phongBan == null)
                return NotFound();

            return View(phongBan);
        }

        // GET: PhongBans/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PhongBans/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaPB,TenPB")] PhongBan phongBan)
        {
            if (ModelState.IsValid)
            {
                _context.PhongBan_Them(phongBan);
                return RedirectToAction(nameof(Index));
            }

            return View(phongBan);
        }

        // GET: PhongBans/Edit/1
        public IActionResult Edit(byte? id)
        {
            if (id == null)
                return NotFound();

            var phongBan = _context.PhongBan_ChiTiet(id.Value);

            if (phongBan == null)
                return NotFound();

            return View(phongBan);
        }

        // POST: PhongBans/Edit/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            byte id, [Bind("MaPB,TenPB")] PhongBan phongBan)
        {
            if (id != phongBan.MaPB)
                return NotFound();

            if (ModelState.IsValid)
            {
                _context.PhongBan_Sua(phongBan);
                return RedirectToAction(nameof(Index));
            }

            return View(phongBan);
        }

        // GET: PhongBans/Delete/1
        public IActionResult Delete(byte? id)
        {
            if (id == null)
                return NotFound();

            var phongBan = _context.PhongBan_ChiTiet(id.Value);

            if (phongBan == null)
                return NotFound();

            return View(phongBan);
        }

        // POST: PhongBans/Delete/1
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(byte id)
        {
            try
            {
                _context.PhongBan_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                var phongBan = _context.PhongBan_ChiTiet(id);

                if (phongBan == null)
                    return NotFound();

                ModelState.AddModelError(string.Empty,
                    "Không thể xóa phòng ban này vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), phongBan);
            }
        }
    }
}