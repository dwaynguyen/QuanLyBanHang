using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Services;
using cellphones.ViewModels;
namespace cellphones.Controllers;
[AllowAnonymous]
[ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class CheckoutController(CartService cart,AppDbContext db,OrderService orders,CheckoutGate gate,ILogger<CheckoutController> logger,OrderReceiptService receipts):Controller
{
    private void Fill(CheckoutPage page)
    {
        try
        {
            page.Cart=cart.Page();page.Wards=db.XaPhuong_DanhSach();page.Provinces=db.Tinh_DanhSach().ToDictionary(x=>x.MaTinh,x=>x.TenTinh);
            page.CanOrder=page.Cart.Lines.Count>0 && !page.Cart.HasUnavailable && !page.Cart.HasInsufficientStock && page.Wards.Count>0 && db.NhanVien_DanhSach().Count>0;
            if(!page.CanOrder) ModelState.AddModelError("","Giỏ hàng, số lượng tồn hoặc thông tin tiếp nhận đơn chưa sẵn sàng. Vui lòng kiểm tra giỏ hàng hoặc liên hệ cửa hàng.");
        }
        catch(SqlException e) { logger.LogWarning(e,"Checkout database is unavailable");page.CanOrder=false;ModelState.AddModelError("","Chưa kết nối được dữ liệu. Vui lòng thử lại sau."); }
    }
    public IActionResult Index()
    {
        if(cart.Count==0) return RedirectToAction("Index","Cart");
        var token=HttpContext.Session.GetString("CheckoutToken");
        if(token==null) { token=Convert.ToHexString(RandomNumberGenerator.GetBytes(32));HttpContext.Session.SetString("CheckoutToken",token); }
        var page=new CheckoutPage { Token=token };Fill(page);if(page.CanOrder) HttpContext.Session.SetString("CheckoutFingerprint",CartService.Fingerprint(page.Cart));return View(page);
    }
    [HttpPost]
    public async Task<IActionResult> Place(CheckoutPage page)
    {
        await gate.Lock.WaitAsync();
        try
        {
            var cached=gate.Find(page.Token??"");
            if(cached!=null && cached.SessionId==HttpContext.Session.Id) return RedirectToAction(nameof(Success),new { key=cached.Key });
            if(string.IsNullOrEmpty(page.Token) || page.Token!=HttpContext.Session.GetString("CheckoutToken")) { TempData["ShopError"]="Phiên đặt hàng đã thay đổi. Vui lòng kiểm tra giỏ hàng rồi đặt lại.";return RedirectToAction("Index","Cart"); }
            Fill(page);
            var fingerprint=CartService.Fingerprint(page.Cart);
            if(page.CanOrder && HttpContext.Session.GetString("CheckoutFingerprint")!=fingerprint)
            {
                HttpContext.Session.SetString("CheckoutFingerprint",fingerprint);
                ModelState.AddModelError("","Giá hoặc số lượng sản phẩm đã thay đổi. Vui lòng kiểm tra tổng tiền bên cạnh và xác nhận lại.");
            }
            if(!ModelState.IsValid || !page.CanOrder) return View("Index",page);
            try
            {
                var receipt=await orders.Place(page,cart.Entries(),HttpContext.Session.Id,fingerprint);var ward=page.Wards.First(w=>w.MaXP==page.WardId);receipt.Address+=", "+ward.TenXP+", "+page.Provinces.GetValueOrDefault(ward.MaTinh);gate.Save(page.Token,receipt);
                cart.Clear();HttpContext.Session.Remove("CheckoutToken");HttpContext.Session.Remove("CheckoutFingerprint");HttpContext.Session.SetString("LastOrder",receipt.Key);return RedirectToAction(nameof(Success),new { key=receipt.Key });
            }
            catch(InvalidOperationException e) { Fill(page);if(page.CanOrder) HttpContext.Session.SetString("CheckoutFingerprint",CartService.Fingerprint(page.Cart));ModelState.AddModelError("",e.Message); }
            catch(SqlException e)
            {
                logger.LogError(e,"Order transaction failed");
                ModelState.AddModelError("",e.Number is 2601 or 2627?"Email hoặc thông tin liên hệ đã gắn với hồ sơ khác. Vui lòng kiểm tra lại họ tên, email và số điện thoại.":"Chưa thể lưu đơn hàng. Giỏ hàng vẫn được giữ lại; vui lòng thử lại sau.");
            }
            return View("Index",page);
        }
        finally { gate.Lock.Release(); }
    }
    [ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
    public IActionResult Success(string key)
    {
        Response.Headers["Referrer-Policy"]="no-referrer";
        Response.Headers["X-Robots-Tag"]="noindex, nofollow";
        try
        {
            var receipt=receipts.Read(key);
            if(receipt==null) return View("Lookup",new ReceiptLookupPage { Error="Liên kết không hợp lệ hoặc đơn hàng không còn tồn tại." });
            return View(receipt);
        }
        catch(SqlException e) { logger.LogWarning(e,"Receipt database unavailable");return View("Lookup",new ReceiptLookupPage { Error="Chưa tải được đơn hàng. Vui lòng giữ liên kết và thử lại sau." }); }
    }
    public IActionResult Lookup() => View(new ReceiptLookupPage());
    [HttpPost]
    public IActionResult Lookup(ReceiptLookupPage page)
    {
        if(!ModelState.IsValid) return View(page);
        return RedirectToAction(nameof(Success),new { key=page.Key.Trim() });
    }
}
