using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Services;
using cellphones.ViewModels;
namespace cellphones.Controllers;
[AllowAnonymous]
public class StoreController(AppDbContext db,ILogger<StoreController> logger,InventoryService inventory):Controller
{
    private StorePage Page()
    {
        try { return new StorePage { Stock=inventory.Snapshot(),Products=db.SanPham_DanhSach(),Categories=db.LoaiSPs.FromSqlRaw("EXEC LoaiSP_DS").ToList().ToDictionary(x=>x.MaLSP,x=>x.TenLSP) }; }
        catch(Exception e) when(e is SqlException or InvalidOperationException) { logger.LogWarning(e,"Store database is unavailable");return new StorePage { DatabaseReady=false }; }
    }
    public IActionResult Index()=>View(Page());
    public IActionResult Products()=>View(Page());
    public IActionResult Details(string id,string returnUrl="")
    {
        if(string.IsNullOrWhiteSpace(id)) return NotFound();
        var product=db.SanPham_ChiTiet(id.Trim());if(product==null) return NotFound();
        ViewBag.Category=db.LoaiSPs.FromSqlRaw("EXEC LoaiSP_DS").ToList().FirstOrDefault(x=>x.MaLSP==product.MaLSP)?.TenLSP;
        ViewBag.Available=Math.Max(0,inventory.Snapshot().GetValueOrDefault(id.Trim()));
        ViewBag.ReturnUrl=Url.IsLocalUrl(returnUrl)?returnUrl:Url.Action(nameof(Products));
        return View(product);
    }
}
