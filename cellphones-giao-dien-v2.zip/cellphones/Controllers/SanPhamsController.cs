﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using cellphones.Data;
using cellphones.Models;

namespace cellphones.Controllers
{
    public class SanPhamsController : Controller
    {
        private readonly AppDbContext _context;

        public SanPhamsController(AppDbContext context)
        {
            _context = context;
        }

        private void LoadDanhSach(short? maLSP = null, byte? maDVT = null)
        {
            ViewBag.MaLSP = new SelectList(
                _context.LoaiSP_DanhSach(),
                "MaLSP", "TenLSP", maLSP);

            ViewBag.MaDVT = new SelectList(
                _context.DonViTinh_DanhSach(),
                "MaDVT", "TenDVT", maDVT);
        }

        // GET: SanPhams
        public IActionResult Index()
        {
            return View(_context.SanPham_DanhSach());
        }

        // GET: SanPhams/Details/SP001
        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return NotFound();

            var sanPham = _context.SanPham_ChiTiet(id);

            if (sanPham == null)
                return NotFound();

            return View(sanPham);
        }

        // GET: SanPhams/Create
        public IActionResult Create()
        {
            LoadDanhSach();
            return View();
        }

        // POST: SanPhams/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            [Bind("MaSP,TenSP,DonGia,AnhSP,MoTaCT,MaLSP,MaDVT")]
            SanPham sanPham)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.SanPham_Them(sanPham);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex)
                    when (ex.Number == 2627 || ex.Number == 2601)
                {
                    ModelState.AddModelError("MaSP",
                        "Mã sản phẩm đã tồn tại.");
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Loại sản phẩm hoặc đơn vị tính không tồn tại.");
                }
            }

            LoadDanhSach(sanPham.MaLSP, sanPham.MaDVT);
            return View(sanPham);
        }

        // GET: SanPhams/Edit/SP001
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return NotFound();

            var sanPham = _context.SanPham_ChiTiet(id);

            if (sanPham == null)
                return NotFound();

            LoadDanhSach(sanPham.MaLSP, sanPham.MaDVT);
            return View(sanPham);
        }

        // POST: SanPhams/Edit/SP001
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(
            string id,
            [Bind("MaSP,TenSP,DonGia,AnhSP,MoTaCT,MaLSP,MaDVT")]
            SanPham sanPham)
        {
            if (string.IsNullOrWhiteSpace(id) ||
                string.IsNullOrWhiteSpace(sanPham.MaSP))
                return NotFound();

            if (id.TrimEnd() != sanPham.MaSP.TrimEnd())
                return NotFound();

            if (_context.SanPham_ChiTiet(id) == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.SanPham_Sua(sanPham);
                    return RedirectToAction(nameof(Index));
                }
                catch (SqlException ex) when (ex.Number == 547)
                {
                    ModelState.AddModelError(string.Empty,
                        "Loại sản phẩm hoặc đơn vị tính không tồn tại.");
                }
            }

            LoadDanhSach(sanPham.MaLSP, sanPham.MaDVT);
            return View(sanPham);
        }

        // GET: SanPhams/Delete/SP001
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return NotFound();

            var sanPham = _context.SanPham_ChiTiet(id);

            if (sanPham == null)
                return NotFound();

            return View(sanPham);
        }

        // POST: SanPhams/Delete/SP001
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return NotFound();

            var sanPham = _context.SanPham_ChiTiet(id);

            if (sanPham == null)
                return NotFound();

            try
            {
                _context.SanPham_Xoa(id);
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                ModelState.AddModelError(string.Empty,
                    "Không thể xóa sản phẩm vì vẫn còn dữ liệu liên quan.");

                return View(nameof(Delete), sanPham);
            }
        }
    }
}