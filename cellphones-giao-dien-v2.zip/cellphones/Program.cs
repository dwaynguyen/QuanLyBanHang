using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using System.Security.Claims;
using System.Threading.RateLimiting;
using cellphones.Data;
using cellphones.Services;

var builder = WebApplication.CreateBuilder(args);
var keyPath = builder.Configuration["Store:ReceiptKeyPath"] ?? Path.Combine(builder.Environment.ContentRootPath,"App_Data","keys");
builder.Services.AddDataProtection().SetApplicationName("cellphones").PersistKeysToFileSystem(new DirectoryInfo(keyPath));
builder.Services.AddScoped<InventoryService>();
builder.Services.AddScoped<OrderReceiptService>();
builder.Services.AddControllersWithViews(options=> {
    options.Filters.Add(new AuthorizeFilter(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().RequireRole("Admin").Build()));
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
});
builder.Services.AddDbContext<AppDbContext>(opt=>opt.UseSqlServer(builder.Configuration.GetConnectionString("DbQLBHConnection")));
builder.Services.AddDistributedMemoryCache();builder.Services.AddMemoryCache();builder.Services.AddHttpContextAccessor();
builder.Services.AddSession(options=> { options.IdleTimeout=TimeSpan.FromHours(2);options.Cookie.HttpOnly=true;options.Cookie.IsEssential=true;options.Cookie.SameSite=SameSiteMode.Lax; });
builder.Services.AddScoped<CartService>();builder.Services.AddScoped<OrderService>();builder.Services.AddScoped<AdminAccess>();builder.Services.AddSingleton<CheckoutGate>();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options=> {
    options.LoginPath="/Account/Login";options.AccessDeniedPath="/Account/Denied";options.Cookie.Name="Cellphones.Admin";
    options.Cookie.HttpOnly=true;options.Cookie.SameSite=SameSiteMode.Lax;options.Cookie.SecurePolicy=CookieSecurePolicy.SameAsRequest;
    options.ExpireTimeSpan=TimeSpan.FromMinutes(30);options.SlidingExpiration=true;
    options.Events.OnValidatePrincipal=async context=> {
        var id=context.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);var valid=false;
        if(short.TryParse(id,out var employeeId)) {
            try { valid=context.HttpContext.RequestServices.GetRequiredService<AdminAccess>().IsAdmin(employeeId); }
            catch(Microsoft.Data.SqlClient.SqlException) { valid=false; }
        }
        if(!valid) { context.RejectPrincipal();await context.HttpContext.SignOutAsync(); }
    };
});
builder.Services.AddRateLimiter(options=> {
    options.RejectionStatusCode=429;
    options.AddPolicy("login",context=>RateLimitPartition.GetFixedWindowLimiter(context.Connection.RemoteIpAddress?.ToString()??"local",_=>new FixedWindowRateLimiterOptions { PermitLimit=10,Window=TimeSpan.FromMinutes(1),QueueLimit=0 }));
});
var app=builder.Build();
if(!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Home/Error");app.UseHsts(); }
app.UseHttpsRedirection();app.UseStaticFiles();app.UseRouting();app.UseSession();app.UseAuthentication();app.UseAuthorization();app.UseRateLimiter();
app.MapControllerRoute(name:"default",pattern:"{controller=Home}/{action=Index}/{id?}");
app.Run();
