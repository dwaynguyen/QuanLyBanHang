using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using cellphones.Models;

namespace cellphones.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> opts) : base(opts) { }

        public DbSet<NhomSP> NhomSPs { get; set; }
        public DbSet<LoaiSP> LoaiSPs { get; set; }
        public DbSet<DonViTinh> DonViTinhs { get; set; }
        public DbSet<Tinh> Tinhs { get; set; }
        public DbSet<XaPhuong> XaPhuongs { get; set; }
        public DbSet<PhongBan> PhongBans { get; set; }
        public DbSet<NhanVien> NhanViens { get; set; }
        public DbSet<Quyen> Quyens { get; set; }
        public DbSet<PhanQuyen> PhanQuyens { get; set; }
        public DbSet<NhaCC> NhaCCs { get; set; }
        public DbSet<SanPham> SanPhams { get; set; }
        public DbSet<DonMH> DonMHs { get; set; }
        public DbSet<CTMH> CTMHs { get; set; }
        public DbSet<KhachHang> KhachHangs { get; set; }
        public DbSet<DonBH> DonBHs { get; set; }
        public DbSet<CTBH> CTBHs { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<PhanQuyen>()
                .HasKey(p => new { p.MaQuyen, p.MaNV });
            modelBuilder.Entity<CTMH>()
                .HasKey(p => new { p.MaDMH, p.MaSP });
            modelBuilder.Entity<CTBH>()
                 .HasKey(p => new { p.MaDBH, p.MaSP });
        }

        // 4.1 Danh sách
        public List<NhomSP> NhomSP_DanhSach()
        {
            return NhomSPs.FromSqlRaw("EXEC NhomSP_DS").ToList();
        }

        // 4.2 Chi tiết
        public NhomSP NhomSP_ChiTiet(byte MaNSP)
        {
            var p = new[]
            {
                new SqlParameter("@MaNSP", MaNSP)
            };
            return NhomSPs.FromSqlRaw("EXEC NhomSP_CT @MaNSP", p).ToList().FirstOrDefault();
        }

        // 4.3 Thêm
        public int NhomSP_Them(NhomSP nsp)
        {
            var p = new[]
            {
                new SqlParameter("@TenNSP", nsp.TenNSP)
            };
            return Database.ExecuteSqlRaw("EXEC NhomSP_Them @TenNSP", p);
        }

        // 4.4 Sửa
        public int NhomSP_Sua(NhomSP nsp)
        {
            var p = new[]
            {
                new SqlParameter("@MaNSP", nsp.MaNSP),
                new SqlParameter("@TenNSP", nsp.TenNSP)
            };
            return Database.ExecuteSqlRaw("EXEC NhomSP_Sua @MaNSP,@TenNSP", p);
        }

        // 4.5 Xóa
        public int NhomSP_Xoa(byte MaNSP)
        {
            var p = new[]
            {
                new SqlParameter("@MaNSP", MaNSP)
            };
            return Database.ExecuteSqlRaw("EXEC NhomSP_Xoa @MaNSP", p);
        }

        // 4.1 Danh sách (kèm thông tin nhóm sản phẩm)

        public List<LoaiSP> LoaiSP_DanhSach()
        {
            var dsloaiSP = LoaiSPs.FromSqlRaw("EXEC LoaiSP_DS").ToList();

            foreach (var l in dsloaiSP)
            {
                l.NhomSP = NhomSP_ChiTiet(l.MaNSP);
            }

            return dsloaiSP;
        }

        // 4.2 Chi tiế
        public LoaiSP LoaiSP_ChiTiet(short MaLSP)
        {
            var p = new[]
            {
                new Microsoft.Data.SqlClient.SqlParameter("@MaLSP", MaLSP)
            };
            var loaiSP = LoaiSPs.FromSqlRaw("EXEC LoaiSP_CT @MaLSP", p).ToList().FirstOrDefault();
            if (loaiSP != null)
                loaiSP.NhomSP = NhomSP_ChiTiet(loaiSP.MaNSP); // Sau khi lấy chi tiết loại SP, lấy thêm nhóm SP
            return loaiSP;
        }

        // 4.3 Thêm
        public int LoaiSP_Them(LoaiSP lsp)
        {
            var p = new[]
            {
                new SqlParameter("@TenLSP", lsp.TenLSP),
                new SqlParameter("@MaNSP", lsp.MaNSP)
            };
            return Database.ExecuteSqlRaw("EXEC LoaiSP_Them @TenLSP,@MaNSP", p);
        }

        // 4.4 Sửa
        public int LoaiSP_Sua(LoaiSP lsp)
        {
            var p = new[]
            {
                new SqlParameter("@MaLSP", lsp.MaLSP),
                new SqlParameter("@TenLSP", lsp.TenLSP),
                new SqlParameter("@MaNSP", lsp.MaNSP)
            };
            return Database.ExecuteSqlRaw("EXEC LoaiSP_Sua @MaLSP,@TenLSP,@MaNSP", p);
        }

        // 4.5 Xóa
        public int LoaiSP_Xoa(short MaLSP)
        {
            var p = new[]
            {
                new SqlParameter("@MaLSP", MaLSP)
            };
            return Database.ExecuteSqlRaw("EXEC LoaiSP_Xoa @MaLSP", p);
        }
        // Thao tác trên bảng Tinh

        // 1. Danh sách
        public List<Tinh> Tinh_DanhSach()
        {
            return Tinhs.FromSqlRaw("EXEC Tinh_DS").ToList();
        }

        // 2. Chi tiết
        public Tinh Tinh_ChiTiet(byte MaTinh)
        {
            var p = new[]
            {
                 new SqlParameter("@MaTinh", MaTinh)
            };

            return Tinhs.FromSqlRaw("EXEC Tinh_CT @MaTinh", p)
                        .ToList()
                        .FirstOrDefault();
        }

        // 3. Thêm
        public int Tinh_Them(Tinh tinh)
        {
            var p = new[]
            {
                new SqlParameter("@TenTinh", tinh.TenTinh)
            };

            return Database.ExecuteSqlRaw("EXEC Tinh_Them @TenTinh", p);
        }

        // 4. Sửa
        public int Tinh_Sua(Tinh tinh)
        {
            var p = new[]
            {
                new SqlParameter("@MaTinh", tinh.MaTinh),
                 new SqlParameter("@TenTinh", tinh.TenTinh)
            };

            return Database.ExecuteSqlRaw(
                "EXEC Tinh_Sua @MaTinh,@TenTinh", p);
        }

        // 5. Xóa
        public int Tinh_Xoa(byte MaTinh)
        {
            var p = new[]
            {
                 new SqlParameter("@MaTinh", MaTinh)
            };

            return Database.ExecuteSqlRaw("EXEC Tinh_Xoa @MaTinh", p);
        }
        // Thao tác trên bảng XaPhuong

        // 1. Danh sách
        public List<XaPhuong> XaPhuong_DanhSach()
        {
            return XaPhuongs.FromSqlRaw("EXEC XaPhuong_DS").ToList();
        }

        // 2. Chi tiết
        public XaPhuong? XaPhuong_ChiTiet(short MaXP)
        {
            var p = new[]
            {
        new SqlParameter("@MaXP", MaXP)
            };

            return XaPhuongs.FromSqlRaw("EXEC XaPhuong_CT @MaXP", p)
                            .ToList()
                            .FirstOrDefault();
        }

        // 3. Thêm
        public int XaPhuong_Them(XaPhuong xaPhuong)
        {
            var p = new[]
            {
        new SqlParameter("@TenXP", xaPhuong.TenXP),
        new SqlParameter("@MaTinh", xaPhuong.MaTinh)
    };

            return Database.ExecuteSqlRaw(
                "EXEC XaPhuong_Them @TenXP,@MaTinh", p);
        }

        // 4. Sửa
        public int XaPhuong_Sua(XaPhuong xaPhuong)
        {
            var p = new[]
            {
        new SqlParameter("@MaXP", xaPhuong.MaXP),
        new SqlParameter("@TenXP", xaPhuong.TenXP),
        new SqlParameter("@MaTinh", xaPhuong.MaTinh)
    };

            return Database.ExecuteSqlRaw(
                "EXEC XaPhuong_Sua @MaXP,@TenXP,@MaTinh", p);
        }

        // 5. Xóa
        public int XaPhuong_Xoa(short MaXP)
        {
            var p = new[]
            {
        new SqlParameter("@MaXP", MaXP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC XaPhuong_Xoa @MaXP", p);
        }
        // Thao tác trên bảng PhongBan

        // 1. Danh sách
        public List<PhongBan> PhongBan_DanhSach()
        {
            return PhongBans.FromSqlRaw("EXEC PhongBan_DS").ToList();
        }

        // 2. Chi tiết
        public PhongBan? PhongBan_ChiTiet(byte MaPB)
        {
            var p = new[]
            {
        new SqlParameter("@MaPB", MaPB)
    };

            return PhongBans.FromSqlRaw("EXEC PhongBan_CT @MaPB", p)
                            .ToList()
                            .FirstOrDefault();
        }

        // 3. Thêm
        public int PhongBan_Them(PhongBan phongBan)
        {
            var p = new[]
            {
        new SqlParameter("@TenPB", phongBan.TenPB)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhongBan_Them @TenPB", p);
        }

        // 4. Sửa
        public int PhongBan_Sua(PhongBan phongBan)
        {
            var p = new[]
            {
        new SqlParameter("@MaPB", phongBan.MaPB),
        new SqlParameter("@TenPB", phongBan.TenPB)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhongBan_Sua @MaPB,@TenPB", p);
        }

        // 5. Xóa
        public int PhongBan_Xoa(byte MaPB)
        {
            var p = new[]
            {
        new SqlParameter("@MaPB", MaPB)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhongBan_Xoa @MaPB", p);
        }
        // Thao tác trên bảng NhanVien

        // 1. Danh sách
        public List<NhanVien> NhanVien_DanhSach()
        {
            return NhanViens.FromSqlRaw("EXEC NhanVien_DS").ToList();
        }

        // 2. Chi tiết
        public NhanVien? NhanVien_ChiTiet(short MaNV)
        {
            var p = new[]
            {
        new SqlParameter("@MaNV", MaNV)
    };

            return NhanViens.FromSqlRaw("EXEC NhanVien_CT @MaNV", p)
                            .ToList()
                            .FirstOrDefault();
        }

        // 3. Thêm
        // MatKhau phải được băm ở Controller trước khi gọi hàm này.
        public int NhanVien_Them(NhanVien nhanVien)
        {
            var p = new[]
            {
        new SqlParameter("@HoNV", nhanVien.HoNV),
        new SqlParameter("@TenNV", nhanVien.TenNV),
        new SqlParameter("@DienThoai", nhanVien.DienThoai),
        new SqlParameter("@Email", nhanVien.Email),
        new SqlParameter("@TenDN", nhanVien.TenDN),
        new SqlParameter("@MatKhau",
            (object?)nhanVien.MatKhau ?? DBNull.Value),
        new SqlParameter("@MaPB", nhanVien.MaPB),
        new SqlParameter("@AnhNV",
            (object?)nhanVien.AnhNV ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhanVien_Them @HoNV,@TenNV,@DienThoai,@Email," +
                "@TenDN,@MatKhau,@MaPB,@AnhNV", p);
        }

        // 4. Sửa
        // Nếu đổi mật khẩu, Controller phải băm mật khẩu mới trước.
        public int NhanVien_Sua(NhanVien nhanVien)
        {
            var p = new[]
            {
        new SqlParameter("@MaNV", nhanVien.MaNV),
        new SqlParameter("@HoNV", nhanVien.HoNV),
        new SqlParameter("@TenNV", nhanVien.TenNV),
        new SqlParameter("@DienThoai", nhanVien.DienThoai),
        new SqlParameter("@Email", nhanVien.Email),
        new SqlParameter("@TenDN", nhanVien.TenDN),
        new SqlParameter("@MaPB", nhanVien.MaPB),
        new SqlParameter("@AnhNV",
            (object?)nhanVien.AnhNV ?? DBNull.Value),
        new SqlParameter("@MatKhau",
            (object?)nhanVien.MatKhau ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhanVien_Sua @MaNV,@HoNV,@TenNV,@DienThoai," +
                "@Email,@TenDN,@MaPB,@AnhNV,@MatKhau", p);
        }

        // 5. Xóa
        public int NhanVien_Xoa(short MaNV)
        {
            var p = new[]
            {
        new SqlParameter("@MaNV", MaNV)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhanVien_Xoa @MaNV", p);
        }
        // Thao tác trên bảng Quyen

        // 1. Danh sách
        public List<Quyen> Quyen_DanhSach()
        {
            return Quyens.FromSqlRaw("EXEC Quyen_DS").ToList();
        }

        // 2. Chi tiết
        public Quyen? Quyen_ChiTiet(byte MaQuyen)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", MaQuyen)
    };

            return Quyens.FromSqlRaw("EXEC Quyen_CT @MaQuyen", p)
                          .ToList()
                          .FirstOrDefault();
        }

        // 3. Thêm
        public int Quyen_Them(Quyen quyen)
        {
            var p = new[]
            {
        new SqlParameter("@TenQuyen", quyen.TenQuyen),
        new SqlParameter("@MoTa",
            (object?)quyen.MoTa ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC Quyen_Them @TenQuyen,@MoTa", p);
        }

        // 4. Sửa
        public int Quyen_Sua(Quyen quyen)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", quyen.MaQuyen),
        new SqlParameter("@TenQuyen", quyen.TenQuyen),
        new SqlParameter("@MoTa",
            (object?)quyen.MoTa ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC Quyen_Sua @MaQuyen,@TenQuyen,@MoTa", p);
        }

        // 5. Xóa
        public int Quyen_Xoa(byte MaQuyen)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", MaQuyen)
    };

            return Database.ExecuteSqlRaw(
                "EXEC Quyen_Xoa @MaQuyen", p);
        }
        // Thao tác trên bảng PhanQuyen

        // 1. Danh sách
        public List<PhanQuyen> PhanQuyen_DanhSach()
        {
            return PhanQuyens.FromSqlRaw("EXEC PhanQuyen_DS").ToList();
        }

        // 2. Chi tiết
        public PhanQuyen? PhanQuyen_ChiTiet(byte MaQuyen, short MaNV)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", MaQuyen),
        new SqlParameter("@MaNV", MaNV)
    };

            return PhanQuyens
                .FromSqlRaw("EXEC PhanQuyen_CT @MaQuyen,@MaNV", p)
                .ToList()
                .FirstOrDefault();
        }

        // 3. Thêm
        public int PhanQuyen_Them(PhanQuyen phanQuyen)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", phanQuyen.MaQuyen),
        new SqlParameter("@MaNV", phanQuyen.MaNV)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhanQuyen_Them @MaQuyen,@MaNV", p);
        }

        // 4. Sửa
        public int PhanQuyen_Sua(
            byte MaQuyenCu, short MaNVCu, PhanQuyen phanQuyen)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyenCu", MaQuyenCu),
        new SqlParameter("@MaNVCu", MaNVCu),
        new SqlParameter("@MaQuyen", phanQuyen.MaQuyen),
        new SqlParameter("@MaNV", phanQuyen.MaNV)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhanQuyen_Sua @MaQuyenCu,@MaNVCu,@MaQuyen,@MaNV", p);
        }

        // 5. Xóa
        public int PhanQuyen_Xoa(byte MaQuyen, short MaNV)
        {
            var p = new[]
            {
        new SqlParameter("@MaQuyen", MaQuyen),
        new SqlParameter("@MaNV", MaNV)
    };

            return Database.ExecuteSqlRaw(
                "EXEC PhanQuyen_Xoa @MaQuyen,@MaNV", p);
        }
        // Thao tác trên bảng NhaCC

        // 1. Danh sách
        public List<NhaCC> NhaCC_DanhSach()
        {
            return NhaCCs.FromSqlRaw("EXEC NhaCC_DS").ToList();
        }

        // 2. Chi tiết
        public NhaCC? NhaCC_ChiTiet(short MaNCC)
        {
            var p = new[]
            {
        new SqlParameter("@MaNCC", MaNCC)
    };

            return NhaCCs.FromSqlRaw("EXEC NhaCC_CT @MaNCC", p)
                         .ToList()
                         .FirstOrDefault();
        }

        // 3. Thêm
        public int NhaCC_Them(NhaCC nhaCC)
        {
            var p = new[]
            {
        new SqlParameter("@TenNCC", nhaCC.TenNCC),
        new SqlParameter("@DienThoai", nhaCC.DienThoai),
        new SqlParameter("@Email", nhaCC.Email),
        new SqlParameter("@DiaChi", nhaCC.DiaChi),
        new SqlParameter("@MaXP", nhaCC.MaXP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhaCC_Them @TenNCC,@DienThoai,@Email,@DiaChi,@MaXP", p);
        }

        // 4. Sửa
        public int NhaCC_Sua(NhaCC nhaCC)
        {
            var p = new[]
            {
        new SqlParameter("@MaNCC", nhaCC.MaNCC),
        new SqlParameter("@TenNCC", nhaCC.TenNCC),
        new SqlParameter("@DienThoai", nhaCC.DienThoai),
        new SqlParameter("@Email", nhaCC.Email),
        new SqlParameter("@DiaChi", nhaCC.DiaChi),
        new SqlParameter("@MaXP", nhaCC.MaXP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhaCC_Sua @MaNCC,@TenNCC,@DienThoai,@Email,@DiaChi,@MaXP",
                p);
        }

        // 5. Xóa
        public int NhaCC_Xoa(short MaNCC)
        {
            var p = new[]
            {
        new SqlParameter("@MaNCC", MaNCC)
    };

            return Database.ExecuteSqlRaw(
                "EXEC NhaCC_Xoa @MaNCC", p);
        }
        // Thao tác trên bảng DonViTinh

        // 1. Danh sách
        public List<DonViTinh> DonViTinh_DanhSach()
        {
            return DonViTinhs.FromSqlRaw("EXEC DonViTinh_DS").ToList();
        }

        // 2. Chi tiết
        public DonViTinh DonViTinh_ChiTiet(byte MaDVT)
        {
            var p = new[]
            {
        new SqlParameter("@MaDVT", MaDVT)
    };

            return DonViTinhs.FromSqlRaw("EXEC DonViTinh_CT @MaDVT", p)
                            .ToList()
                            .FirstOrDefault();
        }

        // 3. Thêm
        public int DonViTinh_Them(DonViTinh donViTinh)
        {
            var p = new[]
            {
        new SqlParameter("@TenDVT", donViTinh.TenDVT)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonViTinh_Them @TenDVT", p);
        }

        // 4. Sửa
        public int DonViTinh_Sua(DonViTinh donViTinh)
        {
            var p = new[]
            {
        new SqlParameter("@MaDVT", donViTinh.MaDVT),
        new SqlParameter("@TenDVT", donViTinh.TenDVT)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonViTinh_Sua @MaDVT,@TenDVT", p);
        }

        // 5. Xóa
        public int DonViTinh_Xoa(byte MaDVT)
        {
            var p = new[]
            {
        new SqlParameter("@MaDVT", MaDVT)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonViTinh_Xoa @MaDVT", p);
        }
        // Thao tác trên bảng SanPham

        // 1. Danh sách
        public List<SanPham> SanPham_DanhSach()
        {
            return SanPhams.FromSqlRaw("EXEC SanPham_DS").ToList();
        }

        // 2. Chi tiết
        public SanPham SanPham_ChiTiet(string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaSP", MaSP)
    };

            return SanPhams.FromSqlRaw("EXEC SanPham_CT @MaSP", p)
                           .ToList()
                           .FirstOrDefault();
        }

        // 3. Thêm
        public int SanPham_Them(SanPham sanPham)
        {
            var p = new[]
            {
        new SqlParameter("@MaSP", sanPham.MaSP),
        new SqlParameter("@TenSP", sanPham.TenSP),
        new SqlParameter("@DonGia", sanPham.DonGia),
        new SqlParameter("@AnhSP",
            (object)sanPham.AnhSP ?? DBNull.Value),
        new SqlParameter("@MoTaCT",
            (object)sanPham.MoTaCT ?? DBNull.Value),
        new SqlParameter("@MaLSP", sanPham.MaLSP),
        new SqlParameter("@MaDVT", sanPham.MaDVT)
    };

            return Database.ExecuteSqlRaw(
                "EXEC SanPham_Them @MaSP,@TenSP,@DonGia,@AnhSP," +
                "@MoTaCT,@MaLSP,@MaDVT", p);
        }

        // 4. Sửa
        public int SanPham_Sua(SanPham sanPham)
        {
            var p = new[]
            {
        new SqlParameter("@MaSP", sanPham.MaSP),
        new SqlParameter("@TenSP", sanPham.TenSP),
        new SqlParameter("@DonGia", sanPham.DonGia),
        new SqlParameter("@AnhSP",
            (object)sanPham.AnhSP ?? DBNull.Value),
        new SqlParameter("@MoTaCT",
            (object)sanPham.MoTaCT ?? DBNull.Value),
        new SqlParameter("@MaLSP", sanPham.MaLSP),
        new SqlParameter("@MaDVT", sanPham.MaDVT)
    };

            return Database.ExecuteSqlRaw(
                "EXEC SanPham_Sua @MaSP,@TenSP,@DonGia,@AnhSP," +
                "@MoTaCT,@MaLSP,@MaDVT", p);
        }

        // 5. Xóa
        public int SanPham_Xoa(string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaSP", MaSP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC SanPham_Xoa @MaSP", p);
        }
        // Thao tác trên bảng DonMH

        // 1. Danh sách
        public List<DonMH> DonMH_DanhSach()
        {
            return DonMHs.FromSqlRaw("EXEC DonMH_DS").ToList();
        }

        // 2. Chi tiết
        public DonMH DonMH_ChiTiet(int MaDMH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", MaDMH)
    };

            return DonMHs.FromSqlRaw("EXEC DonMH_CT @MaDMH", p)
                         .ToList()
                         .FirstOrDefault();
        }

        // 3. Thêm
        public int DonMH_Them(DonMH donMH)
        {
            var p = new[]
            {
        new SqlParameter("@NgayDat", donMH.NgayDat),
        new SqlParameter("@NgayGiao",
            (object)donMH.NgayGiao ?? DBNull.Value),
        new SqlParameter("@MaNV", donMH.MaNV),
        new SqlParameter("@MaNCC", donMH.MaNCC)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonMH_Them @NgayDat,@NgayGiao,@MaNV,@MaNCC", p);
        }

        // 4. Sửa
        public int DonMH_Sua(DonMH donMH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", donMH.MaDMH),
        new SqlParameter("@NgayDat", donMH.NgayDat),
        new SqlParameter("@NgayGiao",
            (object)donMH.NgayGiao ?? DBNull.Value),
        new SqlParameter("@MaNV", donMH.MaNV),
        new SqlParameter("@MaNCC", donMH.MaNCC)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonMH_Sua @MaDMH,@NgayDat,@NgayGiao,@MaNV,@MaNCC", p);
        }

        // 5. Xóa
        public int DonMH_Xoa(int MaDMH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", MaDMH)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonMH_Xoa @MaDMH", p);
        }
        // Thao tác trên bảng CTMH

        // 1. Danh sách
        public List<CTMH> CTMH_DanhSach()
        {
            return CTMHs.FromSqlRaw("EXEC CTMH_DS").ToList();
        }

        // 2. Chi tiết
        public CTMH CTMH_ChiTiet(int MaDMH, string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", MaDMH),
        new SqlParameter("@MaSP", MaSP)
    };

            return CTMHs.FromSqlRaw("EXEC CTMH_CT @MaDMH,@MaSP", p)
                        .ToList()
                        .FirstOrDefault();
        }

        // 3. Thêm
        public int CTMH_Them(CTMH ctmh)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", ctmh.MaDMH),
        new SqlParameter("@MaSP", ctmh.MaSP),
        new SqlParameter("@SLM", ctmh.SLM),
        new SqlParameter("@DGM", ctmh.DGM)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTMH_Them @MaDMH,@MaSP,@SLM,@DGM", p);
        }

        // 4. Sửa
        public int CTMH_Sua(CTMH ctmh)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", ctmh.MaDMH),
        new SqlParameter("@MaSP", ctmh.MaSP),
        new SqlParameter("@SLM", ctmh.SLM),
        new SqlParameter("@DGM", ctmh.DGM)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTMH_Sua @MaDMH,@MaSP,@SLM,@DGM", p);
        }

        // 5. Xóa
        public int CTMH_Xoa(int MaDMH, string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaDMH", MaDMH),
        new SqlParameter("@MaSP", MaSP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTMH_Xoa @MaDMH,@MaSP", p);
        }
        // Thao tác trên bảng KhachHang

        // 1. Danh sách
        public List<KhachHang> KhachHang_DanhSach()
        {
            return KhachHangs.FromSqlRaw("EXEC KhachHang_DS").ToList();
        }

        // 2. Chi tiết
        public KhachHang KhachHang_ChiTiet(int MaKH)
        {
            var p = new[]
            {
        new SqlParameter("@MaKH", MaKH)
    };

            return KhachHangs.FromSqlRaw("EXEC KhachHang_CT @MaKH", p)
                            .ToList()
                            .FirstOrDefault();
        }

        // 3. Thêm
        public int KhachHang_Them(KhachHang khachHang)
        {
            var p = new[]
            {
        new SqlParameter("@HoKH", khachHang.HoKH),
        new SqlParameter("@TenKH", khachHang.TenKH),
        new SqlParameter("@DienThoai", khachHang.DienThoai),
        new SqlParameter("@Email", khachHang.Email),
        new SqlParameter("@DiaChi", khachHang.DiaChi),
        new SqlParameter("@MaXP", khachHang.MaXP),
        new SqlParameter("@TenDN", khachHang.TenDN),
        new SqlParameter("@MatKhau",
            (object)khachHang.MatKhau ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC KhachHang_Them @HoKH,@TenKH,@DienThoai,@Email," +
                "@DiaChi,@MaXP,@TenDN,@MatKhau", p);
        }

        // 4. Sửa
        public int KhachHang_Sua(KhachHang khachHang)
        {
            var p = new[]
            {
        new SqlParameter("@MaKH", khachHang.MaKH),
        new SqlParameter("@HoKH", khachHang.HoKH),
        new SqlParameter("@TenKH", khachHang.TenKH),
        new SqlParameter("@DienThoai", khachHang.DienThoai),
        new SqlParameter("@Email", khachHang.Email),
        new SqlParameter("@DiaChi", khachHang.DiaChi),
        new SqlParameter("@MaXP", khachHang.MaXP),
        new SqlParameter("@TenDN", khachHang.TenDN),
        new SqlParameter("@MatKhau",
            (object)khachHang.MatKhau ?? DBNull.Value)
    };

            return Database.ExecuteSqlRaw(
                "EXEC KhachHang_Sua @MaKH,@HoKH,@TenKH,@DienThoai,@Email," +
                "@DiaChi,@MaXP,@TenDN,@MatKhau", p);
        }

        // 5. Xóa
        public int KhachHang_Xoa(int MaKH)
        {
            var p = new[]
            {
        new SqlParameter("@MaKH", MaKH)
    };

            return Database.ExecuteSqlRaw(
                "EXEC KhachHang_Xoa @MaKH", p);
        }
        // Thao tác trên bảng DonBH

        // 1. Danh sách
        public List<DonBH> DonBH_DanhSach()
        {
            return DonBHs.FromSqlRaw("EXEC DonBH_DS").ToList();
        }

        // 2. Chi tiết
        public DonBH DonBH_ChiTiet(int MaDBH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", MaDBH)
    };

            return DonBHs.FromSqlRaw("EXEC DonBH_CT @MaDBH", p)
                         .ToList()
                         .FirstOrDefault();
        }

        // 3. Thêm
        public int DonBH_Them(DonBH donBH)
        {
            var p = new[]
            {
        new SqlParameter("@NgayDat", donBH.NgayDat),
        new SqlParameter("@NgayGiao",
            (object)donBH.NgayGiao ?? DBNull.Value),
        new SqlParameter("@DCGH", donBH.DCGH),
        new SqlParameter("@MaXP", donBH.MaXP),
        new SqlParameter("@MaNV", donBH.MaNV),
        new SqlParameter("@MaKH", donBH.MaKH)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonBH_Them @NgayDat,@NgayGiao,@DCGH,@MaXP,@MaNV,@MaKH", p);
        }

        // 4. Sửa
        public int DonBH_Sua(DonBH donBH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", donBH.MaDBH),
        new SqlParameter("@NgayDat", donBH.NgayDat),
        new SqlParameter("@NgayGiao",
            (object)donBH.NgayGiao ?? DBNull.Value),
        new SqlParameter("@DCGH", donBH.DCGH),
        new SqlParameter("@MaXP", donBH.MaXP),
        new SqlParameter("@MaNV", donBH.MaNV),
        new SqlParameter("@MaKH", donBH.MaKH)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonBH_Sua @MaDBH,@NgayDat,@NgayGiao,@DCGH,@MaXP,@MaNV,@MaKH",
                p);
        }

        // 5. Xóa
        public int DonBH_Xoa(int MaDBH)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", MaDBH)
    };

            return Database.ExecuteSqlRaw(
                "EXEC DonBH_Xoa @MaDBH", p);
        }
        // Thao tác trên bảng CTBH

        // 1. Danh sách
        public List<CTBH> CTBH_DanhSach()
        {
            return CTBHs.FromSqlRaw("EXEC CTBH_DS").ToList();
        }

        // 2. Chi tiết
        public CTBH CTBH_ChiTiet(int MaDBH, string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", MaDBH),
        new SqlParameter("@MaSP", MaSP)
    };

            return CTBHs.FromSqlRaw("EXEC CTBH_CT @MaDBH,@MaSP", p)
                        .ToList()
                        .FirstOrDefault();
        }

        // 3. Thêm
        public int CTBH_Them(CTBH ctbh)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", ctbh.MaDBH),
        new SqlParameter("@MaSP", ctbh.MaSP),
        new SqlParameter("@SLB", ctbh.SLB),
        new SqlParameter("@DGB", ctbh.DGB)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTBH_Them @MaDBH,@MaSP,@SLB,@DGB", p);
        }

        // 4. Sửa
        public int CTBH_Sua(CTBH ctbh)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", ctbh.MaDBH),
        new SqlParameter("@MaSP", ctbh.MaSP),
        new SqlParameter("@SLB", ctbh.SLB),
        new SqlParameter("@DGB", ctbh.DGB)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTBH_Sua @MaDBH,@MaSP,@SLB,@DGB", p);
        }

        // 5. Xóa
        public int CTBH_Xoa(int MaDBH, string MaSP)
        {
            var p = new[]
            {
        new SqlParameter("@MaDBH", MaDBH),
        new SqlParameter("@MaSP", MaSP)
    };

            return Database.ExecuteSqlRaw(
                "EXEC CTBH_Xoa @MaDBH,@MaSP", p);
        }
    }
}