﻿/*
CHẠY TRONG SSMS TRÊN CƠ SỞ DỮ LIỆU GỐC DbQLBH (đổi USE nếu bạn dùng tên khác).
Giữ nguyên bảng, cột, khóa và thông tin cũ; chỉ bổ sung ảnh nếu trường ảnh trống.
Hỗ trợ NhomSP(MaNSP, TenSP) và NhomSP(MaNSP, TenNSP).
- Đối chiếu dữ liệu theo tên, tài khoản, email hoặc khóa ghép trước khi thêm.
- Lấy đúng mã đã có để gán khóa ngoại; không giả định mã 1, 2, 3.
- Hỗ trợ cả khóa số IDENTITY và khóa số được cấp thủ công.
- Nếu mã sản phẩm mẫu trùng mã cũ, tự chọn một mã CPD khác còn trống.
- Chỉ bổ sung ảnh vào trường ảnh đang trống (có thể tắt ở biến bên dưới).
- Chỉ tạo các stored procedure ứng dụng đang gọi nếu CHƯA CÓ; giữ nguyên procedure cũ.
- Toàn bộ phần ghi dữ liệu / procedure nằm trong một transaction; có lỗi sẽ rollback.
Có thể chạy lại nguyên file: dữ liệu mẫu không bị nhân đôi.
*/
USE [DbQLBH];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF DB_NAME() IN (N'master',N'model',N'msdb',N'tempdb')
    THROW 51000, N'Hãy chọn cơ sở dữ liệu gốc DbQLBH trước khi chạy.', 1;
IF TRY_CONVERT(int,SERVERPROPERTY('ProductMajorVersion')) < 14 OR (SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()) < 130
    THROW 51000, N'Script cần SQL Server 2017+ và compatibility_level từ 130. Không có dữ liệu nào được thay đổi.', 1;
DROP PROCEDURE IF EXISTS #CpsSeedRow;
DROP TABLE IF EXISTS #CpsTables;
DROP TABLE IF EXISTS #CpsColumns;
DROP TABLE IF EXISTS #CpsMap;
CREATE TABLE #CpsTables (Entity sysname COLLATE DATABASE_DEFAULT PRIMARY KEY, ObjectId int NULL, FullName nvarchar(520) COLLATE DATABASE_DEFAULT NULL, PkColumn sysname COLLATE DATABASE_DEFAULT NULL, KeyColumns nvarchar(120) COLLATE DATABASE_DEFAULT NOT NULL, Ready bit NOT NULL DEFAULT 0);
CREATE TABLE #CpsColumns (Entity sysname COLLATE DATABASE_DEFAULT, ColumnName sysname COLLATE DATABASE_DEFAULT, Position int, PRIMARY KEY(Entity,ColumnName));
CREATE TABLE #CpsMap (Entity sysname COLLATE DATABASE_DEFAULT, SeedKey nvarchar(100) COLLATE DATABASE_DEFAULT, RowId nvarchar(100) COLLATE DATABASE_DEFAULT NULL, WasInserted bit NOT NULL, ImageFilled bit NOT NULL, PRIMARY KEY(Entity,SeedKey));
INSERT #CpsTables(Entity,PkColumn,KeyColumns) VALUES
(N'NhomSP',N'MaNSP',N'MaNSP'),
(N'LoaiSP',N'MaLSP',N'MaLSP'),
(N'DonViTinh',N'MaDVT',N'MaDVT'),
(N'Tinh',N'MaTinh',N'MaTinh'),
(N'XaPhuong',N'MaXP',N'MaXP'),
(N'PhongBan',N'MaPB',N'MaPB'),
(N'NhanVien',N'MaNV',N'MaNV'),
(N'Quyen',N'MaQuyen',N'MaQuyen'),
(N'PhanQuyen',NULL,N'MaQuyen,MaNV'),
(N'NhaCC',N'MaNCC',N'MaNCC'),
(N'SanPham',N'MaSP',N'MaSP'),
(N'DonMH',N'MaDMH',N'MaDMH'),
(N'CTMH',NULL,N'MaDMH,MaSP'),
(N'KhachHang',N'MaKH',N'MaKH'),
(N'DonBH',N'MaDBH',N'MaDBH'),
(N'CTBH',NULL,N'MaDBH,MaSP');
INSERT #CpsColumns(Entity,ColumnName,Position) VALUES
(N'NhomSP',N'MaNSP',0),
(N'NhomSP',N'TenNSP',1),
(N'LoaiSP',N'MaLSP',0),
(N'LoaiSP',N'TenLSP',1),
(N'LoaiSP',N'MaNSP',2),
(N'DonViTinh',N'MaDVT',0),
(N'DonViTinh',N'TenDVT',1),
(N'Tinh',N'MaTinh',0),
(N'Tinh',N'TenTinh',1),
(N'XaPhuong',N'MaXP',0),
(N'XaPhuong',N'TenXP',1),
(N'XaPhuong',N'MaTinh',2),
(N'PhongBan',N'MaPB',0),
(N'PhongBan',N'TenPB',1),
(N'NhanVien',N'MaNV',0),
(N'NhanVien',N'HoNV',1),
(N'NhanVien',N'TenNV',2),
(N'NhanVien',N'DienThoai',3),
(N'NhanVien',N'Email',4),
(N'NhanVien',N'TenDN',5),
(N'NhanVien',N'MatKhau',6),
(N'NhanVien',N'AnhNV',7),
(N'NhanVien',N'MaPB',8),
(N'Quyen',N'MaQuyen',0),
(N'Quyen',N'TenQuyen',1),
(N'Quyen',N'MoTa',2),
(N'PhanQuyen',N'MaQuyen',0),
(N'PhanQuyen',N'MaNV',1),
(N'NhaCC',N'MaNCC',0),
(N'NhaCC',N'TenNCC',1),
(N'NhaCC',N'DienThoai',2),
(N'NhaCC',N'Email',3),
(N'NhaCC',N'DiaChi',4),
(N'NhaCC',N'MaXP',5),
(N'SanPham',N'MaSP',0),
(N'SanPham',N'TenSP',1),
(N'SanPham',N'DonGia',2),
(N'SanPham',N'AnhSP',3),
(N'SanPham',N'MoTaCT',4),
(N'SanPham',N'MaLSP',5),
(N'SanPham',N'MaDVT',6),
(N'DonMH',N'MaDMH',0),
(N'DonMH',N'NgayDat',1),
(N'DonMH',N'NgayGiao',2),
(N'DonMH',N'MaNV',3),
(N'DonMH',N'MaNCC',4),
(N'CTMH',N'MaDMH',0),
(N'CTMH',N'MaSP',1),
(N'CTMH',N'SLM',2),
(N'CTMH',N'DGM',3),
(N'KhachHang',N'MaKH',0),
(N'KhachHang',N'HoKH',1),
(N'KhachHang',N'TenKH',2),
(N'KhachHang',N'DienThoai',3),
(N'KhachHang',N'Email',4),
(N'KhachHang',N'DiaChi',5),
(N'KhachHang',N'MaXP',6),
(N'KhachHang',N'TenDN',7),
(N'KhachHang',N'MatKhau',8),
(N'DonBH',N'MaDBH',0),
(N'DonBH',N'NgayDat',1),
(N'DonBH',N'NgayGiao',2),
(N'DonBH',N'DCGH',3),
(N'DonBH',N'MaXP',4),
(N'DonBH',N'MaNV',5),
(N'DonBH',N'MaKH',6),
(N'CTBH',N'MaDBH',0),
(N'CTBH',N'MaSP',1),
(N'CTBH',N'SLB',2),
(N'CTBH',N'DGB',3);

-- Chỉ nhận một bảng khớp tên cũ (dạng số ít hoặc số nhiều); dừng nếu mơ hồ.
DECLARE @entity sysname, @objectId int, @fullName nvarchar(520), @candidates int, @message nvarchar(2048);
DECLARE table_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT Entity FROM #CpsTables;
OPEN table_cursor;
FETCH NEXT FROM table_cursor INTO @entity;
WHILE @@FETCH_STATUS=0
BEGIN
    SELECT @candidates=COUNT(*), @objectId=MIN(t.object_id)
    FROM sys.tables t WHERE t.name IN (@entity,@entity+N's');
    IF @candidates<>1
    BEGIN
        SET @message=N'Không tìm được duy nhất bảng '+@entity+N'. Hãy dùng CSDL gốc có đúng các bảng của ứng dụng. Chưa có thay đổi nào.';
        THROW 51001, @message, 1;
    END;
    SET @fullName=QUOTENAME(OBJECT_SCHEMA_NAME(@objectId))+N'.'+QUOTENAME(OBJECT_NAME(@objectId));
    UPDATE #CpsTables SET ObjectId=@objectId,FullName=@fullName WHERE Entity=@entity;
    -- CSDL gốc có thể dùng TenSP; model vẫn nhận TenNSP qua procedure.
    -- Chỉ ánh xạ tên đã xác nhận, không đổi tên cột của bảng.
    IF @entity=N'NhomSP'
       AND NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=@objectId AND name=N'TenNSP')
       AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id=@objectId AND name=N'TenSP')
        UPDATE #CpsColumns SET ColumnName=N'TenSP' WHERE Entity=N'NhomSP' AND ColumnName=N'TenNSP';
    IF EXISTS (SELECT 1 FROM #CpsColumns ec WHERE ec.Entity=@entity AND NOT EXISTS (SELECT 1 FROM sys.columns c WHERE c.object_id=@objectId AND c.name=ec.ColumnName))
    BEGIN
        SET @message=N'Bảng '+@fullName+N' thiếu cột so với mã nguồn. Script đã dừng, không sửa cấu trúc bảng.';
        THROW 51002,@message,1;
    END;
    UPDATE #CpsTables SET Ready=1 WHERE Entity=@entity;
    FETCH NEXT FROM table_cursor INTO @entity;
END;
CLOSE table_cursor;
DEALLOCATE table_cursor;
GO
CREATE PROCEDURE #CpsSeedRow
    @Entity sysname, @SeedKey nvarchar(100), @Match nvarchar(500),
    @Values nvarchar(max), @FillBlankImages bit=1
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @table nvarchar(520), @object int, @pk sysname, @where nvarchar(max)=N'',
        @cols nvarchar(max), @vals nvarchar(max), @sql nvarchar(max), @id nvarchar(100),
        @didInsert bit=0, @filled bit=0, @matchGroup nvarchar(500), @and nvarchar(max),
        @column sysname, @image sysname, @n bigint, @limit bigint, @type sysname;
    SELECT @table=FullName,@object=ObjectId,@pk=PkColumn FROM #CpsTables WHERE Entity=@Entity;
    IF @table IS NULL THROW 51003,N'Bảng không nằm trong danh mục cho phép.',1;
    IF @Entity=N'NhomSP' AND EXISTS (SELECT 1 FROM #CpsColumns WHERE Entity=@Entity AND ColumnName=N'TenSP')
    BEGIN
        SET @Values=JSON_MODIFY(@Values,N'$.TenSP',JSON_VALUE(@Values,N'$.TenNSP'));
        SET @Values=JSON_MODIFY(@Values,N'$.TenNSP',NULL);
        SET @Match=REPLACE(@Match,N'TenNSP',N'TenSP');
    END;
    IF EXISTS (SELECT 1 FROM OPENJSON(@Values) j WHERE NOT EXISTS (SELECT 1 FROM #CpsColumns c WHERE c.Entity=@Entity AND c.ColumnName=j.[key] COLLATE DATABASE_DEFAULT))
        THROW 51004,N'Dữ liệu mẫu có cột không khớp mã nguồn.',1;
    -- | là các phương án khớp tương đương; dấu phẩy là khóa ghép.
    DECLARE match_groups CURSOR LOCAL FAST_FORWARD FOR SELECT value FROM STRING_SPLIT(@Match,N'|');
    OPEN match_groups; FETCH NEXT FROM match_groups INTO @matchGroup;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @and=N'';
        DECLARE match_cols CURSOR LOCAL FAST_FORWARD FOR SELECT value FROM STRING_SPLIT(@matchGroup,N',');
        OPEN match_cols; FETCH NEXT FROM match_cols INTO @column;
        WHILE @@FETCH_STATUS=0
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM #CpsColumns WHERE Entity=@Entity AND ColumnName=@column)
                THROW 51005,N'Cột đối chiếu không hợp lệ.',1;
            SET @and+=CASE WHEN @and=N'' THEN N'' ELSE N' AND ' END+QUOTENAME(@column)+N'=JSON_VALUE(@json,''$."'+@column+N'"'')';
            FETCH NEXT FROM match_cols INTO @column;
        END;
        CLOSE match_cols; DEALLOCATE match_cols;
        SET @where+=CASE WHEN @where=N'' THEN N'' ELSE N' OR ' END+N'('+@and+N')';
        FETCH NEXT FROM match_groups INTO @matchGroup;
    END;
    CLOSE match_groups; DEALLOCATE match_groups;
    IF NULLIF(@where,N'') IS NULL THROW 51006,N'Thiếu khóa đối chiếu dữ liệu mẫu.',1;
    SET @sql=N'SELECT TOP (1) @id='+CASE WHEN @pk IS NULL THEN N'N''exists''' ELSE N'CONVERT(nvarchar(100),'+QUOTENAME(@pk)+N')' END+N' FROM '+@table+N' WITH (UPDLOCK,HOLDLOCK) WHERE '+@where+CASE WHEN @pk IS NULL THEN N'' ELSE N' ORDER BY '+QUOTENAME(@pk) END+N';';
    EXEC sys.sp_executesql @sql,N'@json nvarchar(max),@id nvarchar(100) OUTPUT',@Values,@id OUTPUT;
    IF @id IS NULL
    BEGIN
        IF @pk IS NOT NULL AND COLUMNPROPERTY(@object,@pk,'IsIdentity')=0
        BEGIN
            SELECT @type=TYPE_NAME(system_type_id) FROM sys.columns WHERE object_id=@object AND name=@pk;
            IF @type IN (N'tinyint',N'smallint',N'int',N'bigint')
            BEGIN
                SET @limit=CASE @type WHEN N'tinyint' THEN 255 WHEN N'smallint' THEN 32767 ELSE 2147483647 END;
                SET @n=1;
                SET @sql=N'WHILE EXISTS (SELECT 1 FROM '+@table+N' WITH (UPDLOCK,HOLDLOCK) WHERE '+QUOTENAME(@pk)+N'=@n) SET @n+=1;';
                EXEC sys.sp_executesql @sql,N'@n bigint OUTPUT',@n OUTPUT;
                IF @n>@limit THROW 51007,N'Không còn mã số phù hợp. Không thay đổi cấu trúc bảng.',1;
                SET @Values=JSON_MODIFY(@Values,N'$."'+@pk+N'"',@n);
            END
            ELSE IF @Entity=N'SanPham'
            BEGIN
                -- Không ghi đè sản phẩm cũ kể cả khi mã CPD mẫu đã được dùng.
                SET @n=1;
                SET @sql=N'WHILE EXISTS (SELECT 1 FROM '+@table+N' WITH (UPDLOCK,HOLDLOCK) WHERE '+QUOTENAME(@pk)+N'=N''CPD''+RIGHT(N''000000''+CONVERT(nvarchar(6),@n),6)) SET @n+=1;';
                EXEC sys.sp_executesql @sql,N'@n bigint OUTPUT',@n OUTPUT;
                IF @n>999999 THROW 51008,N'Không còn mã sản phẩm mẫu phù hợp.',1;
                SET @Values=JSON_MODIFY(@Values,N'$."'+@pk+N'"',N'CPD'+RIGHT(N'000000'+CONVERT(nvarchar(6),@n),6));
            END;
        END;
        SELECT @cols=STRING_AGG(CONVERT(nvarchar(max),QUOTENAME(j.[key])),N','),
            @vals=STRING_AGG(CONVERT(nvarchar(max),CASE WHEN j.[type]=0 THEN N'NULL' ELSE N'JSON_VALUE(@json,''$."'+j.[key]+N'"'')' END),N',')
        FROM OPENJSON(@Values) j WHERE NOT (@pk IS NOT NULL AND j.[key] COLLATE DATABASE_DEFAULT=@pk AND COLUMNPROPERTY(@object,@pk,'IsIdentity')=1);
        SET @sql=CASE WHEN @pk IS NULL THEN N'' ELSE N'DECLARE @new TABLE(Id nvarchar(100));' END+
            N'INSERT INTO '+@table+N'('+@cols+N') '+CASE WHEN @pk IS NULL THEN N'' ELSE N'OUTPUT CONVERT(nvarchar(100),inserted.'+QUOTENAME(@pk)+N') INTO @new ' END+
            N'VALUES ('+@vals+N');'+CASE WHEN @pk IS NULL THEN N'SET @id=N''exists'';' ELSE N'SELECT @id=Id FROM @new;' END;
        EXEC sys.sp_executesql @sql,N'@json nvarchar(max),@id nvarchar(100) OUTPUT',@Values,@id OUTPUT;
        SET @didInsert=1;
    END
    ELSE IF @FillBlankImages=1 AND @Entity IN (N'SanPham',N'NhanVien')
    BEGIN
        SET @image=CASE @Entity WHEN N'SanPham' THEN N'AnhSP' ELSE N'AnhNV' END;
        SET @sql=N'UPDATE '+@table+N' SET '+QUOTENAME(@image)+N'=JSON_VALUE(@json,''$."'+@image+N'"'') WHERE '+QUOTENAME(@pk)+N'=@id AND NULLIF(LTRIM(RTRIM('+QUOTENAME(@image)+N')),N'''') IS NULL; SET @filled=CASE WHEN @@ROWCOUNT>0 THEN 1 ELSE 0 END;';
        EXEC sys.sp_executesql @sql,N'@json nvarchar(max),@id nvarchar(100),@filled bit OUTPUT',@Values,@id,@filled OUTPUT;
    END;
    INSERT #CpsMap VALUES(@Entity,@SeedKey,@id,@didInsert,@filled);
END;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
-- Đổi thành 0 nếu muốn giữ nguyên cả những ô ảnh đang trống.
DECLARE @BoSungAnhTrong bit=1;
-- Đổi thành 0 nếu chỉ muốn thêm dữ liệu, không bổ sung procedure còn thiếu.
DECLARE @TaoThuTucConThieu bit=1;
DECLARE @values nvarchar(max), @lockResult int;
-- SSMS có thể chạy tiếp batch sau GO khi batch trước lỗi: dừng trước mọi thao tác ghi.
IF EXISTS (SELECT 1 FROM #CpsTables WHERE Ready=0 OR ObjectId IS NULL)
    THROW 51013,N'Kiểm tra cấu trúc chưa thành công. Hãy gửi thông báo thiếu cột đầu tiên; chưa thêm dữ liệu.',1;

BEGIN TRY
    BEGIN TRANSACTION;
    EXEC @lockResult=sys.sp_getapplock @Resource=N'Cellphones_DemoData_v1',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=10000;
    IF @lockResult<0 THROW 51009,N'Có phiên khác đang nạp dữ liệu mẫu. Hãy thử lại sau.',1;
    SET @values=N'{"TenNSP":"Điện thoại"}';
    EXEC #CpsSeedRow @Entity=N'NhomSP',@SeedKey=N'phone',@Match=N'TenNSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNSP":"Máy tính"}';
    EXEC #CpsSeedRow @Entity=N'NhomSP',@SeedKey=N'computer',@Match=N'TenNSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNSP":"Phụ kiện"}';
    EXEC #CpsSeedRow @Entity=N'NhomSP',@SeedKey=N'accessory',@Match=N'TenNSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNSP":"Thiết bị đeo"}';
    EXEC #CpsSeedRow @Entity=N'NhomSP',@SeedKey=N'wearable',@Match=N'TenNSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenDVT":"Chiếc"}';
    EXEC #CpsSeedRow @Entity=N'DonViTinh',@SeedKey=N'piece',@Match=N'TenDVT',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenDVT":"Bộ"}';
    EXEC #CpsSeedRow @Entity=N'DonViTinh',@SeedKey=N'set',@Match=N'TenDVT',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenDVT":"Cái"}';
    EXEC #CpsSeedRow @Entity=N'DonViTinh',@SeedKey=N'item',@Match=N'TenDVT',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenTinh":"Khánh Hòa"}';
    EXEC #CpsSeedRow @Entity=N'Tinh',@SeedKey=N'khanhhoa',@Match=N'TenTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenTinh":"Thành phố Hồ Chí Minh"}';
    EXEC #CpsSeedRow @Entity=N'Tinh',@SeedKey=N'hcm',@Match=N'TenTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenTinh":"Hà Nội"}';
    EXEC #CpsSeedRow @Entity=N'Tinh',@SeedKey=N'hanoi',@Match=N'TenTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Nha Trang","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'khanhhoa')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'nhatrang',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Bắc Nha Trang","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'khanhhoa')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'bactrang',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Bến Thành","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'hcm')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'benthanh',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Sài Gòn","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'hcm')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'saigon',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Hoàn Kiếm","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'hanoi')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'hoankiem',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenXP":"Ba Đình","MaTinh":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaTinh"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Tinh' AND SeedKey=N'hanoi')));
    EXEC #CpsSeedRow @Entity=N'XaPhuong',@SeedKey=N'badinh',@Match=N'TenXP,MaTinh',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenPB":"Kinh doanh"}';
    EXEC #CpsSeedRow @Entity=N'PhongBan',@SeedKey=N'sales',@Match=N'TenPB',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenPB":"Kỹ thuật"}';
    EXEC #CpsSeedRow @Entity=N'PhongBan',@SeedKey=N'tech',@Match=N'TenPB',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenPB":"Kho vận"}';
    EXEC #CpsSeedRow @Entity=N'PhongBan',@SeedKey=N'warehouse',@Match=N'TenPB',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenPB":"Hành chính"}';
    EXEC #CpsSeedRow @Entity=N'PhongBan',@SeedKey=N'admin',@Match=N'TenPB',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenQuyen":"Quản lý","MoTa":"Quản lý hoạt động cửa hàng"}';
    EXEC #CpsSeedRow @Entity=N'Quyen',@SeedKey=N'manage',@Match=N'TenQuyen',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenQuyen":"Bán hàng","MoTa":"Theo dõi bán hàng và khách hàng"}';
    EXEC #CpsSeedRow @Entity=N'Quyen',@SeedKey=N'sales',@Match=N'TenQuyen',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenQuyen":"Nhập hàng","MoTa":"Theo dõi hoạt động nhập hàng"}';
    EXEC #CpsSeedRow @Entity=N'Quyen',@SeedKey=N'stock',@Match=N'TenQuyen',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Điện thoại Apple","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'phone')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'apple',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Điện thoại Samsung","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'phone')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'samsung',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Điện thoại Xiaomi","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'phone')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'xiaomi',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Laptop","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'computer')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'laptop',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Máy tính bảng","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'computer')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'tablet',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Âm thanh","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'accessory')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'audio',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Phụ kiện sạc","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'accessory')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'power',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenLSP":"Đồng hồ","MaNSP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhomSP' AND SeedKey=N'wearable')));
    EXEC #CpsSeedRow @Entity=N'LoaiSP',@SeedKey=N'watch',@Match=N'TenLSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Nguyễn Minh","TenNV":"Anh","DienThoai":"0900000101","Email":"nv01@cellphones-demo.example","TenDN":"demo.nv01","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-01.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'sales')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv01',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'manage')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv01')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv01',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Trần Ngọc","TenNV":"Linh","DienThoai":"0900000102","Email":"nv02@cellphones-demo.example","TenDN":"demo.nv02","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-02.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'sales')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv02',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'sales')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv02')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv02',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Lê Quốc","TenNV":"Huy","DienThoai":"0900000103","Email":"nv03@cellphones-demo.example","TenDN":"demo.nv03","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-03.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'tech')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv03',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'sales')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv03')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv03',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Phạm Thảo","TenNV":"Vy","DienThoai":"0900000104","Email":"nv04@cellphones-demo.example","TenDN":"demo.nv04","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-04.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'warehouse')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv04',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'stock')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv04')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv04',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Võ Hoàng","TenNV":"Nam","DienThoai":"0900000105","Email":"nv05@cellphones-demo.example","TenDN":"demo.nv05","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-05.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'tech')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv05',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'sales')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv05')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv05',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoNV":"Đặng Khánh","TenNV":"Ngân","DienThoai":"0900000106","Email":"nv06@cellphones-demo.example","TenDN":"demo.nv06","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A==","AnhNV":"/images/staff/nhan-vien-06.jpg","MaPB":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaPB"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'PhongBan' AND SeedKey=N'admin')));
    EXEC #CpsSeedRow @Entity=N'NhanVien',@SeedKey=N'nv06',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaQuyen":0,"MaNV":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaQuyen"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'Quyen' AND SeedKey=N'sales')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv06')));
    EXEC #CpsSeedRow @Entity=N'PhanQuyen',@SeedKey=N'nv06',@Match=N'MaQuyen,MaNV',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNCC":"Công ty Công nghệ Sao Việt - Demo","DienThoai":"02800000001","Email":"ncc1@cellphones-demo.example","DiaChi":"11 Đường Minh Họa","MaXP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'nhatrang')));
    EXEC #CpsSeedRow @Entity=N'NhaCC',@SeedKey=N'ncc1',@Match=N'TenNCC|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNCC":"Công ty Phân phối Minh Phát - Demo","DienThoai":"02800000002","Email":"ncc2@cellphones-demo.example","DiaChi":"12 Đường Minh Họa","MaXP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'benthanh')));
    EXEC #CpsSeedRow @Entity=N'NhaCC',@SeedKey=N'ncc2',@Match=N'TenNCC|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNCC":"Công ty Thiết bị An Phú - Demo","DienThoai":"02800000003","Email":"ncc3@cellphones-demo.example","DiaChi":"13 Đường Minh Họa","MaXP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'hoankiem')));
    EXEC #CpsSeedRow @Entity=N'NhaCC',@SeedKey=N'ncc3',@Match=N'TenNCC|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"TenNCC":"Công ty Phụ kiện Ánh Dương - Demo","DienThoai":"02800000004","Email":"ncc4@cellphones-demo.example","DiaChi":"14 Đường Minh Họa","MaXP":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'saigon')));
    EXEC #CpsSeedRow @Entity=N'NhaCC',@SeedKey=N'ncc4',@Match=N'TenNCC|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000001","TenSP":"iPhone 15 128GB - Hồng","DonGia":15990000,"AnhSP":"/images/products/iphone-15.jpg","MoTaCT":"Màn hình 6.1 inch, chip A16 Bionic, camera 48MP.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'apple')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp01',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000002","TenSP":"iPhone 16 Pro Max 256GB - Titan","DonGia":29990000,"AnhSP":"/images/products/iphone-16.jpg","MoTaCT":"Màn hình 6.9 inch, chip A18 Pro, bộ nhớ 256GB.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'apple')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp02',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000003","TenSP":"Samsung Galaxy S24 Ultra 256GB","DonGia":24990000,"AnhSP":"/images/products/samsung-s24.jpg","MoTaCT":"Bút S Pen, màn hình AMOLED, camera 200MP.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'samsung')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp03',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000004","TenSP":"Samsung Galaxy A55 5G 128GB","DonGia":8990000,"AnhSP":"/images/products/samsung-a55.jpg","MoTaCT":"Màn hình Super AMOLED 120Hz, pin 5000mAh.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'samsung')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp04',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000005","TenSP":"Xiaomi Redmi Note 13 Pro+ 256GB","DonGia":9990000,"AnhSP":"/images/products/redmi.jpg","MoTaCT":"Màn hình AMOLED, camera 200MP, sạc nhanh 120W.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'xiaomi')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp05',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000006","TenSP":"MacBook Air M2 13 inch 8GB 256GB","DonGia":18990000,"AnhSP":"/images/products/macbook-air.jpg","MoTaCT":"Chip Apple M2, màn hình Liquid Retina, máy mỏng nhẹ.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'laptop')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp06',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000007","TenSP":"iPad Air M2 11 inch Wi-Fi 128GB","DonGia":14990000,"AnhSP":"/images/products/ipad-air.jpg","MoTaCT":"Chip Apple M2, màn hình 11 inch, bộ nhớ 128GB.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'tablet')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp07',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000008","TenSP":"AirPods Pro 2 USB-C","DonGia":4990000,"AnhSP":"/images/products/airpods.jpg","MoTaCT":"Chống ồn chủ động, âm thanh không gian, cổng USB-C.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'audio')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp08',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000009","TenSP":"Apple Watch SE 2023 GPS 40mm","DonGia":5490000,"AnhSP":"/images/products/watch-se.jpg","MoTaCT":"Theo dõi vận động, thông báo cuộc gọi và sức khỏe.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'watch')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp09',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000010","TenSP":"Pin dự phòng 20000mAh","DonGia":590000,"AnhSP":"/images/products/powerbank.jpg","MoTaCT":"Dung lượng 20000mAh, thiết kế nhỏ gọn, dễ mang theo.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'power')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp10',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000011","TenSP":"iPhone 15 256GB - Hồng","DonGia":18490000,"AnhSP":"/images/products/iphone-15.jpg","MoTaCT":"Chip A16 Bionic, bộ nhớ 256GB, camera 48MP.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'apple')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp11',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000012","TenSP":"Samsung Galaxy A55 5G 256GB","DonGia":9990000,"AnhSP":"/images/products/samsung-a55.jpg","MoTaCT":"Bộ nhớ 256GB, màn hình AMOLED 120Hz, pin 5000mAh.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'samsung')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp12',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000013","TenSP":"MacBook Air M2 13 inch 16GB 256GB","DonGia":21990000,"AnhSP":"/images/products/macbook-air.jpg","MoTaCT":"Chip Apple M2, RAM 16GB, SSD 256GB.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'laptop')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp13',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000014","TenSP":"iPad Air M2 11 inch Wi-Fi 256GB","DonGia":17490000,"AnhSP":"/images/products/ipad-air.jpg","MoTaCT":"Màn hình Liquid Retina 11 inch, bộ nhớ 256GB.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'tablet')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp14',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000015","TenSP":"Xiaomi Redmi Note 13 Pro+ 512GB","DonGia":11490000,"AnhSP":"/images/products/redmi.jpg","MoTaCT":"Bộ nhớ 512GB, camera 200MP, màn hình AMOLED.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'xiaomi')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp15',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaSP":"CPD000016","TenSP":"iPhone 16 Pro Max 512GB - Titan","DonGia":35990000,"AnhSP":"/images/products/iphone-16.jpg","MoTaCT":"Chip A18 Pro, bộ nhớ 512GB, màn hình 6.9 inch.","MaLSP":0,"MaDVT":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaLSP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'LoaiSP' AND SeedKey=N'apple')));
    SET @values=JSON_MODIFY(@values,N'$."MaDVT"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonViTinh' AND SeedKey=N'piece')));
    EXEC #CpsSeedRow @Entity=N'SanPham',@SeedKey=N'sp16',@Match=N'TenSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Nguyễn Văn","TenKH":"An","DienThoai":"0910000101","Email":"kh01@cellphones-demo.example","DiaChi":"21 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh01","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'nhatrang')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh1',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Trần Thị","TenKH":"Bình","DienThoai":"0910000102","Email":"kh02@cellphones-demo.example","DiaChi":"22 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh02","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'bactrang')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh2',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Lê Minh","TenKH":"Châu","DienThoai":"0910000103","Email":"kh03@cellphones-demo.example","DiaChi":"23 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh03","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'benthanh')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh3',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Phạm Ngọc","TenKH":"Duy","DienThoai":"0910000104","Email":"kh04@cellphones-demo.example","DiaChi":"24 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh04","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'saigon')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh4',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Võ Thị","TenKH":"Hà","DienThoai":"0910000105","Email":"kh05@cellphones-demo.example","DiaChi":"25 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh05","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'hoankiem')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh5',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Đặng Quốc","TenKH":"Kiệt","DienThoai":"0910000106","Email":"kh06@cellphones-demo.example","DiaChi":"26 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh06","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'badinh')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh6',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Bùi Thanh","TenKH":"Lam","DienThoai":"0910000107","Email":"kh07@cellphones-demo.example","DiaChi":"27 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh07","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'nhatrang')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh7',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"HoKH":"Hoàng Minh","TenKH":"Tuấn","DienThoai":"0910000108","Email":"kh08@cellphones-demo.example","DiaChi":"28 Đường Khách Hàng Mẫu","MaXP":0,"TenDN":"demo.kh08","MatKhau":"AQAAAAIAAYagAAAAECsg7Y9kiLzxAsCin2pRU722MKQ4JFKJY5nM2ie4s/nsG+qlD4I07/rfEg6OHkQJ3A=="}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'benthanh')));
    EXEC #CpsSeedRow @Entity=N'KhachHang',@SeedKey=N'kh8',@Match=N'TenDN|Email',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-11T09:00:00","NgayGiao":"2026-10-13T09:00:00","MaNV":0,"MaNCC":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv04')));
    SET @values=JSON_MODIFY(@values,N'$."MaNCC"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhaCC' AND SeedKey=N'ncc1')));
    EXEC #CpsSeedRow @Entity=N'DonMH',@SeedKey=N'dmh1',@Match=N'NgayDat,MaNV,MaNCC',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":11,"DGM":13591500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp01'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh1-sp1',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":11,"DGM":8491500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp05'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh1-sp5',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":11,"DGM":4666500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp09'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh1-sp9',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":11,"DGM":18691500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp13'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh1-sp13',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-12T09:00:00","NgayGiao":"2026-10-14T09:00:00","MaNV":0,"MaNCC":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv04')));
    SET @values=JSON_MODIFY(@values,N'$."MaNCC"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhaCC' AND SeedKey=N'ncc2')));
    EXEC #CpsSeedRow @Entity=N'DonMH',@SeedKey=N'dmh2',@Match=N'NgayDat,MaNV,MaNCC',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":12,"DGM":25491500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp02'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh2-sp2',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":12,"DGM":16141500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp06'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh2-sp6',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":12,"DGM":501500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp10'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh2-sp10',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":12,"DGM":14866500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp14'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh2-sp14',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-13T09:00:00","NgayGiao":"2026-10-15T09:00:00","MaNV":0,"MaNCC":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv04')));
    SET @values=JSON_MODIFY(@values,N'$."MaNCC"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhaCC' AND SeedKey=N'ncc3')));
    EXEC #CpsSeedRow @Entity=N'DonMH',@SeedKey=N'dmh3',@Match=N'NgayDat,MaNV,MaNCC',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":13,"DGM":21241500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp03'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh3-sp3',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":13,"DGM":12741500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp07'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh3-sp7',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":13,"DGM":15716500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp11'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh3-sp11',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":13,"DGM":9766500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp15'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh3-sp15',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-14T09:00:00","NgayGiao":"2026-10-16T09:00:00","MaNV":0,"MaNCC":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv04')));
    SET @values=JSON_MODIFY(@values,N'$."MaNCC"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhaCC' AND SeedKey=N'ncc4')));
    EXEC #CpsSeedRow @Entity=N'DonMH',@SeedKey=N'dmh4',@Match=N'NgayDat,MaNV,MaNCC',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":14,"DGM":7641500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp04'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh4-sp4',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":14,"DGM":4241500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp08'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh4-sp8',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":14,"DGM":8491500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp12'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh4-sp12',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDMH":0,"MaSP":"","SLM":14,"DGM":30591500}';
    SET @values=JSON_MODIFY(@values,N'$."MaDMH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonMH' AND SeedKey=N'dmh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp16'));
    EXEC #CpsSeedRow @Entity=N'CTMH',@SeedKey=N'dmh4-sp16',@Match=N'MaDMH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-21T10:00:00","NgayGiao":"2026-10-23T10:00:00","DCGH":"21 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'nhatrang')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv01')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh1')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh1',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":15990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp01'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh1-sp1',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":5490000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh1')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp09'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh1-sp9',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-22T10:00:00","NgayGiao":"2026-10-24T10:00:00","DCGH":"22 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'bactrang')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv02')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh2')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh2',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":29990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp02'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh2-sp2',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":590000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh2')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp10'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh2-sp10',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-23T10:00:00","NgayGiao":"2026-10-25T10:00:00","DCGH":"23 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'benthanh')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv01')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh3')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh3',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":24990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp03'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh3-sp3',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":18490000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh3')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp11'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh3-sp11',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-24T10:00:00","NgayGiao":"2026-10-26T10:00:00","DCGH":"24 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'saigon')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv02')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh4')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh4',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":8990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp04'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh4-sp4',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":9990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh4')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp12'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh4-sp12',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-25T10:00:00","NgayGiao":"2026-10-27T10:00:00","DCGH":"25 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'hoankiem')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv01')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh5')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh5',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":9990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh5')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp05'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh5-sp5',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":21990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh5')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp13'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh5-sp13',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-26T10:00:00","NgayGiao":"2026-10-28T10:00:00","DCGH":"26 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'badinh')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv02')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh6')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh6',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":18990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh6')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp06'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh6-sp6',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":17490000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh6')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp14'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh6-sp14',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-27T10:00:00","NgayGiao":null,"DCGH":"27 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'nhatrang')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv01')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh7')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh7',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":14990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh7')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp07'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh7-sp7',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":11490000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh7')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp15'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh7-sp15',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"NgayDat":"2026-10-28T10:00:00","NgayGiao":null,"DCGH":"28 Đường Khách Hàng Mẫu","MaXP":0,"MaNV":0,"MaKH":0}';
    SET @values=JSON_MODIFY(@values,N'$."MaXP"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'XaPhuong' AND SeedKey=N'benthanh')));
    SET @values=JSON_MODIFY(@values,N'$."MaNV"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'NhanVien' AND SeedKey=N'nv02')));
    SET @values=JSON_MODIFY(@values,N'$."MaKH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'KhachHang' AND SeedKey=N'kh8')));
    EXEC #CpsSeedRow @Entity=N'DonBH',@SeedKey=N'dbh8',@Match=N'NgayDat,MaNV,MaKH,DCGH',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":4990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh8')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp08'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh8-sp8',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    SET @values=N'{"MaDBH":0,"MaSP":"","SLB":1,"DGB":35990000}';
    SET @values=JSON_MODIFY(@values,N'$."MaDBH"',CONVERT(int,(SELECT RowId FROM #CpsMap WHERE Entity=N'DonBH' AND SeedKey=N'dbh8')));
    SET @values=JSON_MODIFY(@values,N'$."MaSP"',(SELECT RowId FROM #CpsMap WHERE Entity=N'SanPham' AND SeedKey=N'sp16'));
    EXEC #CpsSeedRow @Entity=N'CTBH',@SeedKey=N'dbh8-sp16',@Match=N'MaDBH,MaSP',@Values=@values,@FillBlankImages=@BoSungAnhTrong;
    -- Bổ sung đúng 5 procedure / bảng mà AppDbContext cũ gọi; không ALTER procedure có sẵn.
    IF @TaoThuTucConThieu=1
    BEGIN
        DECLARE @e sysname,@t nvarchar(520),@obj int,@pk sysname,@keys nvarchar(120),
            @proc sysname,@op nvarchar(12),@params nvarchar(max),@select nvarchar(max),
            @insertCols nvarchar(max),@insertVals nvarchar(max),@updates nvarchar(max),
            @keyWhere nvarchar(max),@definition nvarchar(max),@body nvarchar(max),@hasProc int;
        DECLARE @procColumns TABLE (Name sysname,SqlType nvarchar(256),Pos int,IsKey bit);
        DECLARE entity_procs CURSOR LOCAL FAST_FORWARD FOR SELECT Entity,FullName,ObjectId,PkColumn,KeyColumns FROM #CpsTables;
        OPEN entity_procs; FETCH NEXT FROM entity_procs INTO @e,@t,@obj,@pk,@keys;
        WHILE @@FETCH_STATUS=0
        BEGIN
            DELETE @procColumns;
            INSERT @procColumns
            SELECT c.name,
                CASE WHEN ty.name IN (N'varchar',N'char',N'varbinary',N'binary') THEN ty.name+N'('+CASE WHEN c.max_length=-1 THEN N'max' ELSE CONVERT(nvarchar(10),c.max_length) END+N')'
                     WHEN ty.name IN (N'nvarchar',N'nchar') THEN ty.name+N'('+CASE WHEN c.max_length=-1 THEN N'max' ELSE CONVERT(nvarchar(10),c.max_length/2) END+N')'
                     WHEN ty.name IN (N'decimal',N'numeric') THEN ty.name+N'('+CONVERT(nvarchar(10),c.precision)+N','+CONVERT(nvarchar(10),c.scale)+N')'
                     WHEN ty.name IN (N'datetime2',N'datetimeoffset',N'time') THEN ty.name+N'('+CONVERT(nvarchar(10),c.scale)+N')'
                     ELSE QUOTENAME(ty.name) END,
                ec.Position,CASE WHEN c.name IN (SELECT value FROM STRING_SPLIT(@keys,N',')) THEN 1 ELSE 0 END
            FROM #CpsColumns ec JOIN sys.columns c ON c.object_id=@obj AND c.name=ec.ColumnName
            JOIN sys.types ty ON ty.user_type_id=c.user_type_id WHERE ec.Entity=@e;
            SELECT @select=STRING_AGG(CONVERT(nvarchar(max),QUOTENAME(Name)),N',') WITHIN GROUP(ORDER BY Pos) FROM @procColumns;
            SELECT @keyWhere=STRING_AGG(CONVERT(nvarchar(max),QUOTENAME(Name)+N'=@'+Name),N' AND ') FROM @procColumns WHERE IsKey=1;
            DECLARE ops CURSOR LOCAL FAST_FORWARD FOR SELECT op FROM (VALUES(N'DS'),(N'CT'),(N'Them'),(N'Sua'),(N'Xoa')) x(op);
            OPEN ops; FETCH NEXT FROM ops INTO @op;
            WHILE @@FETCH_STATUS=0
            BEGIN
                SET @proc=@e+N'_'+@op;
                SELECT @hasProc=COUNT(*) FROM sys.procedures WHERE name=@proc;
                IF @hasProc>1 THROW 51010,N'Có procedure trùng tên ở nhiều schema. Hãy kiểm tra procedure gốc.',1;
                IF @hasProc=0
                BEGIN
                    SET @params=N''; SET @body=N'';
                    IF @op=N'DS' SET @body=N'SELECT '+@select+N' FROM '+@t+N';';
                    IF @op IN (N'CT',N'Xoa')
                    BEGIN
                        SELECT @params=STRING_AGG(CONVERT(nvarchar(max),N'@'+Name+N' '+SqlType),N',') FROM @procColumns WHERE IsKey=1;
                        SET @body=CASE WHEN @op=N'CT' THEN N'SELECT '+@select+N' FROM ' ELSE N'DELETE FROM ' END+@t+N' WHERE '+@keyWhere+N';';
                    END;
                    IF @op=N'Them'
                    BEGIN
                        SELECT @params=STRING_AGG(CONVERT(nvarchar(max),N'@'+Name+N' '+SqlType),N',') WITHIN GROUP(ORDER BY Pos),
                            @insertCols=STRING_AGG(CONVERT(nvarchar(max),QUOTENAME(Name)),N',') WITHIN GROUP(ORDER BY Pos),
                            @insertVals=STRING_AGG(CONVERT(nvarchar(max),N'@'+Name),N',') WITHIN GROUP(ORDER BY Pos)
                        FROM @procColumns WHERE NOT (IsKey=1 AND @pk IS NOT NULL AND @e<>N'SanPham');
                        IF @pk IS NOT NULL AND @e<>N'SanPham' AND COLUMNPROPERTY(@obj,@pk,'IsIdentity')=0
                        BEGIN
                            DECLARE @pkType nvarchar(256); SELECT @pkType=SqlType FROM @procColumns WHERE Name=@pk;
                            SET @body=N'SET XACT_ABORT ON; BEGIN TRY BEGIN TRANSACTION; DECLARE @newKey '+@pkType+N'=1; WHILE EXISTS (SELECT 1 FROM '+@t+N' WITH(UPDLOCK,HOLDLOCK) WHERE '+QUOTENAME(@pk)+N'=@newKey) SET @newKey+=1; INSERT '+@t+N'('+QUOTENAME(@pk)+N','+@insertCols+N') VALUES (@newKey,'+@insertVals+N'); COMMIT; END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;';
                        END
                        ELSE SET @body=N'INSERT '+@t+N'('+@insertCols+N') VALUES ('+@insertVals+N');';
                    END;
                    IF @op=N'Sua'
                    BEGIN
                        SELECT @params=STRING_AGG(CONVERT(nvarchar(max),N'@'+Name+N' '+SqlType),N',') WITHIN GROUP(ORDER BY Pos) FROM @procColumns;
                        SELECT @updates=STRING_AGG(CONVERT(nvarchar(max),QUOTENAME(Name)+N'=@'+Name),N',') FROM @procColumns WHERE IsKey=0;
                        SET @body=N'UPDATE '+@t+N' SET '+@updates+N' WHERE '+@keyWhere+N';';
                        IF @e=N'PhanQuyen'
                        BEGIN
                            SET @params=N'@MaQuyenCu tinyint,@MaNVCu smallint,'+@params;
                            SET @body=N'UPDATE '+@t+N' SET [MaQuyen]=@MaQuyen,[MaNV]=@MaNV WHERE [MaQuyen]=@MaQuyenCu AND [MaNV]=@MaNVCu;';
                        END;
                    END;
                    IF @e=N'NhomSP' AND EXISTS(SELECT 1 FROM @procColumns WHERE Name=N'TenSP')
                    BEGIN
                        -- Giữ nguyên tên tham số / tên cột trả về mà C# gốc đang gọi.
                        SET @params=REPLACE(@params,N'@TenSP ',N'@TenNSP ');
                        SET @body=REPLACE(@body,N'@TenSP',N'@TenNSP');
                        IF @op IN (N'DS',N'CT')
                            SET @body=REPLACE(@body,N'[TenSP]',N'[TenSP] AS [TenNSP]');
                    END;
                    SET @definition=N'CREATE PROCEDURE [dbo].'+QUOTENAME(@proc)+N' '+COALESCE(@params,N'')+N' AS BEGIN SET NOCOUNT ON; '+@body+N' END;';
                    EXEC sys.sp_executesql @definition;
                END;
                FETCH NEXT FROM ops INTO @op;
            END;
            CLOSE ops; DEALLOCATE ops;
            FETCH NEXT FROM entity_procs INTO @e,@t,@obj,@pk,@keys;
        END;
        CLOSE entity_procs; DEALLOCATE entity_procs;
    END;
    COMMIT TRANSACTION;
    SELECT Entity AS [Bảng], SUM(CONVERT(int,WasInserted)) AS [Đã thêm],
        SUM(CASE WHEN WasInserted=0 THEN 1 ELSE 0 END) AS [Dùng lại dữ liệu có sẵn],
        SUM(CONVERT(int,ImageFilled)) AS [Đã bổ sung ảnh trống]
    FROM #CpsMap GROUP BY Entity ORDER BY Entity;
    PRINT N'Hoàn tất. Dữ liệu cũ và cấu trúc bảng được giữ nguyên. Có thể chạy lại file này.';
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
DROP PROCEDURE IF EXISTS #CpsSeedRow;
DROP TABLE IF EXISTS #CpsMap;
DROP TABLE IF EXISTS #CpsColumns;
DROP TABLE IF EXISTS #CpsTables;
