"""Starts the real compiled app with an intentionally unavailable test SQL endpoint.
Checks public Razor rendering, authentication boundaries, invalid lookup and DB error UX.
Requires .NET 10, Playwright and Chromium. No original SQL database is accessed.
"""
from pathlib import Path
import os, socket, subprocess, tempfile, time, http.client, json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
passed=[]
def check(name, condition):
    assert condition,name
    passed.append(name)
with tempfile.TemporaryDirectory() as tmp:
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    env=os.environ.copy()
    env.update(ASPNETCORE_ENVIRONMENT='Development',ASPNETCORE_URLS=f'http://127.0.0.1:{port}',Store__ReceiptKeyPath=tmp+'/keys',ConnectionStrings__DbQLBHConnection='Server=127.0.0.1,1;Database=UnavailableTestOnly;Integrated Security=true;Encrypt=true;Connect Timeout=1')
    with open(tmp+'/app.log','w') as log:
        process=subprocess.Popen([os.environ.get('DOTNET_EXECUTABLE','dotnet'),str(ROOT/'bin/Debug/net10.0/cellphones.dll')],cwd=ROOT,env=env,stdout=log,stderr=log)
        try:
            for _ in range(100):
                if process.poll() is not None: raise RuntimeError('Application exited during startup')
                try:
                    connection=http.client.HTTPConnection('127.0.0.1',port,timeout=1);connection.request('GET','/Checkout/Lookup');r=connection.getresponse();r.read();connection.close()
                    if r.status==200:break
                except OSError: pass
                time.sleep(.1)
            else:raise RuntimeError('Startup timed out')
            with sync_playwright() as pw:
                browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':390,'height':844})
                errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                base=f'http://127.0.0.1:{port}'
                response=page.goto(base+'/Checkout/Lookup')
                check('real lookup Razor view renders',response.status==200 and page.locator('textarea[name="Key"]').count()==1)
                page.locator('textarea[name="Key"]').fill('invalid-key')
                page.get_by_role('button',name='Xem đơn hàng',exact=True).click()
                page.wait_for_url('**/Checkout/Success?key=invalid-key')
                check('invalid receipt key shows actionable error, not 500',page.get_by_role('alert').is_visible())
                check('receipt response is not cached', 'no-store' in page.request.get(base+'/Checkout/Success?key=invalid-key').headers.get('cache-control',''))
                response=page.goto(base+'/Home/Support')
                check('support Razor view renders',response.status==200 and page.get_by_role('heading',name='Liên hệ & chính sách cửa hàng').count()==1)
                check('support mobile layout has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                page.goto(base+'/DonBHs/Index')
                check('admin orders require login', '/Account/Login' in page.url and page.locator('input[name="Username"]').count()==1)
                response=page.goto(base+'/Store/Index')
                check('store handles unavailable SQL without an error page',response.status==200 and page.get_by_role('heading',name='Danh mục tạm thời chưa sẵn sàng').count()==1)
                check('real storefront mobile layout has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                check('real public views have no JS runtime errors', not errors)
                browser.close()
        finally:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
print(json.dumps({'passed':len(passed),'checks':passed},ensure_ascii=False,indent=2))
