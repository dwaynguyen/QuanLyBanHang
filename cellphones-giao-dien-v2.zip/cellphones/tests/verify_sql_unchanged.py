"""Usage: python tests/verify_sql_unchanged.py /path/to/original/cellphones.zip"""
from pathlib import Path
import sys,zipfile
root=Path(__file__).resolve().parents[1]
count=0
with zipfile.ZipFile(sys.argv[1]) as archive:
    for entry in archive.namelist():
        parts=Path(entry).parts
        if len(parts)>2 and parts[0]=='cellphones' and parts[1] in {'SQL','Models','Data'} and not entry.endswith('/'):
            relative=Path(*parts[1:])
            assert (root/relative).read_bytes()==archive.read(entry),f'Changed protected file: {relative}'
            count+=1
assert count>0,'No original schema/model files found'
print(f'PASS: {count} SQL, model and DbContext files are byte-for-byte unchanged.')
