"""Browser regression checks for actual site.js/shop.js using small DOM fixtures.
Run from project root: python tests/browser_checks.py (requires Playwright + Chromium).
These checks do not replace a .NET build or tests against the original SQL database.
"""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from functools import partial
import tempfile
import shutil
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(name, condition):
    assert condition, name
    checks.append(name)

with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    shutil.copytree(ROOT / 'wwwroot', root / 'wwwroot')
    cards = ''.join(f'''<article class="product-card" data-name="Điện thoại {i:02}" data-code="P{i}" data-category="Điện thoại" data-price="{100+i}"><a data-product-detail href="/Store/Details/P{i}">Điện thoại {i:02}</a><form><input name="returnUrl"></form></article>''' for i in range(26))
    cards += '<article class="product-card" data-name="Ốp lưng" data-code="CASE" data-category="Phụ kiện" data-price="5">Ốp lưng điện thoại</article>'
    (root / 'catalog.html').write_text('''<!doctype html><html lang="vi"><meta charset="utf-8"><section data-catalog><input data-search><select data-category><option value="">Tất cả</option><option>Điện thoại</option><option>Phụ kiện</option></select><select data-sort><option value="default">Mặc định</option><option value="price-up">Tăng</option><option value="price-down">Giảm</option><option value="name">Tên</option></select><span data-result-count></span><button data-reset>Xóa bộ lọc</button><div class="product-grid">'''+cards+'''</div><div data-empty hidden>Trống</div><div data-pagination></div></section><script src="/wwwroot/js/site.js"></script></html>''')
    (root / 'checkout.html').write_text('''<!doctype html><html lang="vi"><meta charset="utf-8"><form data-checkout-form onsubmit="event.preventDefault()"><div data-province-field hidden><select data-province><option value="">Chọn tỉnh</option><option value="1">Tỉnh A</option><option value="2">Tỉnh B</option></select></div><select data-ward required><option value="">Chọn xã</option><optgroup label="A"><option data-province-id="1" value="11">Xã 11</option><option data-province-id="1" value="12">Xã 12</option></optgroup><optgroup label="B"><option data-province-id="2" value="21" selected>Xã 21</option></optgroup></select><input name="FullName" required><button type="submit">Đặt hàng</button></form><form class="quantity-form" onsubmit="event.preventDefault();this.dataset.submits=String(Number(this.dataset.submits||0)+1)"><input name="quantity" type="number" min="1" max="99" value="98"><button type="button" data-step="1">+</button><button type="button" data-step="-1">−</button></form><script src="/wwwroot/js/shop.js"></script></html>''')
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *args): pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, directory=temp))
    Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
            page = browser.new_page()
            errors=[]
            page.on('pageerror',lambda error: errors.append(str(error)))
            page.goto(base+'/catalog.html?category='+__import__('urllib.parse',fromlist=['quote']).quote('Điện thoại')+'&page=2&sort=price-down')
            check('category URL selects dropdown, not text search', page.locator('select[data-category]').input_value()=='Điện thoại' and page.locator('[data-search]').input_value()=='')
            check('exact category excludes phone accessory', page.locator('[data-code="CASE"]').is_hidden())
            check('page two restored and price sort applied', page.locator('.product-card:visible').count()==12 and page.locator('.product-card:visible').first.get_attribute('data-code')=='P13')
            check('cart return URL contains selected page', 'page=2' in page.locator('input[name="returnUrl"]').first.input_value())
            check('detail link preserves return URL', 'returnUrl=' in page.locator('[data-product-detail]').first.get_attribute('href'))
            page.locator('[data-search]').fill('dien thoai 02')
            check('Vietnamese search ignores accents', page.locator('.product-card:visible').count()==1 and page.locator('.product-card:visible').get_attribute('data-code')=='P2')
            check('search resets pagination and persists URL', 'page=' not in page.url and 'q=dien' in page.url)
            page.reload()
            check('reload preserves query category and sort', page.locator('[data-search]').input_value()=='dien thoai 02' and page.locator('select[data-category]').input_value()=='Điện thoại' and page.locator('[data-sort]').input_value()=='price-down')
            page.locator('select[data-category]').select_option('Phụ kiện')
            check('query and category combine rather than override each other', page.locator('.product-card:visible').count()==0 and page.locator('[data-empty]').is_visible())
            page.locator('[data-reset]').click()
            check('reset clears URL and restores results', '?' not in page.url and page.locator('.product-card:visible').count()==12)
            page.evaluate("history.pushState(null,'','?category='+encodeURIComponent('Phụ kiện'));window.dispatchEvent(new PopStateEvent('popstate'))")
            check('back forward restoration applies correct category', page.locator('.product-card:visible').count()==1 and page.locator('.product-card:visible').get_attribute('data-code')=='CASE')
            page.goto(base+'/checkout.html')
            check('posted ward restores its province', page.locator('[data-province]').input_value()=='2' and page.locator('[data-ward]').input_value()=='21')
            page.locator('[data-province]').select_option('1')
            check('province change clears previous ward and limits options', page.locator('[data-ward]').input_value()=='' and page.locator('[data-ward] option').count()==3 and page.locator('[data-ward] option[value="21"]').count()==0)
            page.locator('[data-checkout-form] button').click()
            check('invalid checkout keeps submit button enabled', page.locator('[data-checkout-form] button').is_enabled())
            page.locator('[data-ward]').select_option('11')
            page.locator('[name="FullName"]').fill('Nguyễn Văn An')
            page.locator('[data-checkout-form] button').click()
            check('valid checkout prevents repeated clicks', page.locator('[data-checkout-form] button').is_disabled())
            page.locator('[data-step="1"]').click()
            page.locator('[data-step="1"]').click()
            check('quantity increment capped at 99 and submits', page.locator('[name="quantity"]').input_value()=='99' and page.locator('.quantity-form').get_attribute('data-submits')=='2')
            page.locator('[name="quantity"]').fill('1')
            page.locator('[data-step="-1"]').click()
            check('quantity decrement capped at one',page.locator('[name="quantity"]').input_value()=='1')
            check('no JavaScript runtime errors', not errors)
            browser.close()
    finally:
        server.shutdown()
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
