using cellphones.Data;
using Microsoft.Data.SqlClient;
namespace cellphones.Services;

public class InventoryService(AppDbContext db)
{
    // Received purchases minus ALL recorded sales (including reserved web orders).
    // No opening stock is invented. Future or undated purchases have not been received.
    public Dictionary<string,long> Snapshot()
    {
        return Calculate(db.DonMH_DanhSach(),db.CTMH_DanhSach(),db.CTBH_DanhSach(),
            TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("Asia/Ho_Chi_Minh")).Date);
    }

    public static Dictionary<string,long> Calculate(IEnumerable<cellphones.Models.DonMH> purchases,
        IEnumerable<cellphones.Models.CTMH> incoming, IEnumerable<cellphones.Models.CTBH> outgoing, DateTime today)
    {
        var received = purchases.Where(x => x.NgayGiao.HasValue && x.NgayGiao.Value.Date <= today.Date).Select(x => x.MaDMH).ToHashSet();
        var stock = new Dictionary<string,long>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in incoming.Where(x => received.Contains(x.MaDMH)))
            stock[line.MaSP.Trim()] = stock.GetValueOrDefault(line.MaSP.Trim()) + line.SLM;
        foreach (var line in outgoing)
            stock[line.MaSP.Trim()] = stock.GetValueOrDefault(line.MaSP.Trim()) - line.SLB;
        return stock;
    }

    // Call inside a SERIALIZABLE transaction; lock the same product before checking/writing.
    public static async Task<long> Available(SqlConnection connection, SqlTransaction transaction, string id)
    {
        var products = await SqlTables.Resolve(connection, transaction, "SanPham");
        var purchases = await SqlTables.Resolve(connection, transaction, "DonMH");
        var purchaseLines = await SqlTables.Resolve(connection, transaction, "CTMH");
        var sales = await SqlTables.Resolve(connection, transaction, "CTBH");
        await using var command = new SqlCommand($"""
            SELECT MaSP FROM {products} WITH (UPDLOCK,HOLDLOCK) WHERE MaSP=@id;
            SELECT
              COALESCE((SELECT SUM(CONVERT(bigint,c.SLM)) FROM {purchaseLines} c WITH (HOLDLOCK)
                JOIN {purchases} d WITH (HOLDLOCK) ON d.MaDMH=c.MaDMH
                WHERE c.MaSP=@id AND d.NgayGiao IS NOT NULL AND d.NgayGiao < @tomorrow),0)
              - COALESCE((SELECT SUM(CONVERT(bigint,SLB)) FROM {sales} WITH (UPDLOCK,HOLDLOCK) WHERE MaSP=@id),0);
            """, connection, transaction);
        var today = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("Asia/Ho_Chi_Minh")).Date;
        command.Parameters.AddWithValue("@id",id);
        command.Parameters.AddWithValue("@tomorrow",today.AddDays(1));
        await using var reader = await command.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) throw new InvalidOperationException("Sản phẩm không còn tồn tại.");
        await reader.NextResultAsync();
        await reader.ReadAsync();
        return reader.GetInt64(0);
    }
}
