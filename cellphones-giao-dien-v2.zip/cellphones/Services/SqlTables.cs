using Microsoft.Data.SqlClient;
namespace cellphones.Services;

// Resolve existing singular/plural tables; never creates or changes database objects.
public static class SqlTables
{
    public static async Task<string> Resolve(SqlConnection connection, SqlTransaction transaction, string name)
    {
        await using var command = new SqlCommand("SELECT QUOTENAME(SCHEMA_NAME(schema_id))+'.'+QUOTENAME(name) FROM sys.tables WHERE name IN (@a,@b)", connection, transaction);
        command.Parameters.AddWithValue("@a", name);
        command.Parameters.AddWithValue("@b", name+"s");
        var names = new List<string>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync()) names.Add(reader.GetString(0));
        if (names.Count != 1) throw new InvalidOperationException("Chưa xác định được bảng " + name + ". Vui lòng liên hệ cửa hàng.");
        return names[0];
    }
}
