using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using cellphones.Data;
using cellphones.Models;
using cellphones.ViewModels;
namespace cellphones.Services;

public class OrderService(AppDbContext db,IConfiguration configuration,OrderReceiptService receipts)
{
    // New checkout uses a single SQL transaction. Original models, tables and CRUD procedures are retained.
    public async Task<OrderReceipt> Place(CheckoutPage input,List<CartEntry> entries,string sessionId,string expectedFingerprint)
    {
        if(entries.Count==0 || entries.Count>30 || entries.Any(x=>x.Quantity<1 || x.Quantity>99)) throw new InvalidOperationException("Giỏ hàng không hợp lệ. Vui lòng kiểm tra lại.");
        await using var connection=new SqlConnection(db.Database.GetConnectionString()); await connection.OpenAsync();
        await using var tx=(SqlTransaction)await connection.BeginTransactionAsync(IsolationLevel.Serializable);
        async Task<object> Scalar(string sql,params SqlParameter[] parameters) { await using var c=new SqlCommand(sql,connection,tx);c.Parameters.AddRange(parameters);return await c.ExecuteScalarAsync(); }
        async Task<string> Table(string name)
        {
            await using var cmd=new SqlCommand("SELECT QUOTENAME(SCHEMA_NAME(schema_id))+'.'+QUOTENAME(name) FROM sys.tables WHERE name IN (@a,@b)",connection,tx);
            cmd.Parameters.AddWithValue("@a",name);cmd.Parameters.AddWithValue("@b",name+"s");
            var names=new List<string>();await using var r=await cmd.ExecuteReaderAsync();while(await r.ReadAsync()) names.Add(r.GetString(0));
            if(names.Count!=1) throw new InvalidOperationException("Chưa xác định được bảng "+name+" trong CSDL. Vui lòng liên hệ cửa hàng.");return names[0];
        }
        async Task<int> Insert(string table,string pk,Dictionary<string,object> values)
        {
            var identity=Convert.ToInt32(await Scalar("SELECT COLUMNPROPERTY(OBJECT_ID(@t),@p,'IsIdentity')",new SqlParameter("@t",table),new SqlParameter("@p",pk)))==1;
            if(!identity)
            {
                var next=Convert.ToInt64(await Scalar($"SELECT ISNULL(MAX([{pk}]),0)+1 FROM {table} WITH(UPDLOCK,HOLDLOCK)"));
                if(next>int.MaxValue) throw new InvalidOperationException("Không thể cấp mã đơn hàng mới.");values[pk]=next;
            }
            var columns=values.Keys.ToArray();
            var sql=$"DECLARE @new TABLE(Id int); INSERT {table} ({string.Join(',',columns.Select(c=>'['+c+']'))}) OUTPUT inserted.[{pk}] INTO @new VALUES ({string.Join(',',columns.Select((_,i)=>"@p"+i))}); SELECT Id FROM @new;";
            return Convert.ToInt32(await Scalar(sql,columns.Select((c,i)=>new SqlParameter("@p"+i,values[c]??DBNull.Value)).ToArray()));
        }
        try
        {
            var productTable=await Table("SanPham");var customerTable=await Table("KhachHang");var orderTable=await Table("DonBH");var detailTable=await Table("CTBH");var employeeTable=await Table("NhanVien");var wardTable=await Table("XaPhuong");
            if(Convert.ToInt32(await Scalar($"SELECT COUNT(*) FROM {wardTable} WHERE MaXP=@id",new SqlParameter("@id",input.WardId)))!=1) throw new InvalidOperationException("Xã / phường đã thay đổi. Vui lòng chọn lại.");
            var employee=configuration.GetValue<short?>("Store:OrderEmployeeId");
            var staff=await Scalar($"SELECT MIN(MaNV) FROM {employeeTable} WHERE (@id IS NULL OR MaNV=@id)",new SqlParameter("@id",(object)employee??DBNull.Value));
            if(staff is null || staff is DBNull) throw new InvalidOperationException("Cửa hàng chưa cấu hình nhân viên tiếp nhận đơn. Vui lòng thử lại sau.");
            var lines=new List<CartLine>();
            foreach(var entry in entries.OrderBy(x=>x.Id,StringComparer.OrdinalIgnoreCase))
            {
                var available=await InventoryService.Available(connection,tx,entry.Id);
                if(entry.Quantity>available) throw new InvalidOperationException($"Sản phẩm {entry.Id} chỉ còn {Math.Max(0,available)} sản phẩm có thể đặt.");
                await using var c=new SqlCommand($"SELECT MaSP,TenSP,DonGia,AnhSP,MoTaCT,MaLSP,MaDVT FROM {productTable} WITH(UPDLOCK,HOLDLOCK) WHERE MaSP=@id",connection,tx);c.Parameters.AddWithValue("@id",entry.Id);
                await using var r=await c.ExecuteReaderAsync();
                if(!await r.ReadAsync()) throw new InvalidOperationException("Một sản phẩm trong giỏ đã ngừng bán. Vui lòng kiểm tra giỏ hàng.");
                var product=new SanPham { MaSP=r.GetString(0).Trim(),TenSP=r.GetString(1),DonGia=r.GetDecimal(2),AnhSP=r.IsDBNull(3)?null:r.GetString(3),MoTaCT=r.IsDBNull(4)?null:r.GetString(4),MaLSP=r.GetInt16(5),MaDVT=r.GetByte(6) };
                if(product.DonGia<=0) throw new InvalidOperationException("Sản phẩm chưa có giá bán hợp lệ.");
                lines.Add(new CartLine { Product=product,Quantity=entry.Quantity });
            }
            if(CartService.Fingerprint(new CartPage { Lines=lines })!=expectedFingerprint)
                throw new InvalidOperationException("Giá bán vừa thay đổi. Vui lòng kiểm tra tổng tiền và xác nhận lại.");
            var parts=input.FullName.Trim().Split(' ',StringSplitOptions.RemoveEmptyEntries);var given=parts.Last();var family=parts.Length>1?string.Join(' ',parts.SkipLast(1)):given;
            if(given.Length>20 || family.Length>50) throw new InvalidOperationException("Tên tối đa 20 ký tự; họ và tên đệm tối đa 50 ký tự.");
            // Reuse only an exact contact match. Never overwrite an existing customer's profile.
            var customer=await Scalar($"SELECT TOP(1) MaKH FROM {customerTable} WITH(UPDLOCK,HOLDLOCK) WHERE Email=@email AND DienThoai=@phone AND HoKH=@ho AND TenKH=@ten ORDER BY MaKH",new SqlParameter("@email",input.Email.Trim()),new SqlParameter("@phone",input.Phone.Trim()),new SqlParameter("@ho",family),new SqlParameter("@ten",given));
            int customerId;
            if(customer!=null && customer is not DBNull) customerId=Convert.ToInt32(customer);
            else
            {
                var guest=new KhachHang();var password=new PasswordHasher<KhachHang>().HashPassword(guest,Guid.NewGuid().ToString("N")+Guid.NewGuid().ToString("N"));
                customerId=await Insert(customerTable,"MaKH",new() { ["HoKH"]=family,["TenKH"]=given,["DienThoai"]=input.Phone.Trim(),["Email"]=input.Email.Trim(),["DiaChi"]=input.Address.Trim(),["MaXP"]=input.WardId,["TenDN"]="web."+Guid.NewGuid().ToString("N"),["MatKhau"]=password });
            }
            var created=TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow,TimeZoneInfo.FindSystemTimeZoneById("Asia/Ho_Chi_Minh"));
            var orderId=await Insert(orderTable,"MaDBH",new() { ["NgayDat"]=created,["NgayGiao"]=DBNull.Value,["DCGH"]=input.Address.Trim(),["MaXP"]=input.WardId,["MaNV"]=Convert.ToInt16(staff),["MaKH"]=customerId });
            foreach(var line in lines) await Scalar($"INSERT {detailTable}(MaDBH,MaSP,SLB,DGB) VALUES(@order,@product,@qty,@price); SELECT 1;",new SqlParameter("@order",orderId),new SqlParameter("@product",line.Product.MaSP),new SqlParameter("@qty",line.Quantity),new SqlParameter("@price",line.Product.DonGia));
            var storedDate=Convert.ToDateTime(await Scalar($"SELECT NgayDat FROM {orderTable} WHERE MaDBH=@id",new SqlParameter("@id",orderId)));
            var receiptKey=receipts.CreateKey(orderId,customerId,storedDate);
            await tx.CommitAsync();
            return new OrderReceipt { Key=receiptKey,SessionId=sessionId,OrderId=orderId,FullName=input.FullName.Trim(),Phone=input.Phone.Trim(),Address=input.Address.Trim(),Created=created,Lines=lines };
        }
        catch { await tx.RollbackAsync();throw; }
    }
}
