using Microsoft.Extensions.Caching.Memory;
using cellphones.ViewModels;
namespace cellphones.Services;
// Serializes final checkout in this application instance; completed tokens are kept for two hours.
public class CheckoutGate(IMemoryCache cache)
{
    public SemaphoreSlim Lock { get; } = new(1,1);
    public OrderReceipt Find(string key) => cache.Get<OrderReceipt>("receipt:"+key);
    public void Save(string checkoutToken, OrderReceipt receipt)
    {
        cache.Set("receipt:"+checkoutToken,receipt,TimeSpan.FromHours(2));
    }
}
