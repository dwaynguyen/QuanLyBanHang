using System.Globalization;
using System.Text;
using cellphones.Data;
namespace cellphones.Services;

public class AdminAccess(AppDbContext db)
{
    private static string Normalize(string s) => new string((s??"").Normalize(NormalizationForm.FormD).Where(c=>CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark).ToArray()).Replace('đ','d').Replace('Đ','D').ToLowerInvariant().Trim();
    public bool IsAdmin(short employeeId)
    {
        var allowed=db.Quyen_DanhSach().Where(q=>new[]{"admin","administrator","quan ly","quan tri","quan tri vien"}.Contains(Normalize(q.TenQuyen))).Select(q=>q.MaQuyen).ToHashSet();
        return db.NhanVien_ChiTiet(employeeId)!=null && db.PhanQuyen_DanhSach().Any(x=>x.MaNV==employeeId && allowed.Contains(x.MaQuyen));
    }
}
