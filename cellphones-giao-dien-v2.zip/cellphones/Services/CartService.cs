using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;
using cellphones.Data;
using cellphones.ViewModels;
namespace cellphones.Services;

public class CartService(IHttpContextAccessor accessor, AppDbContext db, InventoryService inventory)
{
    private ISession Session => accessor.HttpContext!.Session;
    public List<CartEntry> Entries()
    {
        try { return JsonSerializer.Deserialize<List<CartEntry>>(Session.GetString("Cart") ?? "[]") ?? new(); }
        catch(JsonException) { Session.Remove("Cart"); return new(); }
    }
    public int Count => Entries().Sum(x=>x.Quantity);
    public void Set(string id,int quantity)
    {
        id=id.Trim(); var entries=Entries(); var item=entries.Find(x=>string.Equals(x.Id,id,StringComparison.OrdinalIgnoreCase));
        if(quantity<=0) { if(item!=null) entries.Remove(item); }
        else if(item!=null) item.Quantity=Math.Clamp(quantity,1,99);
        else if(entries.Count<30) entries.Add(new CartEntry { Id=id, Quantity=Math.Clamp(quantity,1,99) });
        Session.SetString("Cart",JsonSerializer.Serialize(entries));
    }
    public static string Fingerprint(CartPage page) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("|",page.Lines.OrderBy(x=>x.Product.MaSP.Trim(),StringComparer.OrdinalIgnoreCase).Select(x=>x.Product.MaSP.Trim().ToUpperInvariant()+":"+x.Quantity+":"+x.Product.DonGia.ToString(CultureInfo.InvariantCulture))))));
    public void Clear() => Session.Remove("Cart");
    public CartPage Page()
    {
        var entries=Entries(); var result=new CartPage();
        if(entries.Count==0) return result;
        var stock=inventory.Snapshot();
        var products=db.SanPham_DanhSach().ToDictionary(x=>x.MaSP.Trim(),StringComparer.OrdinalIgnoreCase);
        foreach(var item in entries)
            if(products.TryGetValue(item.Id,out var p) && p.DonGia>0) result.Lines.Add(new CartLine { Product=p,Quantity=item.Quantity,Available=Math.Max(0,stock.GetValueOrDefault(item.Id)) });
            else { result.HasUnavailable=true; result.UnavailableIds.Add(item.Id); }
        return result;
    }
}
