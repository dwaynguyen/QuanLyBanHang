using System.Security.Cryptography;
using System.Globalization;
using Microsoft.AspNetCore.DataProtection;
using cellphones.Data;
using cellphones.Models;
using cellphones.ViewModels;
namespace cellphones.Services;

public class OrderReceiptService(AppDbContext db, IDataProtectionProvider provider)
{
    private readonly IDataProtector protector = provider.CreateProtector("cellphones.order-receipt.v1");
    public string CreateKey(int orderId, int customerId, DateTime placed) =>
        protector.Protect($"{orderId}:{customerId}:{placed.Ticks}");

    public OrderDetailsPage Details(int id)
    {
        var order = db.DonBH_ChiTiet(id);
        if (order == null) return null;
        var customer = db.KhachHang_ChiTiet(order.MaKH);
        var employee = db.NhanVien_ChiTiet(order.MaNV);
        var ward = db.XaPhuong_DanhSach().FirstOrDefault(x => x.MaXP == order.MaXP);
        var province = ward == null ? null : db.Tinh_DanhSach().FirstOrDefault(x => x.MaTinh == ward.MaTinh);
        var products = db.SanPham_DanhSach().ToDictionary(x => x.MaSP.Trim(), StringComparer.OrdinalIgnoreCase);
        var lines = db.CTBH_DanhSach().Where(x => x.MaDBH == id).Select(x => {
            products.TryGetValue(x.MaSP.Trim(), out var product);
            // Use the recorded selling price, never today's catalog price.
            return new CartLine { Quantity=x.SLB, Product=new SanPham { MaSP=x.MaSP.Trim(), TenSP=product?.TenSP ?? x.MaSP.Trim(), AnhSP=product?.AnhSP, DonGia=x.DGB } };
        }).ToList();
        return new OrderDetailsPage { Order=order, CustomerName=customer == null ? $"Khách #{order.MaKH}" : customer.HoKH+" "+customer.TenKH,
            Phone=customer?.DienThoai ?? "", Email=customer?.Email ?? "", EmployeeName=employee == null ? $"Nhân viên #{order.MaNV}" : employee.HoNV+" "+employee.TenNV,
            Address=string.Join(", ",new[] { order.DCGH,ward?.TenXP,province?.TenTinh }.Where(x => !string.IsNullOrWhiteSpace(x))), Lines=lines };
    }

    public OrderReceipt Read(string key)
    {
        if (string.IsNullOrWhiteSpace(key) || key.Length > 2048) return null;
        string[] parts;
        try { parts=protector.Unprotect(key).Split(':'); }
        catch (CryptographicException) { return null; }
        if (parts.Length != 3 || !int.TryParse(parts[0],out var id) || !int.TryParse(parts[1],out var customerId) || !long.TryParse(parts[2],out var ticks)) return null;
        var order = db.DonBH_ChiTiet(id);
        if (order == null || order.MaKH != customerId || order.NgayDat.Ticks != ticks) return null;
        var page = Details(id);
        return new OrderReceipt { Key=key, OrderId=id, Created=order.NgayDat, DeliveryDate=order.NgayGiao, FullName=page.CustomerName, Phone=page.Phone, Address=page.Address, Lines=page.Lines };
    }
}
