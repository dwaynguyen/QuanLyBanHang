using cellphones.Models;
using cellphones.ViewModels;
namespace cellphones.Services;

public static class DashboardService
{
    public static DashboardPage Build(List<SanPham> products, List<KhachHang> customers,
        List<DonBH> orders, List<CTBH> details, int employees, DateTime today, int days)
    {
        days = days is 7 or 30 or 90 ? days : 7;
        today=today.Date;
        var from=today.AddDays(1-days);
        var selected=orders.Where(o=>o.NgayDat>=from && o.NgayDat<today.AddDays(1)).ToList();
        var ids=selected.Select(o=>o.MaDBH).ToHashSet();
        var selectedDetails=details.Where(d=>ids.Contains(d.MaDBH)).ToList();
        var totals=selectedDetails.GroupBy(x=>x.MaDBH).ToDictionary(x=>x.Key,x=>x.Sum(d=>d.SLB*d.DGB));
        var names=products.ToDictionary(x=>x.MaSP.Trim(),x=>x.TenSP,StringComparer.OrdinalIgnoreCase);
        var value=totals.Values.Sum();
        return new DashboardPage {
            Days=days,From=from,To=today,ProductCount=products.Count,CustomerCount=customers.Count,EmployeeCount=employees,
            OrderCount=selected.Count,TodayOrderCount=selected.Count(o=>o.NgayDat.Date==today),
            EmptyOrderCount=selected.Count(o=>!totals.ContainsKey(o.MaDBH)),
            PendingCount=selected.Count(x=>x.NgayGiao==null),SalesValue=value,
            AverageOrderValue=selected.Count==0?0:value/selected.Count,Totals=totals,
            Customers=customers.ToDictionary(x=>x.MaKH,x=>x.HoKH+" "+x.TenKH),
            Orders=selected.OrderByDescending(x=>x.NgayDat).ThenByDescending(x=>x.MaDBH).Take(8).ToList(),
            Daily=Enumerable.Range(0,days).Select(i=>from.AddDays(i)).Select(day=>(day,selected.Where(o=>o.NgayDat.Date==day).Sum(o=>totals.GetValueOrDefault(o.MaDBH)))).ToList(),
            BestSellers=selectedDetails.GroupBy(x=>x.MaSP.Trim(),StringComparer.OrdinalIgnoreCase).Select(g=>(names.GetValueOrDefault(g.Key)??g.Key,g.Sum(x=>(long)x.SLB),g.Sum(x=>x.SLB*x.DGB))).OrderByDescending(x=>x.Item2).Take(5).ToList()
        };
    }
}
