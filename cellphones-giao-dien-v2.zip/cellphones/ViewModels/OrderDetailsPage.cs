using cellphones.Models;
namespace cellphones.ViewModels;
public class OrderDetailsPage
{
    public DonBH Order { get; set; }
    public string CustomerName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public string EmployeeName { get; set; } = "";
    public string Address { get; set; } = "";
    public List<CartLine> Lines { get; set; } = new();
    public decimal Total => Lines.Sum(x => x.Total);
}
