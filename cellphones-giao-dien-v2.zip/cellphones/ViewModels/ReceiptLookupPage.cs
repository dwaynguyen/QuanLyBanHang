using System.ComponentModel.DataAnnotations;
namespace cellphones.ViewModels;
public class ReceiptLookupPage
{
    [Required(ErrorMessage="Nhập mã tra cứu riêng đã lưu sau khi đặt hàng."),StringLength(2048)]
    public string Key { get; set; } = "";
    public string Error { get; set; } = "";
}
