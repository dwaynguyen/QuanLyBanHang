# Cập nhật giao diện khách hàng & quản trị — bản 2

- Khách hàng: trang chủ, danh mục, sản phẩm, giỏ hàng, thông tin người nhận, COD và xác nhận đơn; thêm hướng dẫn 3 bước mua hàng và nhóm sản phẩm trên trang chủ (nhóm có ít nhất 3 sản phẩm để tránh trang thưa/trùng lặp).
- Giỏ hàng xác nhận trước khi xóa toàn bộ; checkout đưa lỗi tổng quát về vị trí dễ thấy và nhắc nhập đủ thông tin nhận hàng.
- Quản trị: trang đăng nhập riêng, hiện/ẩn mật khẩu và phản hồi khi đăng nhập; Dashboard có bộ lọc 7/30/90 ngày, giá trị đơn, đơn hôm nay, trung bình/đơn, đơn chưa có dòng hàng, biểu đồ, đơn gần đây và sản phẩm bán nhiều. Giá trị đơn không phải tiền thực thu. Các KPI đơn/biểu đồ/top sản phẩm cùng dùng khoảng ngày đang chọn; số sản phẩm/khách hàng là tổng danh mục.
- Menu quản trị có nút mở/đóng trên điện thoại. Khi không lấy được dữ liệu, Dashboard hiển thị thông báo thay cho số liệu 0 dễ gây hiểu nhầm.
- Giữ nguyên SQL, Models và Data/AppDbContext; không thêm bảng/cột, không migration.

Đường dẫn chạy: `/Store/Index`, `/Cart/Index`, `/Checkout/Index` (cần có giỏ), `/Account/Login`, `/Admin/Index` (cần quyền quản trị). Dùng tài khoản nhân viên có mật khẩu băm ASP.NET Identity và quyền quản trị đã có trong cơ sở dữ liệu; không có tài khoản/mật khẩu quản trị tự tạo mới. Không chuyển mật khẩu băm thành chữ thường.

**Khi thay bản cũ:** giữ riêng `appsettings.json` đang kết nối được SQL và thư mục `App_Data/keys` của máy bạn. Giải nén vào thư mục mới, đưa cấu hình/khóa cũ vào đúng vị trí rồi mở `cellphones/cellphones.csproj` bằng Visual Studio hỗ trợ .NET 10. Build và chạy bằng F5. Không cần chạy SQL cập nhật cấu trúc. Có thể giữ bản cũ để quay lại.

Kiểm tra bản 2: build C#/Razor 0 lỗi; 16 kiểm tra C#, 18 kiểm tra JavaScript giỏ/lọc, 9 kiểm tra HTTP/bảo vệ quản trị. Render chính các trang Razor với dữ liệu minh họa bằng máy chủ kiểm thử riêng: 27 kiểm tra desktop/mobile và tương tác, không đưa máy chủ kiểm thử hoặc dữ liệu minh họa đó vào bản chạy. Chưa kiểm thử giao dịch trên CSDL SQL Server gốc. Cảnh báo phụ thuộc NuGet từ bản cũ vẫn còn như ghi bên dưới.

---

# Bản sửa giao diện và luồng bán hàng

## Cam kết giữ nguyên SQL

Không thêm, xóa hay đổi tên bảng/cột; không đổi kiểu dữ liệu, khóa hoặc stored procedure. Toàn bộ 19 tệp trong `cellphones/Models`, `cellphones/Data` và `cellphones/SQL` giống từng byte với ZIP gốc. Không có migration, `EnsureCreated`, `ALTER TABLE` hay bước tự động nâng cấp cơ sở dữ liệu trong mã bổ sung. Không cần chạy lại script dữ liệu mẫu để áp dụng bản sửa này.

## Những phần đã sửa

- Danh mục được lọc chính xác, riêng với từ khóa. Tìm kiếm tiếng Việt không dấu; từ khóa, danh mục, sắp xếp và trang hiện tại được lưu trên URL. Mỗi trang có 12 sản phẩm. Sau khi xem chi tiết/thêm giỏ, có thể trở lại đúng danh sách đã chọn.
- Trang chi tiết đơn quản trị hiển thị tên khách, điện thoại, email, địa chỉ đầy đủ, nhân viên, các dòng hàng và tổng tiền theo đơn giá đã ghi nhận lúc bán. Có lối thêm/sửa/xóa dòng hàng ngay từ đơn và quay lại đơn sau thao tác.
- Tính lượng có thể đặt từ dữ liệu nhập/bán hiện có; chặn thêm/cập nhật giỏ hoặc đặt vượt tồn. Kiểm tra lại trong transaction SERIALIZABLE lúc lưu đơn; kiểm tra tương tự khi quản trị thêm/sửa dòng bán. Không chấp nhận đơn giá bán không dương trong biểu mẫu dòng bán. Không cho ngày giao trước ngày đặt.
- Chọn tỉnh/thành rồi mới chọn xã/phường, giữ lại địa chỉ hợp lệ sau lỗi biểu mẫu. Nếu không có JavaScript, dropdown xã/phường gốc vẫn dùng được.
- Đơn đã lưu được đọc lại từ SQL bằng mã tra cứu được bảo vệ bằng ASP.NET Core Data Protection; không phụ thuộc cache 2 giờ hay phiên mua hàng. Có sao chép mã, in/lưu PDF và trang tra cứu. Quản trị có thể cấp lại mã cho khách sau khi xác minh.
- Tăng cỡ chữ/độ tương phản ở mô tả, biểu mẫu và thông báo; tránh bàn phím số lượng vượt 1–99. Có trang liên hệ/chính sách để hiển thị nội dung cửa hàng cấu hình.

## Quy ước tính tồn cần đối chiếu với dữ liệu cửa hàng

Lượng có thể đặt = tổng `CTMH.SLM` của đơn mua có `DonMH.NgayGiao` khác NULL và ngày giao không sau hôm nay (giờ Việt Nam), trừ tổng `CTBH.SLB` đã ghi nhận. Đơn bán chưa giao vẫn giữ chỗ hàng. Ngày giao của đơn nhập được hiểu là chứng từ hàng đã nhận; nếu cửa hàng dùng trường này làm ngày dự kiến, cần đối chiếu lại quy ước nghiệp vụ trước khi bật bán thật.

Không tự bịa số dư đầu kỳ: dữ liệu chưa có nhập hàng đã nhận hoặc đã bán vượt lượng nhập sẽ hiện hết hàng. Cần ghi nhận đầy đủ chứng từ nhập thực tế bằng chức năng có sẵn. Không sửa SQL để đưa tồn về một con số tùy ý. Các ứng dụng khác ghi trực tiếp vào SQL hoặc sửa/xóa chứng từ nhập vẫn có thể thay đổi tồn; cần đối soát nếu có nhiều nguồn ghi dữ liệu.

## Trạng thái và biến thể sản phẩm

CSDL hiện tại không có cột riêng cho chờ xác nhận/đang giao/đã hủy hay trạng thái thu tiền. Bản sửa giữ nhãn theo `NgayGiao`, không suy diễn đã thu tiền từ ngày giao và không nhét trạng thái vào cột địa chỉ/mô tả. Các trạng thái độc lập này chưa được triển khai vì thiếu nơi lưu theo cấu trúc hiện có.

Tương tự, không tạo lựa chọn màu/dung lượng/RAM hay cam kết bảo hành từ dữ liệu không có. Trang sản phẩm dùng thông tin thật hiện có; các biến thể cần được xác định riêng trước khi triển khai.

## Chạy bản sửa

1. Giải nén. Thư mục ứng dụng là `cellphones`.
2. Dùng .NET 10 SDK, giữ cấu hình kết nối cơ sở dữ liệu của bạn. Có thể cấu hình an toàn bằng user secrets hoặc biến `ConnectionStrings__DbQLBHConnection`; không gửi mật khẩu vào chat.
3. Trong `cellphones`: chạy `dotnet restore`, `dotnet build`, `dotnet run`.
4. **Giữ và sao lưu thư mục `cellphones/App_Data/keys` qua các lần triển khai/khởi động lại.** Tài khoản chạy ứng dụng cần quyền ghi; chỉ tài khoản được phép mới được đọc khóa. Khi chạy nhiều instance, dùng chung key ring và bảo vệ khóa theo hạ tầng triển khai. Có thể đổi vị trí qua `Store__ReceiptKeyPath` sang thư mục bền vững ngoài checkout. Không đưa khóa vào Git hoặc bản ZIP chia sẻ.
5. Mã tra cứu là quyền xem thông tin đơn: giữ riêng tư. Các mã cache cũ của phiên bản trước không chuyển thành mã mới; quản trị có thể cấp mã mới từ trang chi tiết đơn. Khi thay đổi ngày đặt/khách hàng của một đơn, mã trước đó bị từ chối; cấp lại mã sau khi sửa. Giữ nguyên dữ liệu đơn và key ring để xem lại được sau khi hết phiên/cache hoặc restart.
6. Không có dữ liệu liên hệ/chính sách giả. Tùy chọn cấu hình `Store__Contact__Phone`, `Store__Contact__Email`, `Store__Contact__Address`, `Store__Policies__Delivery`, `Store__Policies__Warranty` bằng thông tin thật. Phí giao hàng hiện vẫn 0 như bản gốc; không thêm phí không có nơi lưu.

## Kiểm chứng đã thực hiện

- Build C#/Razor bằng .NET SDK 10.0.100: thành công, 0 lỗi.
- 18 kiểm tra Chromium trên mẫu DOM dùng JavaScript thật: lọc chính xác, kết hợp từ khóa/danh mục, sắp xếp/phân trang, giữ URL, reload/back, chọn địa chỉ, chặn nhấn đặt lặp, giới hạn số lượng.
- 11 kiểm tra C#: tính tồn, bỏ đơn nhập tương lai/chưa có ngày nhận, xử lý mã sản phẩm SQL có khoảng trắng, tổng lớn không tràn int, giỏ thiếu hàng, dấu vân tay giá/số lượng, mã tra cứu sau tạo lại provider, từ chối mã sai/sửa nội dung.
- 9 kiểm tra trên ứng dụng thật đang chạy: Razor tra cứu/liên hệ, trả lỗi mã tra cứu hợp lệ về giao diện, không cache thông tin đơn, yêu cầu đăng nhập quản trị, xử lý SQL không khả dụng, không tràn ngang trên các trang công khai đã kiểm tra ở 390px, không lỗi JS runtime.
- Đối chiếu toàn bộ SQL/model/DbContext với ZIP gốc: 19 tệp không đổi.

**Giới hạn kiểm chứng:** Chưa có CSDL SQL Server gốc để chạy trọn giao dịch đặt hàng/đọc đơn/cạnh tranh tồn hoặc trang quản trị có dữ liệu. Tải SQL Server kiểm thử tạm bị registry từ chối. Cần thử trên bản sao CSDL thật trước khi dùng chính thức. Việc kiểm tra khi SQL không khả dụng không xác nhận giao dịch SQL hoạt động.

Build còn cảnh báo nullable và cảnh báo NuGet NU1902/NU1903 của phụ thuộc gián tiếp `System.Security.Cryptography.Pkcs 9.0.11` từ bản gốc. Không tắt kiểm tra bảo mật hoặc thay phiên bản phụ thuộc trong đợt sửa giao diện này; cần nâng cấp phụ thuộc tương thích trước khi triển khai công khai.

## Chạy lại kiểm tra

- `dotnet run --project validation/Validation.csproj` từ thư mục chứa hai thư mục `cellphones` và `validation`.
- `python tests/browser_checks.py` trong `cellphones` (cần Python Playwright và Chromium; có thể chỉnh `executable_path` theo máy).
- `python tests/http_checks.py` trong `cellphones`, sau build (cần .NET trong PATH hoặc biến `DOTNET_EXECUTABLE`, cùng Playwright/Chromium). Script chỉ dùng điểm kết nối SQL kiểm thử cố tình không khả dụng, không truy cập CSDL gốc.
- `python tests/verify_sql_unchanged.py /duong/dan/cellphones-goc.zip` trong `cellphones`.
